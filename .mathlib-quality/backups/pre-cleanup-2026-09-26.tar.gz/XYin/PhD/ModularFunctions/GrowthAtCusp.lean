/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import XYin.PhD.ModularFunctions.CuspGrowth
import Mathlib.NumberTheory.ModularForms.BoundedAtCusp

/-!
# Exponential growth at arbitrary cusps

The definition follows `OnePoint.IsBoundedAt`, replacing boundedness with at most exponential
growth. Checking one scaling matrix suffices, so the condition is independent of that choice.
-/

open Complex Filter UpperHalfPlane Matrix.SpecialLinearGroup
open scoped Topology MatrixGroups ModularForm

noncomputable section

namespace UpperHalfPlane

/-- Changing coordinates by an upper triangular matrix preserves finite exponential growth. -/
lemma IsOfExponentialGrowth.slash {f : ℍ → ℂ} {g : GL (Fin 2) ℝ}
    (hf : IsOfExponentialGrowth f) (hg : g 1 0 = 0) :
    IsOfExponentialGrowth (f ∣[(0 : ℤ)] g) := by
  obtain ⟨ρ, hρ, hb⟩ := hf
  let a : ℝ := |g 0 0 / g 1 1|
  have him (τ : ℍ) : (g • τ).im = a * τ.im := by
    simp [a, im_smul, num, denom, hg, abs_div, abs_mul,
      abs_of_pos τ.im_pos, mul_div_right_comm]
  refine ⟨ρ * a, mul_nonneg hρ (abs_nonneg _), ?_⟩
  have hb' : IsBoundedAtImInfty
      (fun τ ↦ (Real.exp (-ρ * (g • τ).im) : ℂ) * f (g • τ)) :=
    hb.comp_tendsto (tendsto_smul_atImInfty hg)
  obtain ⟨M, A, hA⟩ := isBoundedAtImInfty_iff.mp hb'
  apply isBoundedAtImInfty_iff.mpr
  refine ⟨M * ‖((|g.det.val| : ℝ) : ℂ)⁻¹‖, A, fun τ hτ ↦ ?_⟩
  have he : -(ρ * a) * τ.im = -ρ * (g • τ).im := by rw [him]; ring
  simpa only [ModularForm.slash_apply, sub_zero, zero_sub, neg_zero, zpow_zero, mul_one,
    show (0 : ℤ) - 1 = -1 by norm_num, zpow_neg_one, norm_mul, norm_σ, he, mul_assoc]
    using mul_le_mul_of_nonneg_right (hA τ hτ) (norm_nonneg ((|g.det.val| : ℝ) : ℂ)⁻¹)

end UpperHalfPlane

namespace OnePoint

/-- A weight-zero function has at most exponential growth at a cusp if each scaling transform
has at most exponential growth at infinity, uniformly in the real part. -/
def IsOfExponentialGrowthAt (c : OnePoint ℝ) (f : ℍ → ℂ) : Prop :=
  ∀ g : GL (Fin 2) ℝ, g • ∞ = c → IsOfExponentialGrowth (f ∣[(0 : ℤ)] g)

variable {c : OnePoint ℝ} {f : ℍ → ℂ} {g : GL (Fin 2) ℝ}

lemma IsOfExponentialGrowthAt.smul_iff :
    IsOfExponentialGrowthAt (g • c) f ↔
      IsOfExponentialGrowthAt c (f ∣[(0 : ℤ)] g) := by
  rw [IsOfExponentialGrowthAt, IsOfExponentialGrowthAt,
    (Equiv.mulLeft g⁻¹).forall_congr_left]
  simp [mul_smul, ← SlashAction.slash_mul]

lemma isOfExponentialGrowthAt_infty_iff :
    IsOfExponentialGrowthAt ∞ f ↔ IsOfExponentialGrowth f :=
  ⟨fun h ↦ by simpa using h 1 (by simp),
    fun h _ hg ↦ h.slash (smul_infty_eq_self_iff.mp hg)⟩

/-- One scaling matrix is enough to test exponential growth at a cusp. -/
lemma isOfExponentialGrowthAt_iff (hg : g • ∞ = c) :
    IsOfExponentialGrowthAt c f ↔ IsOfExponentialGrowth (f ∣[(0 : ℤ)] g) :=
  ⟨fun hc ↦ hc g hg,
    by simp [← hg, IsOfExponentialGrowthAt.smul_iff, isOfExponentialGrowthAt_infty_iff]⟩

end OnePoint
