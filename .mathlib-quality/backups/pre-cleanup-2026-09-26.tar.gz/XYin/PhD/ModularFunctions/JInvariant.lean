/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import XYin.PhD.ModularFunctions.Basic
import XYin.PhD.jFunction.jfunction

/-!
# The modular invariant as a modular function

The classical modular invariant `j` defines a modular function for `SL₂(ℤ)`. Its existing
meromorphic cusp expansion supplies the exponential growth condition at every cusp.
-/

open Complex Function UpperHalfPlane Matrix.SpecialLinearGroup
open scoped Manifold MatrixGroups ModularForm

noncomputable section

namespace ModularFunction

/-- The classical modular invariant is holomorphic on the upper half-plane. -/
theorem j_mdifferentiable : MDiff j := by
  exact _root_.j_mdifferentiable

/-- The modular invariant has period one. -/
theorem j_periodic : Periodic (j ∘ UpperHalfPlane.ofComplex) 1 := by
  let f : SlashInvariantForm 𝒮ℒ 0 :=
    ⟨j, by rintro _ ⟨γ, rfl⟩; exact j_slash_invariant γ⟩
  exact SlashInvariantFormClass.periodic_comp_ofComplex f (by simp)

/-- The modular invariant has at most exponential growth at infinity. -/
theorem j_isOfExponentialGrowth : IsOfExponentialGrowth j :=
  isOfExponentialGrowth_of_meromorphicAt_cuspFunction one_pos j_periodic
    j_cuspFunction_meromorphicAt

end ModularFunction

/-- The classical modular invariant, bundled as a level-one modular function. -/
def jModularFunction : ModularFunction 𝒮ℒ where
  toFun := j
  slash_action_eq' := by
    rintro _ ⟨γ, rfl⟩
    exact j_slash_invariant γ
  meromorphic' := ⟨MeromorphicField.ofHolomorphic j ModularFunction.j_mdifferentiable,
    MeromorphicField.toFun_ofHolomorphic j ModularFunction.j_mdifferentiable⟩
  bdd_at_cusps' := by
    intro c hc
    obtain ⟨γ, hγ⟩ := isCusp_SL2Z_iff'.mp hc
    apply (OnePoint.isOfExponentialGrowthAt_iff hγ.symm).mpr
    change IsOfExponentialGrowth (j ∣[(0 : ℤ)] γ)
    rw [j_slash_invariant]
    exact ModularFunction.j_isOfExponentialGrowth

@[simp]
theorem coe_jModularFunction : (jModularFunction : ℍ → ℂ) = j := rfl
