/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import Mathlib.Analysis.Meromorphic.Basic
import Mathlib.NumberTheory.ModularForms.QExpansion

/-!
# Exponential growth and meromorphy at a cusp

Exponential growth is a condition on the upper half plane, independent of a choice of period.
For periodic functions holomorphic sufficiently high in the upper half plane, it is equivalent
to meromorphy of the cusp function at zero.
-/

open Complex Filter Function Set
open scoped Real Topology UpperHalfPlane Manifold

noncomputable section

namespace UpperHalfPlane

/-- A function has exponential growth at infinity if some nonnegative exponential weight makes
it bounded there. This condition does not involve a choice of period. -/
def IsOfExponentialGrowth (f : ℍ → ℂ) : Prop :=
  ∃ ρ : ℝ, 0 ≤ ρ ∧
    IsBoundedAtImInfty (fun τ ↦ (Real.exp (-ρ * τ.im) : ℂ) * f τ)

private lemma norm_qParam_pow (h : ℝ) (n : ℕ) (τ : ℍ) :
    ‖Periodic.qParam h τ ^ n‖ = Real.exp (-(2 * Real.pi * n / h) * τ.im) := by
  rw [norm_pow, Periodic.norm_qParam, ← Real.exp_nat_mul]
  change Real.exp ((n : ℝ) * (-2 * Real.pi * τ.im / h)) = _
  congr 1
  ring

private lemma weighted_bound_iff (h : ℝ) (n : ℕ) (f : ℍ → ℂ) :
    IsBoundedAtImInfty (fun τ ↦ (Real.exp (-(2 * Real.pi * n / h) * τ.im) : ℂ) * f τ) ↔
      IsBoundedAtImInfty (fun τ ↦ Periodic.qParam h τ ^ n * f τ) := by
  simp only [isBoundedAtImInfty_iff, norm_mul, norm_qParam_pow, Complex.norm_real,
    Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]

private lemma meromorphicAt_zero_of_bounded_pow {g : ℂ → ℂ} (n : ℕ)
    (hd : ∀ᶠ q in 𝓝[≠] 0, DifferentiableAt ℂ g q)
    (hb : BoundedAtFilter (𝓝[≠] 0) (fun q ↦ q ^ n * g q)) :
    MeromorphicAt g 0 := by
  have hz : ZeroAtFilter (𝓝[≠] (0 : ℂ)) (fun q ↦ q) := nhdsWithin_le_nhds
  have ht : Tendsto (fun q ↦ q ^ (n + 1) * g q) (𝓝[≠] 0) (𝓝 0) := by
    simpa only [Pi.mul_apply, pow_succ', mul_assoc] using hz.mul_boundedAtFilter hb
  refine ⟨n + 1, ?_⟩
  simp only [sub_zero, smul_eq_mul]
  apply Complex.analyticAt_of_differentiable_on_punctured_nhds_of_continuousAt
  · filter_upwards [hd] with q hq
    exact (differentiableAt_id.pow (n + 1)).mul hq
  · rw [continuousAt_iff_punctured_nhds]
    simpa using ht

private lemma bounded_pow_cuspFunction {h : ℝ} (hh : 0 < h) {f : ℍ → ℂ} (n : ℕ)
    (hb : IsBoundedAtImInfty (fun τ ↦ Periodic.qParam h τ ^ n * f τ)) :
    BoundedAtFilter (𝓝[≠] 0) (fun q ↦ q ^ n * cuspFunction h f q) := by
  have ht := tendsto_comap_im_ofComplex.comp (Periodic.invQParam_tendsto hh)
  have hb' := hb.comp_tendsto ht
  refine hb'.congr' ?_ (by simp)
  filter_upwards [self_mem_nhdsWithin,
    mem_nhdsWithin_of_mem_nhds (Metric.ball_mem_nhds (0 : ℂ) zero_lt_one)] with q hq hq1
  have hq0 : q ≠ 0 := hq
  have hpos := Periodic.im_invQParam_pos_of_norm_lt_one hh
    (mem_ball_zero_iff.mp hq1) hq0
  simp only [Function.comp_apply, ofComplex_apply_of_im_pos hpos, cuspFunction,
    Periodic.cuspFunction_eq_of_nonzero _ _ hq0, Periodic.qParam_right_inv hh.ne' hq0]

/-- Meromorphy of the cusp function gives a period-independent exponential growth bound. -/
theorem isOfExponentialGrowth_of_meromorphicAt_cuspFunction {h : ℝ} (hh : 0 < h)
    {f : ℍ → ℂ} (hfper : Periodic (f ∘ ofComplex) h)
    (hf : MeromorphicAt (cuspFunction h f) 0) : IsOfExponentialGrowth f := by
  obtain ⟨n, hn⟩ := hf
  refine ⟨2 * Real.pi * n / h, by positivity, (weighted_bound_iff h n f).mpr ?_⟩
  have ht := hn.continuousAt.tendsto.comp (qParam_tendsto_atImInfty hh)
  have hb := ht.isBigO_one ℝ
  simpa only [Function.comp_def, sub_zero, smul_eq_mul, eq_cuspFunction _ hh.ne' hfper]
    using hb

/-- A periodic function holomorphic sufficiently high in the upper half plane has exponential
growth if and only if its cusp function is meromorphic at zero. -/
theorem isOfExponentialGrowth_iff_meromorphicAt_cuspFunction {h : ℝ} (hh : 0 < h)
    {f : ℍ → ℂ} (hfper : Periodic (f ∘ ofComplex) h)
    (hfhol : ∀ᶠ τ in atImInfty, MDiffAt f τ) :
    IsOfExponentialGrowth f ↔ MeromorphicAt (cuspFunction h f) 0 := by
  refine ⟨?_, isOfExponentialGrowth_of_meromorphicAt_cuspFunction hh hfper⟩
  rintro ⟨ρ, hρ, hb⟩
  obtain ⟨n, hn⟩ := exists_nat_gt (ρ * h / (2 * Real.pi))
  have hρn : ρ ≤ 2 * Real.pi * n / h := by
    apply (le_div_iff₀ hh).mpr
    have := (div_lt_iff₀ (by positivity : 0 < 2 * Real.pi)).mp hn
    nlinarith
  have hbn : IsBoundedAtImInfty (fun τ ↦ Periodic.qParam h τ ^ n * f τ) := by
    rw [isBoundedAtImInfty_iff] at hb ⊢
    obtain ⟨M, A, hb⟩ := hb
    refine ⟨M, A, fun τ hτ ↦ le_trans ?_ (hb τ hτ)⟩
    simp only [norm_mul, norm_qParam_pow, Complex.norm_real,
      Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    apply mul_le_mul_of_nonneg_right _ (norm_nonneg _)
    apply Real.exp_le_exp.mpr
    simpa only [neg_mul] using neg_le_neg (mul_le_mul_of_nonneg_right hρn τ.im_pos.le)
  have hd : ∀ᶠ z in comap Complex.im atTop, DifferentiableAt ℂ (f ∘ ofComplex) z := by
    filter_upwards [tendsto_comap_im_ofComplex.eventually hfhol,
      preimage_mem_comap (Ioi_mem_atTop 0)] with z hz hzi
    have := mdifferentiableAt_iff.mp hz
    simpa only [ofComplex_apply_of_im_pos hzi] using this
  exact meromorphicAt_zero_of_bounded_pow n
    (hfper.eventually_differentiableAt_cuspFunction_nhds_ne_zero hh hd)
    (bounded_pow_cuspFunction hh n hbn)

end UpperHalfPlane
