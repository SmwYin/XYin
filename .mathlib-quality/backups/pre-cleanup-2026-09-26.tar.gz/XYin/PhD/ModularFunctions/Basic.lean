/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import XYin.PhD.ModularFunctions.MeromorphicField
import XYin.PhD.ModularFunctions.Cusps
import Mathlib.NumberTheory.ModularForms.SlashInvariantForms

/-!
# Modular functions

A modular function is a weight-zero slash-invariant function which is the canonical
representative of an element of the meromorphic function field on the upper half-plane,
and which has at most exponential growth at every cusp. As in `ModularForm`, growth is
uniform on a sufficiently high half-plane and is tested after every scaling transformation.
The definition of growth does not choose a period or cusp width.

Canonical representatives remove arbitrary values at removable singularities and assign zero
at poles. The ambient field operations are operations on codiscrete equivalence classes;
their canonical representatives need not be pointwise sums or products at poles.
-/

open UpperHalfPlane
open scoped MatrixGroups ModularForm

noncomputable section

/-- A weight-zero modular function, realized as a canonical meromorphic representative with
at most exponential growth at all cusps. -/
structure ModularFunction (Γ : Subgroup (GL (Fin 2) ℝ)) extends SlashInvariantForm Γ 0 where
  /-- The underlying function is the canonical representative of a meromorphic field element. -/
  meromorphic' : ∃ a : MeromorphicField, MeromorphicField.toFun a = toFun
  /-- Every cusp transform grows at most exponentially, uniformly in its real part. -/
  bdd_at_cusps' {c : OnePoint ℝ} (hc : IsCusp c Γ) : c.IsOfExponentialGrowthAt toFun

namespace ModularFunction

variable {Γ : Subgroup (GL (Fin 2) ℝ)}

instance : FunLike (ModularFunction Γ) ℍ ℂ where
  coe f := f.toFun
  coe_injective' f g h := by cases f; cases g; congr; exact DFunLike.ext' h

instance : SlashInvariantFormClass (ModularFunction Γ) Γ 0 where
  slash_action_eq f := f.slash_action_eq'

@[simp]
theorem toSlashInvariantForm_coe (f : ModularFunction Γ) :
    (f.toSlashInvariantForm : ℍ → ℂ) = f := rfl

@[ext]
theorem ext {f g : ModularFunction Γ} (h : ∀ τ, f τ = g τ) : f = g := DFunLike.ext f g h

/-- The ambient meromorphic function field element represented by a modular function. -/
def toMeromorphicField (f : ModularFunction Γ) : MeromorphicField := f.meromorphic'.choose

/-- The field element's canonical representative is exactly the bundled function. -/
@[simp]
theorem toFun_toMeromorphicField (f : ModularFunction Γ) :
    MeromorphicField.toFun f.toMeromorphicField = f := f.meromorphic'.choose_spec

/-- Modular functions have meromorphic normal form throughout the upper half-plane. -/
theorem meromorphicNFOn (f : ModularFunction Γ) :
    MeromorphicNFOn (f ∘ ofComplex) upperHalfPlaneSet :=
  (MeromorphicField.meromorphicNFOn_iff_exists f).mpr f.meromorphic'

/-- In particular, a modular function is meromorphic at every point of the upper half-plane. -/
theorem meromorphicOn (f : ModularFunction Γ) :
    MeromorphicOn (f ∘ ofComplex) upperHalfPlaneSet := f.meromorphicNFOn.meromorphicOn

/-- Canonical representatives identify modular functions with their ambient field elements. -/
theorem toMeromorphicField_injective :
    Function.Injective (toMeromorphicField (Γ := Γ)) := by
  intro f g h
  apply DFunLike.ext'
  simpa only [toFun_toMeromorphicField] using congrArg MeromorphicField.toFun h

/-- The growth condition of a modular function at a specified cusp. -/
theorem bdd_at_cusps (f : ModularFunction Γ) {c : OnePoint ℝ} (hc : IsCusp c Γ) :
    c.IsOfExponentialGrowthAt f := f.bdd_at_cusps' hc

/-- A modular function is meromorphic at every cusp, in the usual q-coordinate sense. -/
theorem meromorphic_at_cusps [DiscreteTopology Γ] [Γ.HasDetPlusMinusOne]
    (f : ModularFunction Γ) {c : OnePoint ℝ} (hc : IsCusp c Γ) : c.IsMeromorphicAt f :=
  (OnePoint.isOfExponentialGrowthAt_iff_isMeromorphicAt f.toSlashInvariantForm
    f.meromorphicNFOn hc).mp (f.bdd_at_cusps hc)

/-- Meromorphy in any chosen positive-period chart of a cusp. -/
theorem meromorphicAt_cuspFunction (f : ModularFunction Γ) {c : OnePoint ℝ}
    (hc : IsCusp c Γ) {g : GL (Fin 2) ℝ} (hg : g • OnePoint.infty = c)
    {h : ℝ} (hh : 0 < h) (hper : Function.Periodic ((f ∣[(0 : ℤ)] g) ∘ ofComplex) h) :
    MeromorphicAt (cuspFunction h (f ∣[(0 : ℤ)] g)) 0 :=
  (OnePoint.isOfExponentialGrowthAt_iff_meromorphicAt_cuspFunction
    f.meromorphicNFOn hg hh hper).mp (f.bdd_at_cusps hc)

end ModularFunction
