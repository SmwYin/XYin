/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import XYin.PhD.ModularFunctions.JInvariant

/-!
# Modular functions on congruence subgroups

For `Γ₀(N)`, every integral modular transform has period `N`. This relates the period-free
definition of modular functions to the cusp expansions used in classical function-field
arguments, and supplies a constructor from those expansions.
-/

open Complex Function UpperHalfPlane Matrix.SpecialLinearGroup
open scoped MatrixGroups ModularForm

noncomputable section

namespace ModularFunction

/-- Restrict a modular function to a subgroup. Every cusp of the subgroup is also a cusp
of the original group. -/
def restrict {Γ Γ' : Subgroup (GL (Fin 2) ℝ)} (f : ModularFunction Γ) (h : Γ' ≤ Γ) :
    ModularFunction Γ' where
  toFun := f
  slash_action_eq' γ hγ := f.slash_action_eq' γ (h hγ)
  meromorphic' := f.meromorphic'
  bdd_at_cusps' hc := f.bdd_at_cusps (hc.mono h)

@[simp]
theorem coe_restrict {Γ Γ' : Subgroup (GL (Fin 2) ℝ)} (f : ModularFunction Γ) (h : Γ' ≤ Γ) :
    (f.restrict h : ℍ → ℂ) = f := rfl

private lemma periodic_comp_ofComplex_of_vadd {f : ℍ → ℂ} {h : ℝ}
    (hf : ∀ τ, f (h +ᵥ τ) = f τ) : Periodic (f ∘ ofComplex) (h : ℂ) := by
  intro z
  by_cases hz : 0 < z.im
  · have hzadd : 0 < (z + (h : ℂ)).im := by simpa using hz
    simp only [Function.comp_apply, ofComplex_apply_of_im_pos hzadd,
      ofComplex_apply_of_im_pos hz]
    convert hf ⟨z, hz⟩ using 2
    ext
    simp [coe_vadd, add_comm]
  · have hz' : z.im ≤ 0 := le_of_not_gt hz
    have hzadd : (z + (h : ℂ)).im ≤ 0 := by simpa using hz'
    simp [ofComplex_apply_of_im_nonpos hzadd, ofComplex_apply_of_im_nonpos hz']

private lemma conjugate_T_pow_mem_Gamma0 (N : ℕ+) (γ : SL(2, ℤ)) :
    γ * ModularGroup.T ^ (N : ℤ) * γ⁻¹ ∈ CongruenceSubgroup.Gamma0 (N : ℕ) := by
  rw [CongruenceSubgroup.Gamma0_mem]
  have hentry :
      ((γ * ModularGroup.T ^ (N : ℤ) * γ⁻¹ : SL(2, ℤ)) : Matrix (Fin 2) (Fin 2) ℤ) 1 0 =
        -(N : ℤ) * (γ 1 0) ^ 2 := by
    rw [SL2_inv_expl γ]
    change
      (γ.1 * (ModularGroup.T ^ (N : ℤ)).1 *
        (!![γ.1 1 1, -γ.1 0 1; -γ.1 1 0, γ.1 0 0] : Matrix (Fin 2) (Fin 2) ℤ))
          1 0 = _
    rw [ModularGroup.coe_T_zpow]
    simp [Matrix.mul_apply, Fin.sum_univ_two]
    ring
  rw [hentry]
  simp

/-- Every integral modular transform of a weight-zero `Γ₀(N)`-invariant function has period
`N`. No analytic assumptions are needed. -/
theorem periodic_comp_sl2_of_gamma0_invariant (N : ℕ+) {f : ℍ → ℂ}
    (hinv : ∀ γ : CongruenceSubgroup.Gamma0 (N : ℕ), f ∣[(0 : ℤ)] (γ : SL(2, ℤ)) = f)
    (γ : SL(2, ℤ)) : Periodic (fun z : ℂ ↦ f (γ • ofComplex z)) (N : ℂ) := by
  let t : SL(2, ℤ) := ModularGroup.T ^ (N : ℤ)
  let δ : SL(2, ℤ) := γ * t * γ⁻¹
  have hδ : δ ∈ CongruenceSubgroup.Gamma0 (N : ℕ) := conjugate_T_pow_mem_Gamma0 N γ
  have hinv' (τ : ℍ) : f (δ • τ) = f τ := by
    have h := congrFun (hinv ⟨δ, hδ⟩) τ
    simpa only [ModularForm.SL_slash_apply, neg_zero, zpow_zero, mul_one] using h
  have hperiod (τ : ℍ) : f (γ • ((N : ℝ) +ᵥ τ)) = f (γ • τ) := by
    have hT : t • τ = (N : ℝ) +ᵥ τ := by
      simpa only [t, Int.cast_natCast] using modular_T_zpow_smul τ (N : ℤ)
    rw [← hT]
    simpa only [δ, mul_smul, inv_smul_smul] using hinv' (γ • τ)
  simpa only [Function.comp_def, ofReal_natCast] using
    periodic_comp_ofComplex_of_vadd (f := fun τ ↦ f (γ • τ)) hperiod

/-- Every integral modular transform of a `Γ₀(N)` modular function has period `N`. -/
theorem periodic_comp_sl2_gamma0 (N : ℕ+)
    (f : ModularFunction (CongruenceSubgroup.Gamma0 (N : ℕ))) (γ : SL(2, ℤ)) :
    Periodic (fun z : ℂ ↦ f (γ • ofComplex z)) (N : ℂ) := by
  apply periodic_comp_sl2_of_gamma0_invariant N
  intro δ
  exact f.slash_action_eq' _ ⟨δ, δ.property, rfl⟩

/-- The period-`N` cusp expansion of a `Γ₀(N)` modular function is meromorphic at zero. -/
theorem cuspFunction_gamma0 (N : ℕ+)
    (f : ModularFunction (CongruenceSubgroup.Gamma0 (N : ℕ))) (γ : SL(2, ℤ)) :
    MeromorphicAt (cuspFunction (N : ℝ) (fun τ : ℍ ↦ f (γ • τ))) 0 := by
  letI : NeZero (N : ℕ) := ⟨N.ne_zero⟩
  have hc : IsCusp (mapGL ℝ γ • OnePoint.infty)
      (CongruenceSubgroup.Gamma0 (N : ℕ)) :=
    (Subgroup.IsArithmetic.isCusp_iff_isCusp_SL2Z _).mpr
      (isCusp_SL2Z_iff'.mpr ⟨γ, rfl⟩)
  have hslash : ((f : ℍ → ℂ) ∣[(0 : ℤ)] γ) = fun τ : ℍ ↦ f (γ • τ) := by
    ext τ
    simp [ModularForm.SL_slash_apply]
  have hper : Periodic (((f : ℍ → ℂ) ∣[(0 : ℤ)] γ) ∘ ofComplex) (N : ℝ) := by
    simpa only [hslash, Function.comp_def, ofReal_natCast] using periodic_comp_sl2_gamma0 N f γ
  have hf := f.meromorphicAt_cuspFunction hc rfl
    (Nat.cast_pos.mpr N.pos) hper
  change MeromorphicAt (cuspFunction (N : ℝ) ((f : ℍ → ℂ) ∣[(0 : ℤ)] γ)) 0 at hf
  simpa only [hslash] using hf

/-- Construct a `Γ₀(N)` modular function from its canonical meromorphic representative,
invariance, and meromorphic period-`N` expansions at every integral cusp. -/
def ofGamma0CuspData (N : ℕ+) (f : ℍ → ℂ)
    (hf : MeromorphicNFOn (f ∘ ofComplex) upperHalfPlaneSet)
    (hinv : ∀ γ : CongruenceSubgroup.Gamma0 (N : ℕ), f ∣[(0 : ℤ)] (γ : SL(2, ℤ)) = f)
    (hcusp : ∀ γ : SL(2, ℤ),
      MeromorphicAt (cuspFunction (N : ℝ) (fun τ : ℍ ↦ f (γ • τ))) 0) :
    ModularFunction (CongruenceSubgroup.Gamma0 (N : ℕ)) where
  toFun := f
  slash_action_eq' := by
    rintro _ ⟨γ, hγ, rfl⟩
    exact hinv ⟨γ, hγ⟩
  meromorphic' := (MeromorphicField.meromorphicNFOn_iff_exists f).mp hf
  bdd_at_cusps' := by
    intro c hc
    have hc' : IsCusp c 𝒮ℒ := hc.mono (Subgroup.map_le_range ..)
    obtain ⟨γ, hγ⟩ := isCusp_SL2Z_iff'.mp hc'
    apply (OnePoint.isOfExponentialGrowthAt_iff hγ.symm).mpr
    change IsOfExponentialGrowth (f ∣[(0 : ℤ)] γ)
    have hslash : (f ∣[(0 : ℤ)] γ) = fun τ : ℍ ↦ f (γ • τ) := by
      ext τ
      simp [ModularForm.SL_slash_apply]
    rw [hslash]
    apply isOfExponentialGrowth_of_meromorphicAt_cuspFunction (Nat.cast_pos.mpr N.pos)
      (h := (N : ℝ))
    · simpa only [Function.comp_def, ofReal_natCast] using
        periodic_comp_sl2_of_gamma0_invariant N hinv γ
    · exact hcusp γ

@[simp]
theorem coe_ofGamma0CuspData (N : ℕ+) (f : ℍ → ℂ)
    (hf : MeromorphicNFOn (f ∘ ofComplex) upperHalfPlaneSet)
    (hinv : ∀ γ : CongruenceSubgroup.Gamma0 (N : ℕ), f ∣[(0 : ℤ)] (γ : SL(2, ℤ)) = f)
    (hcusp : ∀ γ : SL(2, ℤ),
      MeromorphicAt (cuspFunction (N : ℝ) (fun τ : ℍ ↦ f (γ • τ))) 0) :
    (ofGamma0CuspData N f hf hinv hcusp : ℍ → ℂ) = f := rfl

end ModularFunction
