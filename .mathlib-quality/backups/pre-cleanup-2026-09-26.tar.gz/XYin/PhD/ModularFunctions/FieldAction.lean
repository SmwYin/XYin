/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import Mathlib.Analysis.Calculus.Deriv.Inverse
import Mathlib.Geometry.Manifold.MFDeriv.SpecificFunctions
import XYin.PhD.ModularFunctions.MeromorphicField

/-!
# Holomorphic functions and the modular group action on meromorphic functions

Holomorphic functions on the upper half-plane form a subring of the pointwise function ring
and embed in the field of meromorphic germs. Precomposition by `SL₂(ℤ)` descends to an
automorphism of this field because its action preserves punctured neighborhoods.
-/

open Function MatrixGroups
open scoped Manifold

noncomputable section

namespace UpperHalfPlane

/-- The subring of holomorphic functions on the upper half-plane. -/
def holomorphicFunctions : Subring (ℍ → ℂ) where
  carrier := {f | MDiff f}
  zero_mem' := mdifferentiable_const
  one_mem' := mdifferentiable_const
  add_mem' := fun hf hg ↦ hf.add hg
  neg_mem' := fun hf ↦ hf.neg
  mul_mem' := fun hf hg ↦ hf.mul hg

/-- A holomorphic function on the upper half-plane. -/
abbrev HolomorphicFunction := holomorphicFunctions

/-- The action of an integral determinant-one matrix is holomorphic. -/
lemma sl2_mdifferentiable (delta : SL(2, ℤ)) :
    MDiff (fun tau : ℍ ↦ delta • tau) := by
  simpa only using
    UpperHalfPlane.mdifferentiable_smul (g := (delta : GL (Fin 2) ℝ)) (by simp)

namespace MeromorphicField

/-- Holomorphic functions embed in the field of meromorphic germs. -/
def holomorphicToMeromorphic : HolomorphicFunction →+* MeromorphicField where
  toFun f := MeromorphicField.ofHolomorphic f f.property
  map_one' := rfl
  map_mul' _ _ := rfl
  map_zero' := rfl
  map_add' _ _ := rfl

/-- The canonical representative of a holomorphic germ is its original function. -/
@[simp]
theorem toFun_holomorphicToMeromorphic (f : HolomorphicFunction) :
    MeromorphicField.toFun (holomorphicToMeromorphic f) = f :=
  MeromorphicField.toFun_ofHolomorphic f f.property

theorem holomorphicToMeromorphic_injective : Function.Injective holomorphicToMeromorphic := by
  intro f g h
  apply Subtype.ext
  simpa only [toFun_holomorphicToMeromorphic] using congrArg MeromorphicField.toFun h

instance : Algebra HolomorphicFunction MeromorphicField := holomorphicToMeromorphic.toAlgebra

/-- The embedding of holomorphic functions preserves their values everywhere. -/
@[simp]
theorem toFun_algebraMap (f : HolomorphicFunction) :
    toFun (algebraMap HolomorphicFunction MeromorphicField f) = f :=
  toFun_holomorphicToMeromorphic f

instance : NoZeroDivisors HolomorphicFunction :=
  holomorphicToMeromorphic_injective.noZeroDivisors holomorphicToMeromorphic
    holomorphicToMeromorphic.map_zero holomorphicToMeromorphic.map_mul

private def smulComplex (delta : SL(2, ℤ)) (z : ℂ) : ℂ :=
  (↑(delta • (ofComplex z : ℍ)) : ℂ)

private theorem smulComplex_tendsto (delta : SL(2, ℤ)) :
    Filter.Tendsto (smulComplex delta) (Filter.codiscreteWithin upperHalfPlaneSet)
      (Filter.codiscreteWithin upperHalfPlaneSet) := by
  intro s hs
  apply Filter.eventually_codiscreteWithin_of_forall_eventually_nhdsNE
  intro z hz
  have hs' := (Filter.eventually_codiscreteWithin_iff_forall_eventually_nhdsNE
    isOpen_upperHalfPlaneSet).mp hs (smulComplex delta z) (delta • ofComplex z).im_pos
  have han := (⟨z, hz⟩ : ℍ).analyticAt_smul
    (g := (delta : GL (Fin 2) ℝ)) (by change 0 < (delta : GL (Fin 2) ℝ).det.val; simp)
  have hne := (⟨z, hz⟩ : ℍ).deriv_smul_ne_zero
    (g := (delta : GL (Fin 2) ℝ)) (by change 0 < (delta : GL (Fin 2) ℝ).det.val; simp)
  exact (han.differentiableAt.hasDerivAt.tendsto_nhdsNE hne).eventually hs'

private def precompGerm (delta : SL(2, ℤ)) :
    Filter.Germ (Filter.codiscreteWithin upperHalfPlaneSet) ℂ →+*
      Filter.Germ (Filter.codiscreteWithin upperHalfPlaneSet) ℂ where
  toFun a := a.compTendsto (smulComplex delta) (smulComplex_tendsto delta)
  map_one' := rfl
  map_mul' a b := Filter.Germ.inductionOn₂ a b fun _ _ ↦ rfl
  map_zero' := rfl
  map_add' a b := Filter.Germ.inductionOn₂ a b fun _ _ ↦ rfl

private def precompHom (delta : SL(2, ℤ)) : MeromorphicField →+* MeromorphicField where
  toFun a := ⟨precompGerm delta a.1, by
    obtain ⟨f, hf, hfa⟩ := MeromorphicOn.mem_germRing_iff.mp a.2
    refine MeromorphicOn.mem_germRing_iff.mpr ⟨f ∘ smulComplex delta, ?_, ?_⟩
    · intro z hz
      exact (hf (smulComplex delta z) (delta • ofComplex z).im_pos).comp_analyticAt
        (g := smulComplex delta) (x := z)
        ((⟨z, hz⟩ : ℍ).analyticAt_smul (g := (delta : GL (Fin 2) ℝ))
          (by change 0 < (delta : GL (Fin 2) ℝ).det.val; simp))
    · rw [← hfa]
      rfl⟩
  map_one' := Subtype.ext (precompGerm delta).map_one
  map_mul' a b := Subtype.ext ((precompGerm delta).map_mul a.1 b.1)
  map_zero' := Subtype.ext (precompGerm delta).map_zero
  map_add' a b := Subtype.ext ((precompGerm delta).map_add a.1 b.1)

private theorem precompHom_inv (delta : SL(2, ℤ)) (a : MeromorphicField) :
    precompHom delta⁻¹ (precompHom delta a) = a := by
  apply Subtype.ext
  obtain ⟨f, hf, hfa⟩ := MeromorphicOn.mem_germRing_iff.mp a.2
  change precompGerm delta⁻¹ (precompGerm delta a.1) = a.1
  rw [← hfa]
  apply Filter.Germ.coe_eq.mpr
  filter_upwards [Filter.self_mem_codiscreteWithin upperHalfPlaneSet] with z hz
  simp [smulComplex, Function.comp_def, ofComplex_apply_of_im_pos hz]

/-- Precomposition of meromorphic germs by an element of `SL₂(ℤ)`. -/
def precomp (delta : SL(2, ℤ)) : MeromorphicField ≃+* MeromorphicField where
  __ := precompHom delta
  invFun := precompHom delta⁻¹
  left_inv := precompHom_inv delta
  right_inv a := by simpa using precompHom_inv delta⁻¹ a

/-- Precomposition agrees with composition of holomorphic representatives. -/
@[simp]
theorem precomp_algebraMap (delta : SL(2, ℤ)) (f : HolomorphicFunction) :
    precomp delta (algebraMap HolomorphicFunction MeromorphicField f) =
      algebraMap HolomorphicFunction MeromorphicField
        ⟨fun tau ↦ f.1 (delta • tau), f.property.comp (sl2_mdifferentiable delta)⟩ := by
  apply Subtype.ext
  apply Filter.Germ.coe_eq.mpr
  filter_upwards with z
  change f.1 (ofComplex (smulComplex delta z)) = f.1 (delta • ofComplex z)
  simp [smulComplex]

end MeromorphicField

end UpperHalfPlane
