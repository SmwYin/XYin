/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import Mathlib.Analysis.Complex.UpperHalfPlane.FunctionsBoundedAtInfty
import Mathlib.Analysis.Complex.UpperHalfPlane.Manifold
import Mathlib.Analysis.Meromorphic.NormalForm

/-!
# Exponential growth excludes poles near infinity

A meromorphic function in normal form is analytic wherever it is locally bounded. In particular,
an exponential bound on an upper half-plane excludes poles sufficiently high in the half-plane.
-/

open Filter

open scoped Topology UpperHalfPlane Manifold

/-- A locally bounded meromorphic function in normal form is analytic. -/
lemma MeromorphicNFAt.analyticAt_of_eventually_norm_le {f : ℂ → ℂ} {x : ℂ}
    (hf : MeromorphicNFAt f x) (hbound : ∃ C : ℝ, ∀ᶠ z in 𝓝 x, ‖f z‖ ≤ C) :
    AnalyticAt ℂ f x := by
  apply hf.meromorphicOrderAt_nonneg_iff_analyticAt.mp
  by_contra horder
  have ht := tendsto_cobounded_of_meromorphicOrderAt_neg (lt_of_not_ge horder)
  rw [← tendsto_norm_atTop_iff_cobounded] at ht
  obtain ⟨C, hC⟩ := hbound
  obtain ⟨z, hz, hz'⟩ := ((hC.filter_mono nhdsWithin_le_nhds).and
    (ht.eventually (eventually_gt_atTop C))).exists
  exact (not_lt_of_ge hz) hz'

namespace UpperHalfPlane

/-- An exponential bound excludes poles near infinity for a meromorphic function in normal form. -/
lemma eventually_mdifferentiableAt_of_meromorphicNFOn_of_exponential_bound {f : ℍ → ℂ}
    (hf : MeromorphicNFOn (f ∘ ofComplex) {z : ℂ | 0 < z.im})
    (hbound : ∃ ρ : ℝ, 0 ≤ ρ ∧
      IsBoundedAtImInfty (fun τ ↦ (Real.exp (-ρ * τ.im) : ℂ) * f τ)) :
    ∀ᶠ τ in atImInfty, MDiffAt f τ := by
  obtain ⟨ρ, _, hρ⟩ := hbound
  obtain ⟨M, A, hM⟩ := isBoundedAtImInfty_iff.mp hρ
  apply (atImInfty_mem _).mpr
  refine ⟨A + 1, fun τ hτ ↦ ?_⟩
  apply mdifferentiableAt_iff.mpr
  apply AnalyticAt.differentiableAt
  apply (hf τ.im_pos).analyticAt_of_eventually_norm_le
  have hA : A < τ.im := by linarith
  have hc : ContinuousAt (fun z : ℂ ↦ M / Real.exp (-ρ * z.im)) (τ : ℂ) := by
    exact continuousAt_const.div
      (Real.continuous_exp.continuousAt.comp
        (continuousAt_const.mul Complex.continuous_im.continuousAt)) (Real.exp_ne_zero _)
  refine ⟨M / Real.exp (-ρ * τ.im) + 1, ?_⟩
  filter_upwards [continuousAt_const.eventually_lt Complex.continuous_im.continuousAt hA,
    continuousAt_const.eventually_lt Complex.continuous_im.continuousAt τ.im_pos,
    hc.eventually_lt continuousAt_const (lt_add_one _)] with z hzA hzpos hzbound
  have hz := hM ⟨z, hzpos⟩ hzA.le
  have hz' : ‖f ⟨z, hzpos⟩‖ ≤ M / Real.exp (-ρ * z.im) := by
    apply (le_div_iff₀ (Real.exp_pos _)).mpr
    change ‖(Real.exp (-ρ * z.im) : ℂ) * f ⟨z, hzpos⟩‖ ≤ M at hz
    rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)] at hz
    simpa only [mul_comm] using hz
  simpa [Function.comp_apply, ofComplex_apply_of_im_pos hzpos] using hz'.trans hzbound.le

end UpperHalfPlane
