module

public import Mathlib.NumberTheory.ModularForms.EisensteinSeries.E2.Transform
public import XYin.PhD.Modularforms.SlashActionAuxil

@[expose] public section

open ModularForm UpperHalfPlane TopologicalSpace Set MeasureTheory intervalIntegral
  Metric Filter Function Complex MatrixGroups
open ArithmeticFunction

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat
open scoped ArithmeticFunction.sigma

noncomputable section

/-- Compatibility alias for Mathlib's `EisensteinSeries.G2`. -/
def G₂ : ℍ → ℂ := EisensteinSeries.G2

/-- Compatibility alias for Mathlib's `EisensteinSeries.E2`. -/
def E₂ : ℍ → ℂ := EisensteinSeries.E2

/-- Compatibility alias for Mathlib's `EisensteinSeries.D2`. -/
def D₂ (γ : SL(2, ℤ)) : ℍ → ℂ := EisensteinSeries.D2 γ

lemma D₂_apply (γ : SL(2, ℤ)) (z : ℍ) :
    D₂ γ z = (2 * π * Complex.I * γ 1 0) / (γ 1 0 * z + γ 1 1) := by
  rfl

lemma D2_one : D₂ 1 = 0 := by
  ext z
  simp [D₂]

lemma D2_mul (A B : SL(2, ℤ)) : D₂ (A * B) = ((D₂ A) ∣[(2 : ℤ)] B) + (D₂ B) := by
  simpa [D₂] using (EisensteinSeries.D2_mul A B)

lemma D2_inv (A : SL(2, ℤ)) : (D₂ A) ∣[(2 : ℤ)] A⁻¹ = -D₂ (A⁻¹) := by
  simpa [D₂] using (EisensteinSeries.D2_inv A)

lemma D2_T : D₂ ModularGroup.T = 0 := by
  simpa [D₂] using (EisensteinSeries.D2_T)

lemma D2_S (z : ℍ) : D₂ ModularGroup.S z = 2 * (π : ℂ) * Complex.I / z :=
  EisensteinSeries.D2_S z

lemma G2_q_exp (z : ℍ) : G₂ z = (2 * riemannZeta 2) - 8 * π ^ 2 *
    ∑' n : ℕ+, sigma 1 n * cexp (2 * π * Complex.I * n * z) := by
  simpa [G₂, ← Complex.exp_nat_mul, mul_assoc, mul_comm, mul_left_comm] using
    EisensteinSeries.G2_eq_tsum_cexp z

lemma G2_periodic : (G₂ ∣[(2 : ℤ)] ModularGroup.T) = G₂ := by
  simpa [G₂] using (EisensteinSeries.G2_T_transform)

lemma G₂_transform (γ : SL(2, ℤ)) : (G₂ ∣[(2 : ℤ)] γ) = G₂ - (D₂ γ) := by
  simpa [G₂, D₂] using (EisensteinSeries.G2_slash_action γ)

/-- E₂ is 1-periodic: E₂(z + 1) = E₂(z). -/
lemma E₂_periodic (z : ℍ) : E₂ ((1 : ℝ) +ᵥ z) = E₂ z := by
  have h := congrFun (EisensteinSeries.E2_slash_action ModularGroup.T) z
  rw [modular_slash_T_apply] at h
  simpa [E₂, EisensteinSeries.D2_T] using h

lemma E₂_transform (z : ℍ) : (E₂ ∣[(2 : ℤ)] ModularGroup.S) z =
    E₂ z + 6 / (π * Complex.I * z) := by
  have h := congrFun (EisensteinSeries.E2_slash_action ModularGroup.S) z
  have h' : (E₂ ∣[(2 : ℤ)] ModularGroup.S) z =
      E₂ z - (1 / (2 * riemannZeta 2)) * (2 * π * Complex.I / z) := by
    simpa [E₂, EisensteinSeries.D2_S, smul_eq_mul] using h
  rw [riemannZeta_two] at h'
  have hpi : (π : ℂ) ≠ 0 := by simp
  have hI : (Complex.I : ℂ) ≠ 0 := Complex.I_ne_zero
  have hz : (z : ℂ) ≠ 0 := ne_zero z
  calc
    (E₂ ∣[(2 : ℤ)] ModularGroup.S) z =
        E₂ z - 1 / (2 * (π ^ 2 / (6 : ℂ))) * (2 * π * Complex.I / z) := h'
    _ = E₂ z + 6 / (π * Complex.I * z) := by
      field_simp [hpi, hI, hz]
      ring_nf
      simp [Complex.I_sq, add_comm]

/-- E₂ transforms under SL(2,ℤ) as: E₂ ∣[2] γ = E₂ - α • D₂ γ where α = 1/(2ζ(2)). -/
lemma E₂_slash_transform (γ : SL(2, ℤ)) :
    (E₂ ∣[(2 : ℤ)] γ) = E₂ - (1 / (2 * riemannZeta 2)) • D₂ γ := by
  simpa [E₂, D₂] using (EisensteinSeries.E2_slash_action γ)

/-- E₂ transforms under S as: E₂(-1/z) = z² · (E₂(z) + 6/(πIz)). -/
lemma E₂_S_transform (z : ℍ) :
    E₂ (ModularGroup.S • z) = z ^ 2 * (E₂ z + 6 / (π * Complex.I * z)) := by
  have h := E₂_transform z
  rw [SL_slash_apply, ModularGroup.denom_S, zpow_neg, zpow_two] at h
  simpa [sq, mul_comm] using (mul_inv_eq_iff_eq_mul₀ (mul_ne_zero z.ne_zero z.ne_zero)).mp h

lemma tsum_eq_tsum_sigma (z : ℍ) : ∑' n : ℕ, (n + 1) *
    cexp (2 * π * Complex.I * (n + 1) * z) / (1 - cexp (2 * π * Complex.I * (n + 1) * z)) =
    ∑' n : ℕ, sigma 1 (n + 1) * cexp (2 * π * Complex.I * (n + 1) * z) := by
  have h := tsum_pow_div_one_sub_eq_tsum_sigma (UpperHalfPlane.norm_exp_two_pi_I_lt_one z) 1
  rw [tsum_pnat_eq_tsum_succ (f := fun n : ℕ ↦
      (n : ℂ) ^ 1 * cexp (2 * π * Complex.I * z) ^ n /
        (1 - cexp (2 * π * Complex.I * z) ^ n)),
    tsum_pnat_eq_tsum_succ (f := fun n : ℕ ↦
      (sigma 1 n : ℂ) * cexp (2 * π * Complex.I * z) ^ n)] at h
  simpa [← Complex.exp_nat_mul, Nat.cast_add, Nat.cast_one, mul_assoc, mul_comm, mul_left_comm] using h

lemma E₂_eq (z : UpperHalfPlane) : E₂ z =
    1 - 24 * ∑' n : ℕ+, ↑n * cexp (2 * π * Complex.I * n * z) /
                        (1 - cexp (2 * π * Complex.I * n * z)) := by
  rw [E₂, EisensteinSeries.E2_eq_tsum_cexp,
    ← tsum_pow_div_one_sub_eq_tsum_sigma (UpperHalfPlane.norm_exp_two_pi_I_lt_one z) 1]
  simp [← Complex.exp_nat_mul, mul_assoc, mul_comm, mul_left_comm]
