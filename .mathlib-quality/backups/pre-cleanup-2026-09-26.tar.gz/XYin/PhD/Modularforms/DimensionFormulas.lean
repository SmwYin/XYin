/-
Copyright (c) 2026 SmwYin. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: SmwYin
-/
module

public import Mathlib.Algebra.Order.Floor.Semifield
public import Mathlib.Data.Rat.Star
public import Mathlib.LinearAlgebra.Dimension.Localization
public import Mathlib.NumberTheory.ModularForms.LevelOne.GradedRing
public import XYin.PhD.Modularforms.Eisenstein

/-!
# Dimension formulas for modular forms

This file relates cusp forms to modular forms of weight twelve less by division by the
modular discriminant. It contains the project's dimension-formula development, including
weight-two vanishing, which follows from mathlib's level-one dimension theory.
-/

@[expose] public section

open ModularForm hiding E₄ E₆
open EisensteinSeries UpperHalfPlane TopologicalSpace Set MeasureTheory intervalIntegral
  Metric Filter Function Complex MatrixGroups SlashInvariantFormClass ModularFormClass

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat
  Real MatrixGroups CongruenceSubgroup

noncomputable section

-- Keep the determinant-one instance bound while transporting the level subgroup.
private lemma modularForm_rank_gamma_one (k : ℤ) : Module.rank ℂ (ModularForm Γ(1) k) =
    Module.rank ℂ (ModularForm 𝒮ℒ k) := by
  have h (G : Subgroup (GL (Fin 2) ℝ)) [G.HasDetOne] (hG : G = 𝒮ℒ) :
      Module.rank ℂ (ModularForm G k) = Module.rank ℂ (ModularForm 𝒮ℒ k) := by
    subst G
    rfl
  exact h _ CongruenceSubgroup.Gamma_one_coe_eq_SL

private lemma cuspForm_rank_gamma_one (k : ℤ) : Module.rank ℂ (CuspForm Γ(1) k) =
    Module.rank ℂ (CuspForm 𝒮ℒ k) := by
  have h (G : Subgroup (GL (Fin 2) ℝ)) [G.HasDetOne] (hG : G = 𝒮ℒ) :
      Module.rank ℂ (CuspForm G k) = Module.rank ℂ (CuspForm 𝒮ℒ k) := by
    subst G
    rfl
  exact h _ CongruenceSubgroup.Gamma_one_coe_eq_SL

def mul_Delta_map (k : ℤ) (f : ModularForm (CongruenceSubgroup.Gamma 1) (k - 12)) :
    ModularForm (CongruenceSubgroup.Gamma 1) k := by
  have := (f.mul (ModForm_mk _ 12 Delta))
  have hk : k - 12 + 12 = k := by ring
  exact ModularForm.mcast hk this

lemma mcast_apply {a b : ℤ} {Γ : Subgroup SL(2, ℤ)} (h : a = b) (f : ModularForm Γ a) (z : ℍ) :
  (ModularForm.mcast h f) z = f z := by
  rfl

lemma mul_Delta_map_eq (k : ℤ) (f : ModularForm (CongruenceSubgroup.Gamma 1) (k - 12)) (z : ℍ) :
  (mul_Delta_map k f) z = f z * Delta z := by
  rfl

lemma mul_Delta_map_eq_mul (k : ℤ) (f : ModularForm (CongruenceSubgroup.Gamma 1) (k - 12)) :
  ((mul_Delta_map k f) : ℍ → ℂ) = (f.mul (ModForm_mk _ 12 Delta)) := by
  rfl

lemma qExpansion_coe_smul {n : ℕ} [NeZero n] {k : ℤ} (a : ℂ) (f : ModularForm Γ(n) k) :
    qExpansion n (⇑(a • f)) = qExpansion n (a • ⇑f) := rfl

lemma qExpansion_coe_smul_cusp {n : ℕ} [NeZero n] {k : ℤ} (a : ℂ) (f : CuspForm Γ(n) k) :
    qExpansion n (⇑(a • f)) = qExpansion n (a • ⇑f) := rfl

lemma qExpansion_coe_sub {k : ℤ} (f g : ModularForm Γ(1) k) :
    qExpansion (1 : ℕ) (⇑(f - g)) = qExpansion (1 : ℕ) (⇑f - ⇑g) := rfl

lemma mul_Delta_IsCuspForm (k : ℤ) (f : ModularForm (CongruenceSubgroup.Gamma 1) (k - 12)) :
  IsCuspForm (CongruenceSubgroup.Gamma 1) k (mul_Delta_map k f) := by
  change mul_Delta_map k f ∈ LinearMap.range (CuspForm_to_ModularForm Γ(1) k)
  refine ⟨CuspForm.mcast (by ring) (Delta.mulModularForm f), ?_⟩
  ext z
  simpa only [mul_Delta_map_eq] using mul_comm (Delta z) (f z)

def Modform_mul_Delta' (k : ℤ) (f : ModularForm (CongruenceSubgroup.Gamma 1) (k - 12)) :
    CuspForm (CongruenceSubgroup.Gamma 1) k :=
  IsCuspForm_to_CuspForm _ k (mul_Delta_map k f) (mul_Delta_IsCuspForm k f)

theorem SlashInvariantForm.mul_apply {k₁ k₂ : ℤ} {Γ : Subgroup SL(2, ℤ)}
    (f : SlashInvariantForm Γ k₁) (g : SlashInvariantForm Γ k₂) (z : ℍ) :
    (f.mul g) z = f z * g z := rfl

lemma Modform_mul_Delta_apply (k : ℤ) (f : ModularForm (CongruenceSubgroup.Gamma 1) (k - 12))
    (z : ℍ) : (Modform_mul_Delta' k f) z = f z * Delta z := by
  exact (congrFun
    (CuspForm_to_ModularForm_Fun_coe _ _ (mul_Delta_map k f) (mul_Delta_IsCuspForm k f)) z).trans
      (mul_Delta_map_eq k f z)

def CuspForms_iso_Modforms (k : ℤ) : CuspForm (CongruenceSubgroup.Gamma 1) k ≃ₗ[ℂ]
    ModularForm (CongruenceSubgroup.Gamma 1) (k - 12) where
      toFun f := CuspForm_div_Discriminant k f
      map_add' a b := CuspForm_div_Discriminant_Add k a b
      map_smul' := by
        intro m a
        ext z
        simp only [CuspForm_div_Discriminant_apply, CuspForm.IsGLPos.smul_apply, smul_eq_mul,
          RingHom.id_apply, IsGLPos.smul_apply]
        exact mul_div_assoc m (a z) (Δ z)
      invFun := Modform_mul_Delta' k
      left_inv := by
        intro f
        ext z
        simpa only [Modform_mul_Delta_apply, CuspForm_div_Discriminant_apply, Delta_apply] using
          div_mul_cancel₀ (f z) (Δ_ne_zero z)
      right_inv := by
        intro f
        ext z
        simpa only [Modform_mul_Delta_apply, CuspForm_div_Discriminant_apply, Delta_apply] using
          mul_div_cancel_right₀ (f z) (Δ_ne_zero z)

theorem Delta_E4_eqn : Delta = Delta_E4_E6_aux := by
  ext z
  rw [show Delta z = ModularForm.discriminant z from Delta_eq_eta_pow z,
    ModularForm.discriminant_eq_E₄_cube_sub_E₆_sq]
  symm
  change (((1 / 1728 : ℂ) • (((DirectSum.of (ModularForm Γ(1)) 4 E₄)^3 -
    (DirectSum.of (ModularForm Γ(1)) 6 E₆)^2) 12)) z) = _
  simp only [ModularForm.directSum_of_pow, Nat.cast_ofNat, Int.reduceMul, DirectSum.sub_apply]
  change (1 / 1728 : ℂ) * (E₄ z ^ 3 - E₆ z ^ 2) = (E₄ z ^ 3 - E₆ z ^ 2) / 1728
  ring

lemma delta_eq_E4E6_const : ∃ (c : ℂ), (c • Delta) = Delta_E4_E6_aux := by
  exact ⟨1, by simpa using Delta_E4_eqn⟩

lemma cuspform_weight_lt_12_zero (k : ℤ) (hk : k < 12) : Module.rank ℂ (CuspForm Γ(1) k) = 0 := by
  exact (cuspForm_rank_gamma_one k).trans (CuspForm.rank_eq_zero_of_weight_lt_twelve hk)

lemma IsCuspForm_weight_lt_eq_zero (k : ℤ) (hk : k < 12) (f : ModularForm Γ(1) k)
    (hf : IsCuspForm Γ(1) k f) : f = 0 := by
  change f ∈ LinearMap.range (CuspForm_to_ModularForm Γ(1) k) at hf
  obtain ⟨g, rfl⟩ := hf
  rw [rank_zero_iff_forall_zero.mp (cuspform_weight_lt_12_zero k hk) g, map_zero]

lemma Delta_E4_E6_eq : ModForm_mk _ _ Delta_E4_E6_aux =
  ((1/ 1728 : ℂ) • (((DirectSum.of _ 4 E₄)^3 - (DirectSum.of _ 6 E₆)^2) 12 )) := by
  ext
  rfl

lemma Delta_E4_E6_aux_q_one_term : (qExpansion 1 Delta_E4_E6_aux).coeff 1 = 1 := by
  rw [← Delta_E4_eqn]
  exact Delta_q_one_term

lemma weight_six_one_dimensional : Module.rank ℂ (ModularForm Γ(1) 6) = 1 := by
  exact (modularForm_rank_gamma_one 6).trans ModularForm.levelOne_weight_six_rank_one

lemma weight_four_one_dimensional : Module.rank ℂ (ModularForm Γ(1) 4) = 1 := by
  exact (modularForm_rank_gamma_one 4).trans ModularForm.levelOne_weight_four_rank_one

lemma weight_eight_one_dimensional (k : ℕ) (hk : 3 ≤ (k : ℤ)) (hk2 : Even k) (hk3 : k < 12) :
    Module.rank ℂ (ModularForm Γ(1) k) = 1 := by
  rw [modularForm_rank_gamma_one, ModularForm.dimension_level_one k hk2]
  have hmod : ¬ k ≡ 2 [MOD 12] := by simp only [Nat.ModEq]; omega
  simp [hmod, Nat.div_eq_of_lt hk3]

lemma weight_two_zero (f : ModularForm (CongruenceSubgroup.Gamma 1) 2) : f = 0 := by
  have h := rank_zero_iff_forall_zero.mp ModularForm.levelOne_weight_two_rank_zero
  rw [← CongruenceSubgroup.Gamma_one_coe_eq_SL] at h
  exact h f

lemma dim_modforms_eq_one_add_dim_cuspforms (k : ℕ) (hk : 3 ≤ (k : ℤ)) (hk2 : Even k) :
    Module.rank ℂ (ModularForm (CongruenceSubgroup.Gamma 1) k) =
    1 + Module.rank ℂ (CuspForm (CongruenceSubgroup.Gamma 1) k) := by
  rw [modularForm_rank_gamma_one, cuspForm_rank_gamma_one]
  exact ModularForm.rank_eq_one_add_rank_cuspForm (by omega) hk2

theorem dim_weight_two : Module.rank ℂ (ModularForm Γ(1) ↑2) = 0 := by
  exact rank_zero_iff_forall_zero.mpr weight_two_zero

lemma floor_lem1 (k a : ℚ) (ha : 0 < a) (hak : a ≤ k) :
    1 + Nat.floor ((k - a) / a) = Nat.floor (k / a) := by
  rw [div_sub_same ha.ne', Nat.floor_sub_one]
  exact Nat.add_sub_cancel' (Nat.le_floor ((le_div_iff₀ ha).mpr (by simpa using hak)))

lemma dim_modforms_lvl_one (k : ℕ) (hk : 3 ≤ (k : ℤ)) (hk2 : Even k) :
    Module.rank ℂ (ModularForm (CongruenceSubgroup.Gamma 1) (k)) = if 12 ∣ ((k) : ℤ) - 2 then
    Nat.floor ((k : ℚ)/ 12) else Nat.floor ((k : ℚ) / 12) + 1 := by
  rw [modularForm_rank_gamma_one, ModularForm.dimension_level_one k hk2]
  have hmod : k ≡ 2 [MOD 12] ↔ (12 : ℤ) ∣ (k : ℤ) - 2 := by
    simp only [Nat.ModEq]
    omega
  have hfloor : Nat.floor ((k : ℚ) / 12) = k / 12 := Nat.floor_div_eq_div k 12
  simp only [hmod, hfloor]

lemma ModularForm.dimension_level_one_XYin (k : ℕ) (hk : 3 ≤ (k : ℤ)) (hk2 : Even k) :
    Module.rank ℂ (ModularForm (CongruenceSubgroup.Gamma 1) (k)) = if 12 ∣ ((k) : ℤ) - 2 then
    Nat.floor ((k : ℚ)/ 12) else Nat.floor ((k : ℚ) / 12) + 1 := by
  apply dim_modforms_lvl_one k hk hk2

lemma dim_gen_cong_levels (k : ℤ) (Γ : Subgroup SL(2, ℤ)) (hΓ : Subgroup.index Γ ≠ 0) :
    FiniteDimensional ℂ (ModularForm Γ k) := by sorry
--use the norm to turn it into a level one question.
