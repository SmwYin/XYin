/-
Copyright (c) 2026 SmwYin. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: SmwYin
-/
module

public import Mathlib.Analysis.Normed.Module.FiniteDimension
public import Mathlib.LinearAlgebra.Complex.FiniteDimensional
public import XYin.PhD.Modularforms.exp_lems
public import XYin.PhD.Modularforms.equivs

/-!
# Summation indices and exponential series

Summation over integers and positive naturals, geometric and exponential summability,
and reindexing by divisor antidiagonals. These lemmas were split from `summable_lems`.
-/

@[expose] public section

open UpperHalfPlane TopologicalSpace Set Metric Filter Function Complex ArithmeticFunction

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat

theorem int_sum_neg {α : Type*} [AddCommMonoid α] [TopologicalSpace α] [T2Space α] (f : ℤ → α) :
  ∑' d : ℤ, f d = ∑' d, f (-d) := by
  exact (negEquiv.tsum_eq f).symm

theorem summable_neg {α : Type*} [TopologicalSpace α] [AddCommMonoid α] (f : ℤ → α)
    (hf : Summable f) : Summable fun d => f (-d) := by
  exact negEquiv.summable_iff.mpr hf

lemma aux33 (f : ℕ → ℂ) (hf : Summable f) : ∑' n, f (n) =
    limUnder atTop (fun N : ℕ => ∑ n ∈ Finset.range N, f (n)) := by
  exact (hf.hasSum.comp tendsto_finset_range).limUnder_eq.symm

/- this is being Pr'd-/
lemma tsum_pnat_eq_tsum_succ3 {α : Type*} [TopologicalSpace α] [AddCommMonoid α] [T2Space α]
  (f : ℕ → α) : ∑' (n : ℕ+), f ↑n = ∑' (n : ℕ), f (n + 1) := by
  apply tsum_pnat_eq_tsum_succ



theorem nat_pos_tsum2 {α : Type _} [TopologicalSpace α] [AddCommMonoid α]
    (f : ℕ → α) (hf : f 0 = 0) : (Summable fun x : ℕ+ => f x) ↔ Summable f := by
  apply PNat.coe_injective.summable_iff
  intro n hn
  have hn0 : n = 0 := by
    by_contra h
    exact hn ⟨⟨n, Nat.pos_of_ne_zero h⟩, rfl⟩
  simpa [hn0] using hf

theorem tsum_pNat {α : Type _} [AddCommGroup α] [UniformSpace α] [IsUniformAddGroup α] [T2Space α]
  [CompleteSpace α] (f : ℕ → α) (hf : f 0 = 0) : ∑' n : ℕ+, f n = ∑' n, f n := by
  apply PNat.coe_injective.tsum_eq
  intro n hn
  exact ⟨⟨n, Nat.pos_of_ne_zero (fun h ↦ hn (h ▸ hf))⟩, rfl⟩

lemma tsum_pnat_eq_tsum_succ4 {α : Type*} [TopologicalSpace α] [AddCommGroup α]
    [IsTopologicalAddGroup α] [T2Space α]
  (f : ℕ → α) (hf : Summable f) : f 0 + ∑' (n : ℕ+), f ↑n = ∑' (n : ℕ), f n := by
  exact tsum_zero_pnat_eq_tsum_nat hf

/-- Closed form for ∑ n·rⁿ over ℕ+ when ‖r‖ < 1. -/
lemma tsum_pnat_coe_mul_geometric {r : ℝ} (hr : ‖r‖ < 1) :
    (∑' n : ℕ+, (n : ℝ) * r ^ (n : ℕ)) = r / (1 - r) ^ 2 := by
  rw [tsum_pNat (f := fun n => (n : ℝ) * r ^ n) (by simp)]
  exact tsum_coe_mul_geometric_of_norm_lt_one hr

theorem nat_pos_tsum2' {α : Type*} [TopologicalSpace α] [AddCommMonoid α] (f : ℕ → α) :
    (Summable fun x : ℕ+ => f x) ↔ Summable fun x : ℕ => f (x + 1) := by
  exact summable_pnat_iff_summable_succ

theorem int_nat_sum {α : Type*} [AddCommGroup α] [UniformSpace α] [IsUniformAddGroup α]
  [CompleteSpace α]
  (f : ℤ → α) : Summable f → Summable fun x : ℕ => f x := by
  exact fun hf ↦ hf.comp_injective Nat.cast_injective

theorem HasSum.nonneg_add_neg {α : Type*} [TopologicalSpace α] [AddCommGroup α]
    [IsTopologicalAddGroup α] [T2Space α] {a b : α} {f : ℤ → α} (hnonneg : HasSum (fun n : ℕ => f n)
      a)
    (hneg : HasSum (fun n : ℕ => f (-n.succ)) b) : HasSum f (a + b) := by
  convert hnonneg.int_rec hneg using 1
  ext (i | j) <;> rfl


theorem HasSum.pos_add_zero_add_neg {α : Type*} [TopologicalSpace α] [AddCommGroup α]
    [IsTopologicalAddGroup α] [T2Space α] {a b : α} {f : ℤ → α} (hpos : HasSum (fun n : ℕ => f (n +
      1)) a)
    (hneg : HasSum (fun n : ℕ => f (-n.succ)) b) : HasSum f (a + f 0 + b) := by
  apply HasSum.nonneg_add_neg (b := b) _ hneg
  simpa using (hasSum_nat_add_iff (f := fun n : ℕ ↦ f n) 1).mp hpos

theorem sum_int_even {α : Type*} [UniformSpace α] [CommRing α] [IsUniformAddGroup α]
    [CompleteSpace α] [T2Space α] (f : ℤ → α) (hf : ∀ n : ℤ, f n = f (-n)) (hf2 : Summable f) :
    ∑' n, f n = f 0 + 2 * ∑' n : ℕ+, f n := by
  simpa only [nsmul_eq_mul] using
    tsum_int_eq_zero_add_two_mul_tsum_pnat (fun n ↦ (hf n).symm) hf2

theorem sigma_eq_sum_div' (k n : ℕ) : sigma k n = ∑ d ∈ Nat.divisors n, (n / d) ^ k :=
  by
  simp only [sigma, ArithmeticFunction.coe_mk]
  rw [← Nat.sum_div_divisors]


theorem a33 (k : ℕ) (e : ℕ+) (z : ℍ) :
    Summable fun c : ℕ+ => (c : ℂ) ^ k * exp (2 * ↑π * Complex.I * e * ↑z * c) := by
  have hr : ‖cexp (2 * ↑π * Complex.I * e * z)‖ < 1 := by
    have h := exp_upperHalfPlane_lt_one_nat z e.natPred
    rw [← Nat.cast_add_one, e.natPred_add_one] at h
    simpa [mul_assoc, mul_comm, mul_left_comm] using h
  apply ((summable_pow_mul_geometric_of_norm_lt_one k hr).subtype (fun n ↦ 0 < n)).congr
  intro n
  dsimp only [Function.comp_def]
  rw [← Complex.exp_nat_mul]
  change (n.val : ℂ) ^ k * cexp ((n.val : ℂ) * (2 * ↑π * Complex.I * e * z)) =
    (n.val : ℂ) ^ k * cexp (2 * ↑π * Complex.I * e * z * (n.val : ℂ))
  congr 2
  ring

lemma hsum (k : ℕ) (z : ℍ) : Summable fun b : ℕ+ => ∑ _ ∈ (b : ℕ).divisors, b ^ k *
    ‖exp (2 * ↑π * Complex.I * ↑z * b)‖ := by
    simp only [Finset.sum_const, nsmul_eq_mul]
    have hs := summable_norm_iff.mpr (a33 (k+1) 1 z)
    apply Summable.of_nonneg_of_le _ _ hs
    · simp only [Nat.cast_pos, Finset.card_pos, Nat.nonempty_divisors, ne_eq, PNat.ne_zero,
        not_false_eq_true, mul_nonneg_iff_of_pos_left, PNat.pos, pow_pos, norm_nonneg, implies_true]
    intro b
    simp only [PNat.val_ofNat, Nat.cast_one, mul_one, Complex.norm_mul, norm_pow,
      Complex.norm_natCast]
    rw [← mul_assoc]
    gcongr
    rw [pow_add, mul_comm]
    gcongr
    simpa using Nat.card_divisors_le_self (b : ℕ)

theorem summable_auxil_1 (k : ℕ) (z : ℍ) :
  Summable fun c : (n : ℕ+) × { x // x ∈ (n : ℕ).divisorsAntidiagonal } ↦
  ↑(↑(c.snd) : ℕ × ℕ).1 ^ k *
    cexp (2 * ↑π * Complex.I * ↑z * ↑(↑(c.snd) : ℕ × ℕ).1 * ↑↑(↑(c.snd) : ℕ × ℕ).2) := by
  have hs := (summable_prod_mul_pow k (exp_upperHalfPlane_lt_one z)).prod_symm
  have ht := sigmaAntidiagonalEquivProd.summable_iff.mpr hs
  simpa [Function.comp_def, sigmaAntidiagonalEquivProd, divisorsAntidiagonalFactors,
    ← Complex.exp_nat_mul, mul_assoc, mul_comm, mul_left_comm] using ht

lemma sum_range_zero (f : ℤ → ℂ) (n : ℕ) : ∑ m ∈ Finset.range (n+1), f m = f 0 +
  ∑ m ∈ Finset.range n, f (m+1) := by
  simpa [add_comm] using Finset.sum_range_succ' (fun m : ℕ ↦ f m) n

theorem tsum_sigma_eqn2 (k : ℕ) (z : ℍ) :
    ∑' (c : Fin 2 → ℕ+), (c 0 ^ k : ℂ) * Complex.exp (2 * ↑π * Complex.I * z * c 0 * c 1) =
      ∑' e : ℕ+, sigma k e * Complex.exp (2 * ↑π * Complex.I * z * e) := by
  rw [← (piFinTwoEquiv fun _ ↦ ℕ+).symm.tsum_eq]
  have hs := summable_prod_mul_pow k (exp_upperHalfPlane_lt_one z)
  simpa [← hs.tsum_prod, ← Complex.exp_nat_mul, mul_assoc, mul_comm, mul_left_comm]
    using ((Equiv.prodComm ℕ+ ℕ+).tsum_eq
      (fun c : ℕ+ × ℕ+ ↦ (c.2 : ℂ) ^ k * cexp (2 * ↑π * Complex.I * z) ^
        (c.1 * c.2 : ℕ))).trans
          (hs.tsum_prod.trans (tsum_prod_pow_eq_tsum_sigma k (exp_upperHalfPlane_lt_one z)))

/-This is proven in the modular forms repo. -/
theorem tsum_sigma_eqn {k : ℕ} (z : ℍ) :
    ∑' c : ℕ+ × ℕ+, (c.1 ^ k : ℂ) * Complex.exp (2 * ↑π * Complex.I * z * c.1 * c.2) =
      ∑' e : ℕ+, sigma k e * Complex.exp (2 * ↑π * Complex.I * e * z) := by
  rw [← (piFinTwoEquiv fun _ => ℕ+).tsum_eq]
  have := tsum_sigma_eqn2 k z
  simp only [piFinTwoEquiv_apply, Fin.isValue]
  grind

lemma exp_aux (z : ℍ) (n : ℕ) : cexp (2 * ↑π * Complex.I * n * ↑z) =
    cexp (2 * ↑π * Complex.I * ↑z) ^ n := by
  rw [← Complex.exp_nat_mul]
  congr 1
  ring

theorem summable_exp_pow (z : ℍ) : Summable fun i : ℕ ↦
     ‖(cexp (2 * ↑π * Complex.I * (↑i + 1) * z))‖ := by
  simpa [Function.comp_def, ← norm_pow, ← Complex.exp_nat_mul,
    Nat.cast_add, Nat.cast_one, mul_assoc, mul_comm, mul_left_comm] using
    (summable_geometric_of_norm_lt_one
      (by simpa using exp_upperHalfPlane_lt_one z : ‖‖cexp (2 * ↑π * Complex.I * z)‖‖ < 1)).comp_injective Nat.succ_injective

/-This is straight from the mod forms repo-/
theorem a1 (k : ℕ) (e : ℕ+) (z : ℍ) :
    Summable fun c : ℕ => (e : ℂ) ^ (k - 1) * exp (2 * ↑π * Complex.I * ↑z * e * c) := by
  have hr : ‖cexp (2 * ↑π * Complex.I * z * e)‖ < 1 := by
    have h := exp_upperHalfPlane_lt_one_nat z e.natPred
    rw [← Nat.cast_add_one, e.natPred_add_one] at h
    simpa [mul_assoc, mul_comm, mul_left_comm] using h
  simpa [← Complex.exp_nat_mul, mul_comm, mul_left_comm] using
    (summable_geometric_of_norm_lt_one hr).mul_left ((e : ℂ) ^ (k - 1))

theorem a4 (k : ℕ) (z : ℍ) :
    Summable (uncurry fun b c : ℕ+ => ↑b ^ (k - 1) * exp (2 * ↑π * Complex.I * ↑c * ↑z * ↑b)) := by
  rw [sigmaAntidiagonalEquivProd.summable_iff.symm]
  simp only [sigmaAntidiagonalEquivProd, divisorsAntidiagonalFactors, PNat.mk_coe, Equiv.coe_fn_mk]
  apply (summable_auxil_1 (k - 1) z).congr
  intro b
  simp only [comp_apply, uncurry_apply_pair, PNat.mk_coe, mul_eq_mul_left_iff, pow_eq_zero_iff',
    Nat.cast_eq_zero, ne_eq]
  left
  ring_nf

lemma summable_pnats (f : ℕ → ℂ) : Summable (fun n : ℕ+ => f n) ↔ Summable f := by
  rw [nat_pos_tsum2', summable_nat_add_iff]
