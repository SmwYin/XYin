/-
Copyright (c) 2026 SmwYin. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: SmwYin
-/
module

public import Mathlib.NumberTheory.ModularForms.EisensteinSeries.E2.Summable
public import XYin.PhD.Modularforms.Summability.Basic
public import XYin.PhD.Modularforms.BigO
public import XYin.PhD.Modularforms.upperhalfplane

/-!
# Summability of reciprocal lattice terms

Paired reciprocal sums, denominator estimates on the upper half-plane, and summable
corrections to weight-two Eisenstein sums. These lemmas were split from `summable_lems`.
-/

@[expose] public section

open ModularForm EisensteinSeries UpperHalfPlane TopologicalSpace Set
  Metric Filter Function Complex ArithmeticFunction

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat

theorem upp_half_not_ints (z : ℍ) (n : ℤ) : (z : ℂ) ≠ n := by
  exact z.ne_intCast n

lemma aus (a b : ℂ) : a + b ≠ 0 ↔ a ≠ -b := by
  exact (eq_neg_iff_add_eq_zero).symm.not

lemma pnat_inv_sub_squares (z : ℍ) :
  (fun n : ℕ+ => 1 / ((z : ℂ) - n) + 1 / (z + n)) =
    fun n : ℕ+ => 2 * z.1 * (1 / (z ^ 2 - n ^ 2)) := by
  funext n
  have hsub : (z : ℂ) - n ≠ 0 := sub_ne_zero.mpr (by exact z.ne_intCast n)
  have hadd : (z : ℂ) + n ≠ 0 := by
    simpa [add_eq_zero_iff_eq_neg] using z.ne_intCast (-(n : ℤ))
  rw [sq_sub_sq]
  field_simp
  ring

lemma upper_half_plane_ne_int_pow_two (z : ℍ) (n : ℤ) : (z : ℂ) ^ 2 - n ^ 2 ≠ 0 := by
  rw [sq_sub_sq, mul_ne_zero_iff]
  exact ⟨by simpa [add_eq_zero_iff_eq_neg] using z.ne_intCast (-n),
    sub_ne_zero.mpr (z.ne_intCast n)⟩

theorem upbnd (z : ℍ) (d : ℤ) : (d ^ 2 : ℝ) * r z ^ 2 ≤ ‖((z : ℂ) ^ 2 - d ^ 2)‖ := by
  have h (n : ℤ) : r z * |(n : ℝ)| ≤ ‖(z : ℂ) + n‖ := calc
    _ ≤ r z * ‖![1, n]‖ := by
      simpa [Int.norm_eq_abs] using
        mul_le_mul_of_nonneg_left (norm_le_pi_norm ![(1 : ℤ), n] 1) (r_pos z).le
    _ ≤ _ := by simpa using r_mul_max_le z (x := ![1, n]) (by simp)
  rw [sq_sub_sq, norm_mul]
  calc
    _ = (r z * |(d : ℝ)|) * (r z * |(d : ℝ)|) := by nlinarith [sq_abs (d : ℝ)]
    _ ≤ _ := mul_le_mul (h d) (by simpa [sub_eq_add_neg] using h (-d))
      (mul_nonneg (r_pos z).le (abs_nonneg _)) (norm_nonneg _)

/- This is from the mod forms repo -/
theorem lhs_summable (z : ℍ) : Summable fun n : ℕ+ => 1 / ((z : ℂ) - n) + 1 / (z + n) := by
  rw [summable_pnat_iff_summable_succ (f := fun n : ℕ ↦ 1 / ((z : ℂ) - n) + 1 / (z + n))]
  simpa [cotTerm] using summable_cotTerm (coe_mem_integerComplement z)

lemma neg_div_neg_aux (a b : ℂ) : -a/b = a / -b := by
  ring

theorem summable_diff (z : ℍ) (d : ℤ) :
    Summable fun m : ℕ+ ↦ 1 / (-(d : ℂ) / ↑z - ↑↑m) + 1 / (-↑d / ↑z + ↑↑m) := by
  by_cases hd : d = 0
  · simp [hd]
  rw [summable_pnat_iff_summable_succ (f := fun n : ℕ ↦
    1 / (-(d : ℂ) / z - n) + 1 / (-d / z + n))]
  simpa [cotTerm] using summable_cotTerm
    (show -(d : ℂ) / z ∈ integerComplement from
      by simpa using z.int_div_mem_integerComplement (n := -d) (neg_ne_zero.mpr hd))

lemma arg1 (a b c d e f g h : ℂ) : e / f + g / h - a / b - c / d = e / f + g / h + a / -b + c / -d
    := by ring

lemma sum_int_pnat3 (z : ℍ) (d : ℤ) :
  ∑' m : ℕ+,
    ((1 / ((m : ℂ) * ↑z - d) + 1 / (-↑m * ↑z + -d)) - (1 / ((m : ℂ) * ↑z + d)) - 1 / (-↑m * ↑z + d))
      =
  (2 / z) * ∑' m : ℕ+,
    ((1 / (-(d : ℂ)/↑z - m) + 1 / (-d/↑z + m))) := by
  rw [← tsum_mul_left]
  apply tsum_congr
  intro m
  rw [arg1]
  ring_nf
  field_simp [z.ne_zero]
  ring

lemma pow_max (x y : ℕ) : (max x y)^2 = max (x^2) (y ^ 2) := by
  exact (monotone_id.pow_const 2).map_max

theorem extracted_abs_norm_summable (z : ℍ) (i : ℤ) :
  Summable fun m ↦ 1 / (r z ^ 2 * 2⁻¹ * ‖![m, i]‖ ^ 2) := by
  have hs : Summable fun m : ℤ ↦ 1 / (r z ^ 2 * 2⁻¹ * (m : ℝ) ^ 2) := by
    simp only [one_div, mul_inv_rev]
    have hs : Summable fun m : ℤ ↦ ((m : ℝ) ^ 2)⁻¹ := by
      simpa only [one_div] using (Real.summable_one_div_int_pow (p := 2)).mpr (by norm_num)
    exact hs.mul_right ((2⁻¹ : ℝ)⁻¹ * (r z ^ 2)⁻¹)
  apply hs.of_norm_bounded_eventually
  filter_upwards [eventually_cofinite_ne (0 : ℤ)] with m hm
  rw [Real.norm_of_nonneg (by positivity)]
  have hr := r_pos z
  have hm' : (m : ℝ) ≠ 0 := by exact_mod_cast hm
  apply one_div_le_one_div_of_le (by positivity)
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  have h := norm_le_pi_norm ![m, i] 0
  simpa [Int.norm_eq_abs, sq_abs] using pow_le_pow_left₀ (norm_nonneg _) h 2

lemma summable_hammerTime_nat {α : Type} [NormedField α] [CompleteSpace α] (f : ℕ → α) (a : ℝ) (hab
  : 1 < a)
    (hf : (fun n => (f n)⁻¹) =O[cofinite] fun n => (|(n : ℝ)| ^ (a : ℝ))⁻¹) :
    Summable fun n => (f n)⁻¹ := by
  exact summable_of_isBigO
    (by simpa using (Real.summable_nat_rpow_inv.mpr hab)) hf

theorem summable_diff_denom (z : ℍ) (i : ℤ) :
  Summable fun (m : ℤ) ↦ ((m : ℂ) * ↑z + ↑i + 1)⁻¹ * ((m : ℂ) * ↑z + ↑i)⁻¹ := by
  simpa [mul_inv_rev, add_assoc] using
    summable_linear_left_mul_linear_left z.ne_zero i (i + 1)

lemma summable_pain (z : ℍ) (i : ℤ) :
  Summable (fun m : ℤ ↦ 1 / ((m : ℂ) * ↑z + ↑i) - 1 / (↑m * ↑z + ↑i + 1)) := by
  simpa [add_assoc] using summable_left_one_div_linear_sub_one_div_linear z i (i + 1)

theorem vector_norm_bound (b : Fin 2 → ℤ) (hb : b ≠ 0) (HB1 : b ≠ ![0, -1]) :
    ‖![b 0, b 1 + 1]‖ ^ (-1 : ℝ) * ‖b‖ ^ (-2 : ℝ) ≤ 2 * ‖b‖ ^ (-3 : ℝ) := by
  have hshift : 0 < ‖![b 0, b 1 + 1]‖ := by
    rw [norm_pos_iff]
    simpa [funext_iff, Fin.forall_fin_two, add_eq_zero_iff_eq_neg] using HB1
  have hnorm : ‖b‖ ≤ 2 * ‖![b 0, b 1 + 1]‖ := by
    simp only [norm_eq_max_natAbs, Matrix.cons_val_zero, Matrix.cons_val_one]
    push_cast
    norm_cast
    have hn : b 0 ≠ 0 ∨ b 1 ≠ -1 := by
      by_contra h
      push Not at h
      apply HB1
      ext i
      fin_cases i <;> simp [h.1, h.2]
    omega
  have hi : ‖![b 0, b 1 + 1]‖⁻¹ ≤ 2 * ‖b‖⁻¹ := by
    rwa [le_mul_inv_iff₀ (norm_pos_iff.mpr hb), inv_mul_eq_div, div_le_iff₀ hshift]
  calc
    _ ≤ (2 * ‖b‖⁻¹) * ‖b‖ ^ (-2 : ℝ) := by
      simpa only [Real.rpow_neg_one] using
        mul_le_mul_of_nonneg_right hi (Real.rpow_nonneg (norm_nonneg _) _)
    _ = 2 * ‖b‖ ^ (-3 : ℝ) := by
      rw [mul_assoc, ← Real.rpow_neg_one, ← Real.rpow_add (norm_pos_iff.mpr hb)]
      norm_num

lemma G_2_alt_summable (z : ℍ) : Summable fun (m : Fin 2 → ℤ) =>
    1 / (((m 0 : ℂ) * z + m 1)^2 * (m 0 * z + m 1 + 1)) := by
  apply EisensteinSeries.summable_of_isBigO_rpow_norm (a := 3) (by norm_num)
  simpa [one_div, pow_three, pow_two, ← mul_assoc] using
    ((isBigO_linear_add_const_vec z 0 1).mul
      (isBigO_linear_add_const_vec z 0 0)).mul (isBigO_linear_add_const_vec z 0 0)

noncomputable def δ (a b : ℤ) : ℂ := if a = 0 ∧ b = 0 then 1 else if a = 0 ∧ b = -1 then 2 else 0

@[simp]
lemma δ_eq : δ 0 0 = 1 := by simp [δ]

@[simp]
lemma δ_eq2 : δ 0 (-1) = 2 := by simp [δ]

lemma δ_neq (a b : ℤ) (h : a ≠ 0) : δ a b = 0 := by
  simp [δ, h]

lemma G_2_alt_summable_δ (z : ℍ) : Summable fun (m : Fin 2 → ℤ) =>
    (1 / (((m 0 : ℂ) * z + m 1)^2 * (m 0 * z + m 1 + 1)) + δ (m 0) (m 1)):= by
  apply (G_2_alt_summable z).congr_cofinite
  filter_upwards [eventually_cofinite_ne ![0, 0], eventually_cofinite_ne ![0, -1] ] with m h₀ h₁
  have hzero : ¬ (m 0 = 0 ∧ m 1 = 0) := by
    rintro ⟨h₀', h₁'⟩
    apply h₀
    ext i
    fin_cases i <;> simp [h₀', h₁']
  have hone : ¬ (m 0 = 0 ∧ m 1 = -1) := by
    rintro ⟨h₀', h₁'⟩
    apply h₁
    ext i
    fin_cases i <;> simp [h₀', h₁']
  simp [δ, hzero, hone]

theorem G2_prod_summable1 (z : ℍ) (b : ℤ) :
    Summable fun c : ℤ ↦ ((b : ℂ) * ↑z + ↑c + 1)⁻¹ * (((b : ℂ) * ↑z + ↑c) ^ 2)⁻¹ := by
  have := G_2_alt_summable z
  simp only [Fin.isValue, one_div, mul_inv_rev] at this
  rw [← (finTwoArrowEquiv _).symm.summable_iff] at this
  apply this.prod_factor b

theorem G2_prod_summable1_δ (z : ℍ) (b : ℤ) :
    Summable fun c : ℤ ↦ ((b : ℂ) * ↑z + ↑c + 1)⁻¹ * (((b : ℂ) * ↑z + ↑c) ^ 2)⁻¹ + δ b c := by
  have := G_2_alt_summable_δ z
  simp only [Fin.isValue, one_div, mul_inv_rev] at this
  rw [← (finTwoArrowEquiv _).symm.summable_iff] at this
  apply this.prod_factor b

lemma G2_alt_indexing_δ (z : ℍ) : ∑' (m : Fin 2 → ℤ),
    (1 / (((m 0 : ℂ) * z + m 1)^2 * (m 0 * z + m 1 + 1)) + δ (m 0) (m 1)) =
    ∑' m : ℤ, ∑' n : ℤ, (1 / (((m : ℂ)* z + n)^2 * (m * z + n +1)) + (δ m n)) := by
  rw [← (finTwoArrowEquiv _).symm.tsum_eq]
  exact ((finTwoArrowEquiv _).symm.summable_iff.mpr (G_2_alt_summable_δ z)).tsum_prod

lemma G2_alt_indexing2_δ (z : ℍ) : ∑' (m : Fin 2 → ℤ),
    (1 / (((m 0 : ℂ) * z + m 1)^2 * (m 0 * z + m 1 + 1)) + δ (m 0) (m 1)) =
    ∑' n : ℤ, ∑' m : ℤ, (1 / (((m : ℂ)* z +n)^2 * (m * z + n +1)) + δ m n) := by
  rw [G2_alt_indexing_δ]
  have hs := (finTwoArrowEquiv _).symm.summable_iff.mpr (G_2_alt_summable_δ z)
  change Summable (Function.uncurry (fun m n : ℤ ↦
    1 / (((m : ℂ) * z + n)^2 * (m * z + n + 1)) + δ m n)) at hs
  exact hs.tsum_comm.symm

theorem summable_1 (k : ℕ) (z : ℍ) (hk : 1 ≤ k) :
    Summable fun (b : ℕ) ↦ (((z : ℂ) - ↑↑b) ^ (k + 1))⁻¹ := by
  have h := (summable_int_iff_summable_nat_and_neg.mp
    (linear_right_summable (z : ℂ) 1 (k := k + 1) (by omega))).2
  simpa [sub_eq_add_neg] using h

theorem summable_2 (k : ℕ) (z : ℍ) (hk : 1 ≤ k) :
    Summable fun (b : ℕ) ↦ (((z : ℂ) + ↑↑b) ^ (k + 1))⁻¹ := by
  have h := (summable_int_iff_summable_nat_and_neg.mp
    (linear_right_summable (z : ℂ) 1 (k := k + 1) (by omega))).1
  simpa using h

theorem summable_3 (m : ℕ) (y : {z : ℂ | 0 < z.im}) :
    Summable fun n : ℕ+ =>
      (-1 : ℂ) ^ m * ↑m ! * (1 / (y - ↑n) ^ (m + 1)) +
        (-1) ^ m * ↑m ! * (1 / (y + ↑n) ^ (m + 1)) := by
  rcases m with _ | m
  · simpa using lhs_summable (⟨y, y.2⟩ : ℍ)
  simpa [one_div, mul_add] using
    (((summable_1 (m + 1) ⟨y, y.2⟩ (by omega)).subtype _).add
      ((summable_2 (m + 1) ⟨y, y.2⟩ (by omega)).subtype _)).mul_left
      ((-1 : ℂ) ^ (m + 1) * ↑(m + 1)!)

lemma G2_summable_aux (n : ℤ) (z : ℍ) (k : ℤ) (hk : 2 ≤ k) :
    Summable fun d : ℤ => ((((n : ℂ) * z) + d) ^ k)⁻¹ := by
  exact linear_right_summable z n hk

/-This is straight from the mod forms repo-/
lemma auxf (a b c d : ℂ) : a / b - (c / d) = a / b + (c / -d) := by
  ring

theorem summable_diff_right_a (z : ℍ) (d : ℕ+) :
  Summable fun n : ℕ ↦ 1 / ((n : ℂ) * ↑z - ↑↑d) - 1 / (↑↑n * ↑z + ↑↑d) := by
  have h := summable_left_one_div_linear_sub_one_div_linear z (-d) d
  simpa using (summable_int_iff_summable_nat_and_neg.mp h).1

theorem summable_diff_right (z : ℍ) (d : ℕ+) :
  Summable fun m : ℤ ↦ 1 / ((m : ℂ) * ↑z - ↑↑d) - 1 / (↑m * ↑z + ↑↑d) := by
  simpa using summable_left_one_div_linear_sub_one_div_linear z (-d) d

lemma sum_int_pnatt (z : ℍ) (d : ℕ+) :
  2/ d + ∑' (m : ℤ), (1 / ((m : ℂ) * ↑z - d) - 1 / (↑m * ↑z + d)) = ∑' m : ℕ+,
    ((1 / ((m : ℂ) * ↑z - d) + 1 / (-↑m * ↑z + -d)) - (1 / ((m : ℂ) * ↑z + d)) - 1 / (-↑m * ↑z + d))
      := by
  rw [tsum_int_eq_zero_add_tsum_pnat (summable_diff_right z d)]
  simp only [Int.cast_zero, zero_mul, zero_sub, one_div, zero_add, Int.cast_natCast, Int.cast_neg,
    neg_mul]
  ring_nf
  rw [← Summable.tsum_add]
  · congr
    funext m
    ring
  · have := (summable_diff_right z d)
    rw [summable_int_iff_summable_nat_and_neg] at this
    have H := this.1
    simp only [Int.cast_natCast, one_div, Int.cast_neg, neg_mul] at *
    have v : Summable fun (n : ℕ) ↦ (-↑(d : ℂ) + (n : ℂ) * ↑z)⁻¹ - (↑↑d + (n : ℂ)* ↑z)⁻¹ := by
      apply H.congr
      intro b
      ring
    apply v.subtype
  · have := (summable_diff_right z d)
    rw [summable_int_iff_summable_nat_and_neg] at this
    have H := this.2
    simp only [Int.cast_natCast, one_div, Int.cast_neg, neg_mul] at *
    have v : Summable fun (n : ℕ) ↦ ( - ↑(d : ℂ)- z * ((n : ℂ)))⁻¹ - (↑↑d - z * ((n : ℂ)))⁻¹ := by
      apply H.congr
      intro b
      ring
    apply v.subtype

lemma sum_int_pnat2_pnat (z : ℍ) (d : ℕ+) :
  ∑' (m : ℤ), (1 / ((m : ℂ) * ↑z - d) - 1 / (↑m * ↑z + d)) = -2/d + ∑' m : ℕ+,
    ((1 / ((m : ℂ) * ↑z - d) + 1 / (-↑m * ↑z + -d)) - (1 / ((m : ℂ) * ↑z + d)) - 1 / (-↑m * ↑z + d))
      := by
  rw [← sum_int_pnatt]
  ring
