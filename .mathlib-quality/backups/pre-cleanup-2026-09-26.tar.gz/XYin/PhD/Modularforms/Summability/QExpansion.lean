/-
Copyright (c) 2026 SmwYin. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: SmwYin
-/
module

public import Mathlib.NumberTheory.ModularForms.EisensteinSeries.QExpansion
public import XYin.PhD.Modularforms.Summability.Reciprocal
public import XYin.PhD.Modularforms.tsumderivWithin

/-!
# Fourier expansion of reciprocal lattice sums

Locally uniform derivative estimates for reciprocal and exponential series,
followed by the cotangent identity and the Eisenstein q-expansion formula `q_exp_iden`.
These lemmas were split from `summable_lems`.
-/

@[expose] public section

open ModularForm EisensteinSeries UpperHalfPlane TopologicalSpace Set
  Metric Filter Function Complex ArithmeticFunction

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat

theorem summable_iter_derv' (k : ℕ) (y : ℍ') :
    Summable fun n : ℕ => (2 * ↑π * Complex.I * n) ^ k *
      Complex.exp (2 * ↑π * Complex.I * n * y) := by
  simpa [mul_pow, ← Complex.exp_nat_mul, mul_comm, mul_left_comm, mul_assoc] using
    (summable_pow_mul_geometric_of_norm_lt_one k
      (norm_exp_two_pi_I_lt_one (⟨y, y.2⟩ : ℍ))).mul_left ((2 * π * Complex.I) ^ k)

theorem exp_series_ite_deriv_uexp2 (k : ℕ) (x : {z : ℂ | 0 < z.im}) :
    iteratedDerivWithin k (fun z => ∑' n : ℕ, Complex.exp (2 * ↑π * Complex.I * n * z))
    {z : ℂ | 0 < z.im} x =
    ∑' n : ℕ, iteratedDerivWithin k (fun s : ℂ => Complex.exp (2 * ↑π * Complex.I * n * s))
    {z : ℂ | 0 < z.im} x := by
  simpa [← Complex.exp_nat_mul, mul_comm, mul_left_comm, mul_assoc] using
    iteratedDerivWithin_tsum_cexp_eq k (⟨x, x.2⟩ : ℍ)

theorem exp_series_ite_deriv_uexp'' (k : ℕ) (x : {z : ℂ | 0 < z.im}) :
    iteratedDerivWithin k (fun z => ∑' n : ℕ, Complex.exp (2 * ↑π * Complex.I * n * z))
    {z : ℂ | 0 < z.im} x =
    ∑' n : ℕ, (2 * ↑π * Complex.I * n) ^ k * Complex.exp (2 * ↑π * Complex.I * n * x) := by
  rw [exp_series_ite_deriv_uexp2 k x]
  exact tsum_congr fun n ↦ exp_iter_deriv_within k n x.2

theorem exp_series_ite_deriv_uexp''' (k : ℕ) :
    EqOn (iteratedDerivWithin k (fun z => ∑' n : ℕ, Complex.exp (2 * ↑π * Complex.I * n * z)) ℍ')
      (fun x : ℂ => ∑' n : ℕ, (2 * ↑π * Complex.I * n) ^ k * Complex.exp (2 * ↑π * Complex.I * n *
        x)) ℍ' := by
  exact fun x hx ↦ exp_series_ite_deriv_uexp'' k ⟨x, hx⟩

theorem tsum_uexp_contDiffOn (k : ℕ) :
    ContDiffOn ℂ k (fun z : ℂ => ∑' n : ℕ, Complex.exp (2 * ↑π * Complex.I * n * z)) ℍ' := by
  simpa [← Complex.exp_nat_mul, mul_comm, mul_left_comm, mul_assoc] using
    contDiffOn_tsum_cexp k

theorem iter_der_within_add (k : ℕ+) (x : {z : ℂ | 0 < z.im}) :
    iteratedDerivWithin k
        (fun z => ↑π * Complex.I - (2 * ↑π * Complex.I) •
        ∑' n : ℕ, Complex.exp (2 * ↑π * Complex.I * n * z)) {z : ℂ | 0 < z.im} x =
      -(2 * ↑π * Complex.I) * ∑' n : ℕ, (2 * ↑π * Complex.I * n) ^ (k : ℕ) *
      Complex.exp (2 * ↑π * Complex.I * n * x) := by
  rw [iteratedDerivWithin_const_sub k.pos]
  · simp only [smul_eq_mul]
    rw [iteratedDerivWithin_fun_neg, iteratedDerivWithin_const_mul_field,
      exp_series_ite_deriv_uexp'']
    ring

theorem iter_exp_eqOn (k : ℕ+) :
    EqOn
      (iteratedDerivWithin k
        (fun z => ↑π * Complex.I - (2 * ↑π * Complex.I) • ∑' n : ℕ, Complex.exp (2 * ↑π * Complex.I
          * n * z)) {z : ℂ | 0 < z.im})
      (fun x : ℂ =>
        -(2 * ↑π * Complex.I) * ∑' n : ℕ, (2 * ↑π * Complex.I * n) ^ (k : ℕ) * Complex.exp (2 * ↑π *
          Complex.I * n * x))
      {z : ℂ | 0 < z.im} := by
  exact fun z hz ↦ iter_der_within_add k ⟨z, hz⟩

theorem summable_iter_aut (k : ℕ) (z : ℍ) :
    Summable fun n : ℕ+ => iteratedDerivWithin k (fun z : ℂ => 1 / (z - n) + 1 / (z + n))
      {z : ℂ | 0 < z.im} z := by
  apply (summable_3 k ⟨z, z.2⟩).congr
  intro n
  simpa using (iter_div_aut_add n k z.2).symm

lemma sub_bound (s : ℍ) (A B : ℝ) (hB : 0 < B) (hs : s ∈ verticalStrip A B) (k : ℕ)
    (n : ℕ+) :
    ‖((-1 : ℂ) ^ (k + 1) * (k + 1)! * (1 / (s - n) ^ (k + 2)))‖ ≤
    ‖((k + 1)! / r ⟨⟨A, B⟩, by simp [hB]⟩ ^ (k + 2)) * ((n : ℝ) ^ ((k : ℤ) +2))⁻¹‖ := by
  have hn : ‖![(1 : ℤ), -(n : ℤ)]‖ = (n : ℝ) := by
    simp only [norm_eq_max_natAbs, Matrix.cons_val_zero, Matrix.cons_val_one,
      Int.natAbs_neg, Int.natAbs_natCast, Int.natAbs_one, max_eq_right (show 1 ≤ (n : ℕ) from n.2)]
  have h := summand_bound_of_mem_verticalStrip (k := (k + 2 : ℕ))
    (by positivity) ![1, -(n : ℤ)] hB hs
  simp only [Real.rpow_neg_natCast, zpow_neg, zpow_natCast] at h
  rw [show (k : ℤ) + 2 = ((k + 2 : ℕ) : ℤ) by omega]
  simpa [hn, sub_eq_add_neg, Real.rpow_neg, Real.rpow_natCast,
    norm_mul, norm_pow, norm_div, abs_of_pos (r_pos _), div_eq_mul_inv, mul_assoc] using
    mul_le_mul_of_nonneg_left h (show (0 : ℝ) ≤ (k + 1)! by positivity)

lemma add_bound (s : ℍ) (A B : ℝ) (hB : 0 < B) (hs : s ∈ verticalStrip A B) (k : ℕ)
    (n : ℕ+) :
    ‖((-1 : ℂ) ^ (k + 1) * (k + 1)! * (1 / (s + n) ^ (k + 2)))‖ ≤
    ‖((k + 1)! / r ⟨⟨A, B⟩, by simp [hB]⟩ ^ (k + 2)) * ((n : ℝ) ^ ((k : ℤ) +2))⁻¹‖ := by
  have hn : ‖![(1 : ℤ), (n : ℤ)]‖ = (n : ℝ) := by
    simp only [norm_eq_max_natAbs, Matrix.cons_val_zero, Matrix.cons_val_one,
      Int.natAbs_natCast, Int.natAbs_one, max_eq_right (show 1 ≤ (n : ℕ) from n.2)]
  have h := summand_bound_of_mem_verticalStrip (k := (k + 2 : ℕ))
    (by positivity) ![1, (n : ℤ)] hB hs
  simp only [Real.rpow_neg_natCast, zpow_neg, zpow_natCast] at h
  rw [show (k : ℤ) + 2 = ((k + 2 : ℕ) : ℤ) by omega]
  simpa [hn, sub_eq_add_neg, Real.rpow_neg, Real.rpow_natCast,
    norm_mul, norm_pow, norm_div, abs_of_pos (r_pos _), div_eq_mul_inv, mul_assoc] using
    mul_le_mul_of_nonneg_left h (show (0 : ℝ) ≤ (k + 1)! by positivity)

theorem aut_bound_on_comp (K : Set ℍ) (hk2 : IsCompact K) (k : ℕ) :
    ∃ u : ℕ+ → ℝ,
      Summable u ∧
        ∀ (n : ℕ+) (s : K),
        ‖(derivWithin (fun z : ℂ =>
        iteratedDerivWithin k (fun z : ℂ => (z - (n : ℂ))⁻¹ + (z + n)⁻¹) {z : ℂ | 0 < z.im} z)
        {z : ℂ | 0 < z.im} s)‖ ≤
            u n := by
  obtain ⟨A, B, hB, hAB⟩ := subset_verticalStrip_of_isCompact hk2
  let zAB : ℍ := ⟨⟨A, B⟩, hB⟩
  have hsum : Summable fun n : ℕ ↦ ((n : ℝ) ^ (k + 2))⁻¹ :=
    Real.summable_nat_pow_inv.mpr (by omega)
  refine ⟨fun n : ℕ+ ↦ 2 * ‖((k + 1)! / r zAB ^ (k + 2))‖ *
    ((n : ℝ) ^ (k + 2))⁻¹,
    (hsum.subtype _).mul_left (2 * ‖((k + 1)! / r zAB ^ (k + 2))‖), ?_⟩
  intro n s
  rw [← iteratedDerivWithin_succ]
  have h := iter_div_aut_add n (k + 1) s.1.2
  simp only [Int.cast_natCast, one_div, Pi.add_apply] at h
  rw [h]
  have hb := (norm_add_le _ _).trans
    (add_le_add (sub_bound s.1 A B hB (hAB s.2) k n)
      (add_bound s.1 A B hB (hAB s.2) k n))
  simpa only [one_div, norm_mul, norm_inv, norm_zpow, norm_pow, Real.norm_natCast,
    ← two_mul, mul_assoc, zAB, show k + 1 + 1 = k + 2 by omega,
    show (k : ℤ) + 2 = ((k + 2 : ℕ) : ℤ) by omega, zpow_natCast] using hb


theorem diff_on_aux (k : ℕ) (n : ℕ+) :
    DifferentiableOn ℂ
      ((fun t : ℂ => (-1 : ℂ) ^ k * k ! * (1 / (t - n) ^ (k + 1))) + fun t : ℂ =>
        (-1) ^ k * k ! * (1 / (t + n) ^ (k + 1))) {z : ℂ | 0 < z.im} := by
  have this (n : ℕ+) (z : ℂ) (hz : 0 < z.im) : (z + n) ^ (k + 1) ≠ 0 := by
    simpa using upper_ne_int ⟨z, hz⟩ n
  have this (n : ℕ+) (z : ℂ) (hz : 0 < z.im) : (z - n) ^ (k + 1) ≠ 0 := by
    simpa using upper_ne_int ⟨z, hz⟩ (-n)
  fun_prop (disch := aesop)

theorem diff_at_aux (s : {z : ℂ | 0 < z.im}) (k : ℕ) (n : ℕ+) :
    DifferentiableAt ℂ
      (fun z : ℂ => iteratedDerivWithin k (fun z : ℂ => (z - ↑n)⁻¹ + (z + ↑n)⁻¹) {z : ℂ | 0 < z.im}
        z)
      ↑s := by
  apply (DifferentiableOn.congr (diff_on_aux k n) ?_).differentiableAt
    (upper_half_plane_isOpen.mem_nhds s.2)
  intro z hz
  simpa [one_div] using iter_div_aut_add n k hz

theorem aut_series_ite_deriv_uexp2 (k : ℕ) (x : ℍ) :
    iteratedDerivWithin k (fun z : ℂ => ∑' n : ℕ+, (1 / (z - n) + 1 / (z + n))) {z : ℂ | 0 < z.im} x
      =
      ∑' n : ℕ+, iteratedDerivWithin k (fun z : ℂ => 1 / (z - n) + 1 / (z + n)) {z : ℂ | 0 < z.im} x
        := by
  have h (z : ℂ) : (∑' n : ℕ+, (1 / (z - n) + 1 / (z + n))) =
      ∑' n : ℕ, cotTerm z n := by
    simpa only [cotTerm, Nat.cast_add, Nat.cast_one] using
      tsum_pnat_eq_tsum_succ (f := fun n : ℕ ↦ 1 / (z - n) + 1 / (z + n))
  simp_rw [h]
  rw [tsum_pnat_eq_tsum_succ (f := fun n : ℕ ↦
    iteratedDerivWithin k (fun z : ℂ ↦ 1 / (z - n) + 1 / (z + n)) upperHalfPlaneSet x)]
  simp only [Nat.cast_add, Nat.cast_one]
  change iteratedDerivWithin k (fun z ↦ ∑' n : ℕ, cotTerm z n) upperHalfPlaneSet x =
    ∑' n : ℕ, iteratedDerivWithin k (fun z ↦ cotTerm z n) upperHalfPlaneSet x
  rw [iteratedDerivWithin_tsum k isOpen_upperHalfPlaneSet
    (show (x : ℂ) ∈ upperHalfPlaneSet from x.2)]
  · exact fun z hz ↦ summable_cotTerm (coe_mem_integerComplement ⟨z, hz⟩)
  · exact fun n hn _ ↦ summableLocallyUniformlyOn_iteratedDerivWithin_cotTerm hn
  · exact fun n l z _ hz ↦ (differentiableOn_iteratedDerivWithin_cotTerm n l).differentiableAt
      (isOpen_upperHalfPlaneSet.mem_nhds hz)

theorem tsum_ider_der_eq (k : ℕ) (x : {z : ℂ | 0 < z.im}) :
    ∑' n : ℕ+, iteratedDerivWithin k (fun z : ℂ => 1 / (z - n) + 1 / (z + n)) {z : ℂ | 0 < z.im} x =
      ∑' n : ℕ+,
        ((-1 : ℂ) ^ k * k ! * (1 / (x - n) ^ (k + 1)) +
          (-1) ^ k * k ! * (1 / (x + n) ^ (k + 1))) := by
  exact tsum_congr fun n ↦ by simpa using iter_div_aut_add n k x.2

theorem auxp_series_ite_deriv_uexp''' (k : ℕ) :
    EqOn (iteratedDerivWithin k (fun z : ℂ => ∑' n : ℕ+, (1 / (z - n) + 1 / (z + n)))
    {z : ℂ | 0 < z.im})
    (fun x : ℂ =>
      ∑' n : ℕ+,
        ((-1 : ℂ) ^ k * k ! * (1 / (x - n) ^ (k + 1)) + (-1) ^ k * k ! * (1 / (x + n) ^ (k + 1))))
    {z : ℂ | 0 < z.im} := by
  exact fun x hx ↦ (aut_series_ite_deriv_uexp2 k ⟨x, hx⟩).trans (tsum_ider_der_eq k ⟨x, hx⟩)

theorem tsum_aexp_contDiffOn (k : ℕ) :
    ContDiffOn ℂ k (fun z : ℂ => ∑' n : ℕ+, (1 / (z - n) + 1 / (z + n))) {z : ℂ | 0 < z.im} := by
  have h : ContDiffOn ℂ k (fun z : ℂ ↦ π * cot (π * z) - 1 / z) upperHalfPlaneSet := by
    intro z hz
    exact ((contDiffWithinAt_const.mul
      (cot_pi_mul_contDiffWithinAt k (coe_mem_integerComplement ⟨z, hz⟩))).sub
      (contDiffWithinAt_const.div contDiffWithinAt_id (ne_zero ⟨z, hz⟩)))
  apply h.congr
  intro z hz
  rw [cot_series_rep (coe_mem_integerComplement ⟨z, hz⟩)]
  ring

theorem aux_iter_der_tsum (k : ℕ) (hk : 1 ≤ k) (x : ℍ) :
    iteratedDerivWithin k
        ((fun z : ℂ => 1 / z) + fun z : ℂ => ∑' n : ℕ+, (1 / (z - n) + 1 / (z + n))) {z : ℂ | 0 <
          z.im} x =
      (-1) ^ (k : ℕ) * (k : ℕ)! * ∑' n : ℤ, 1 / ((x : ℂ) + n) ^ (k + 1 : ℕ) := by
  rw [← iteratedDerivWithin_cot_pi_mul_eq_mul_tsum_div_pow hk x.2]
  apply iteratedDerivWithin_congr (s := {z : ℂ | 0 < z.im}) _ x.2
  intro z hz
  exact (cot_series_rep (coe_mem_integerComplement ⟨z, hz⟩)).symm

theorem aux_iter_der_tsum_eqOn (k : ℕ) (hk : 2 ≤ k) :
    EqOn (iteratedDerivWithin (k - 1)
    ((fun z : ℂ => 1 / z) + fun z : ℂ => ∑' n : ℕ+, (1 / (z - n) + 1 / (z + n))) {z : ℂ | 0 < z.im})
    (fun z : ℂ => (-1) ^ (k - 1) * (k - 1)! * ∑' n : ℤ, 1 / (z + n) ^ (k : ℕ)) {z : ℂ | 0 < z.im}
    := by
  intro z hz
  simpa [Nat.sub_add_cancel (show 1 ≤ k by omega)] using
    aux_iter_der_tsum (k - 1) (by omega) ⟨z, hz⟩

theorem pos_sum_eq (k : ℕ) (hk : 0 < k) :
    (fun x : ℂ =>
        -(2 * ↑π * Complex.I) * ∑' n : ℕ, (2 * ↑π * Complex.I * n) ^ (k : ℕ) * Complex.exp (2 * ↑π *
          Complex.I * n * x)) =
      fun x : ℂ =>
      -(2 * ↑π * Complex.I) * ∑' n : ℕ+, (2 * ↑π * Complex.I * n) ^ (k : ℕ) * Complex.exp (2 * ↑π *
        Complex.I * n * x) := by
  funext x
  congr 1
  exact (tsum_pNat _ (by simp [hk.ne'])).symm

theorem cot_series_repr (z : ℍ) :
    ↑π * cot (↑π * z) - 1 / z = ∑' n : ℕ+, (1 / ((z : ℂ) - n) + 1 / (z + n)) := by
  rw [cot_series_rep (coe_mem_integerComplement z)]
  ring

lemma EisensteinSeries_Identity (z : ℍ) :
    1 / z + ∑' n : ℕ+, (1 / ((z : ℂ) - n) + 1 / (z + n)) =
      π * Complex.I - 2 * π * Complex.I * ∑' n : ℕ, Complex.exp (2 * π * Complex.I * z) ^ n := by
  rw [← cot_series_rep (coe_mem_integerComplement z), pi_mul_cot_pi_q_exp]

theorem q_exp_iden'' (k : ℕ) (hk : 2 ≤ k) :
    EqOn (fun z : ℂ => (-1 : ℂ) ^ (k - 1) * (k - 1)! * ∑' d : ℤ, 1 / ((z : ℂ) + d) ^ k)
      (fun z : ℂ =>
        -(2 * ↑π * Complex.I) * ∑' n : ℕ+, (2 * ↑π * Complex.I * n) ^ ((k - 1) : ℕ) * Complex.exp (2
          * ↑π * Complex.I * n * z))
      {z : ℂ | 0 < z.im} := by
  refine (aux_iter_der_tsum_eqOn k hk).symm.trans ?_
  have h := iter_exp_eqOn (⟨k - 1, by omega⟩ : ℕ+)
  simp only [PNat.mk_coe, smul_eq_mul] at h
  rw [pos_sum_eq (k - 1) (by omega)] at h
  refine EqOn.trans (iteratedDerivWithin_congr ?_) h
  intro z hz
  simpa [Pi.add_apply, ← Complex.exp_nat_mul, mul_comm, mul_left_comm, mul_assoc] using
    EisensteinSeries_Identity ⟨z, hz⟩


theorem q_exp_iden (k : ℕ) (hk : 2 ≤ k) (z : ℍ) :
    ∑' d : ℤ, 1 / ((z : ℂ) + d) ^ k =
      (-2 * ↑π * Complex.I) ^ k / (k - 1)! * ∑' n : ℕ+, n ^ ((k - 1)) * Complex.exp (2 * ↑π *
        Complex.I * z * n) := by
  simpa [Nat.sub_add_cancel (show 1 ≤ k by omega), ← Complex.exp_nat_mul,
    mul_comm, mul_left_comm, mul_assoc] using
    EisensteinSeries.qExpansion_identity_pnat (k := k - 1) (by omega) z

lemma t9 (z : ℍ) : ∑' m : ℕ,
  ( 2 * (-2 * ↑π * Complex.I) ^ 2 / (2 - 1)! *
      ∑' n : ℕ+, n ^ ((2 - 1)) * Complex.exp (2 * ↑π * Complex.I * (m + 1) * z * n)) = -
    8 * π ^ 2 * ∑' (n : ℕ+), (sigma 1 n) * cexp (2 * π * Complex.I * n * z) := by
  have h := tsum_prod_pow_eq_tsum_sigma 1 (norm_exp_two_pi_I_lt_one z)
  rw [tsum_pnat_eq_tsum_succ (f := fun m ↦ ∑' n : ℕ+, (n : ℂ) ^ 1 *
    Complex.exp (2 * π * Complex.I * z) ^ (m * n : ℕ))] at h
  simp only [Nat.add_one_sub_one, Nat.factorial_one, Nat.cast_one, div_one, pow_one]
  have hc : 2 * (-2 * ↑π * Complex.I) ^ 2 = -8 * π ^ 2 := by
    ring_nf
    simp [Complex.I_sq]
  rw [hc, tsum_mul_left]
  congr 1
  simpa [← Complex.exp_nat_mul, mul_comm, mul_left_comm, mul_assoc] using h

