module

public import Mathlib.Analysis.SpecialFunctions.Log.Summable
public import XYin.PhD.Modularforms.Summability.Basic

@[expose] public section

open UpperHalfPlane TopologicalSpace Set Metric Filter Function Complex

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat

open ArithmeticFunction


/-this is being PRd-/
lemma Complex.summable_nat_multipliable_one_add (f : ℕ → ℂ) (hf : Summable f) :
    Multipliable (fun n : ℕ => 1 + f n) := by
  exact Complex.multipliable_one_add_of_summable hf

theorem term_ne_zero (z : ℍ) (n : ℕ) : 1 -cexp (2 * ↑π * Complex.I * (↑n + 1) * ↑z) ≠ 0 := by
  exact sub_ne_zero.mpr (ne_of_apply_ne norm (ne_of_gt (by
    simpa using exp_upperHalfPlane_lt_one_nat z n)))

theorem ball_pow_ne_1 (x : ℂ) (hx : x ∈ ball 0 1) (n : ℕ) : 1 + (fun n ↦ -x ^ (n + 1)) n ≠ 0 := by
  have hpow : ‖x ^ (n + 1)‖ < 1 := by
    rw [norm_pow]
    exact pow_lt_one₀ (norm_nonneg _) (mem_ball_zero_iff.mp hx) (by lia)
  simpa [sub_eq_add_neg] using sub_ne_zero.mpr (ne_of_apply_ne norm (ne_of_gt (by
    simpa using hpow)))

theorem multipliable_lt_one (x : ℂ) (hx : x ∈ ball 0 1) :
  Multipliable fun i ↦ 1 - x ^ (i+ 1) := by
  simpa [sub_eq_add_neg] using Complex.multipliable_one_add_of_summable
    (((summable_geometric_of_norm_lt_one (mem_ball_zero_iff.mp hx)).comp_injective
      Nat.succ_injective).neg)

lemma MultipliableEtaProductExpansion (z : ℍ) :
    Multipliable (fun (n : ℕ) => (1 - cexp (2 * π * Complex.I * (n + 1) * z)) ) := by
  simpa [sub_eq_add_neg] using Complex.multipliable_one_add_of_summable
    ((summable_norm_iff.mp (summable_exp_pow z)).neg)

lemma MultipliableEtaProductExpansion_pnat (z : ℍ) :
  Multipliable (fun (n : ℕ+) => (1 - cexp (2 * π * Complex.I * n * z))) := by
  apply (multipliable_pnat_iff_multipliable_succ
    (f := fun n : ℕ ↦ 1 - cexp (2 * π * Complex.I * n * z))).2
  simpa using MultipliableEtaProductExpansion z

lemma tprod_ne_zero (x : ℍ) (f : ℕ → ℍ → ℂ) (hf : ∀ i x, 1 + f i x ≠ 0)
  (hu : ∀ x : ℍ, Summable fun n => f n x) : (∏' i : ℕ, (1 + f i) x) ≠ 0 := by
  change tprod (fun i : ℕ ↦ 1 + f i x) ≠ 0
  rw [← Complex.cexp_tsum_eq_tprod (f := fun n ↦ 1 + f n x) (fun n ↦ hf n x)
    (Complex.summable_log_one_add_of_summable (hu x))]
  exact Complex.exp_ne_zero _

lemma Multipliable_pow {ι : Type*} (f : ι → ℂ) (hf : Multipliable f) (n : ℕ) :
     Multipliable (fun i => f i ^ n) := by
  exact hf.pow n

lemma MultipliableDeltaProductExpansion_pnat (z : ℍ) :
  Multipliable (fun (n : ℕ+) => (1 - cexp (2 * π * Complex.I * n * z))^24) := by
  exact (MultipliableEtaProductExpansion_pnat z).pow 24

lemma tprod_pow (f : ℕ → ℂ) (hf : Multipliable f) (n : ℕ) : (∏' (i : ℕ), f i) ^ n = ∏' (i : ℕ),
    (f i) ^ n := by
  exact (hf.tprod_pow n).symm

variable {a a₁ a₂ : ℝ} {ι : Type*}

theorem hasProd_le_nonneg (f g : ι → ℝ) (h : ∀ i, f i ≤ g i) (h0 : ∀ i, 0 ≤ f i)
  (hf : HasProd f a₁) (hg : HasProd g a₂) : a₁ ≤ a₂ := by
  exact le_of_tendsto_of_tendsto' hf hg fun s ↦
    Finset.prod_le_prod (fun i _ ↦ h0 i) (fun i _ ↦ h i)

theorem HasProd.le_one_nonneg (g : ℕ → ℝ) (h : ∀ i, g i ≤ 1) (h0 : ∀ i, 0 ≤ g i)
    (ha : HasProd g a) : a ≤ 1 := by
  apply hasProd_le_nonneg (f := g) (g := fun _ => 1) h h0 ha hasProd_one

theorem one_le_tprod_nonneg (g : ℕ → ℝ) (h : ∀ i, g i ≤ 1) (h0 : ∀ i, 0 ≤ g i) : ∏' i, g i ≤ 1 := by
  by_cases hg : Multipliable g
  · apply hg.hasProd.le_one_nonneg g h h0
  · rw [tprod_eq_one_of_not_multipliable hg]
