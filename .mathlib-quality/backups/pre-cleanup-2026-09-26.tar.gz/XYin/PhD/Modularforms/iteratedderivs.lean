module

public import Mathlib.Analysis.CStarAlgebra.Classes
public import Mathlib.Analysis.Calculus.Deriv.Inv
public import Mathlib.Analysis.Calculus.Deriv.Pow
public import Mathlib.Analysis.Calculus.IteratedDeriv.WithinZpow
public import Mathlib.Analysis.Complex.UpperHalfPlane.Basic
public import Mathlib.Analysis.SpecialFunctions.ExpDeriv
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
public import Mathlib.Tactic.Cases

@[expose] public section

open  UpperHalfPlane TopologicalSpace Set
  Metric Filter Function Complex

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat


theorem upper_ne_int (x : ℍ) (d : ℤ) : (x : ℂ) + d ≠ 0 := by
  intro h
  exact x.im_pos.ne' (by simpa using congrArg Complex.im h)


theorem aut_iter_deriv (d : ℤ) (k : ℕ) :
    EqOn (iteratedDerivWithin k (fun z : ℂ => 1 / (z + d)) {z : ℂ | 0 < z.im})
      (fun t : ℂ => (-1) ^ k * k ! * (1 / (t + d) ^ (k + 1))) {z : ℂ | 0 < z.im} := by
  intro x hx
  simp only [one_div]
  rw [iteratedDerivWithin_of_isOpen (isOpen_lt continuous_const continuous_im) hx,
    iteratedDeriv_comp_add_const]
  have h := iteratedDerivWithin_one_div (𝕜 := ℂ) k isOpen_univ (mem_univ (x + d))
  rw [show (-1 - (k : ℤ)) = -((k + 1 : ℕ) : ℤ) by lia] at h
  simpa only [iteratedDerivWithin_univ, zpow_neg, zpow_natCast, one_div] using h


theorem aut_iter_deriv' (d : ℤ) (k : ℕ) :
    EqOn (iteratedDerivWithin k (fun z : ℂ => 1 / (z - d)) {z : ℂ | 0 < z.im})
      (fun t : ℂ => (-1) ^ k * k ! * (1 / (t - d) ^ (k + 1))) {z : ℂ | 0 < z.im} := by
  simpa [sub_eq_add_neg] using aut_iter_deriv (-d) k


theorem aut_contDiffOn (d : ℤ) (k : ℕ) : ContDiffOn ℂ k (fun z : ℂ => 1 / (z - d))
    {z : ℂ | 0 < z.im} := by
  refine (contDiffOn_const.div (contDiffOn_id.sub contDiffOn_const) ?_)
  intro x hx
  simpa [sub_eq_add_neg] using upper_ne_int ⟨x, hx⟩ (-d)


theorem iter_div_aut_add (d : ℤ) (k : ℕ) :
    EqOn (iteratedDerivWithin k (fun z : ℂ => 1 / (z - d) + 1 / (z + d)) {z : ℂ | 0 < z.im})
      ((fun t : ℂ => (-1) ^ k * k ! * (1 / (t - d) ^ (k + 1))) + fun t : ℂ =>
        (-1) ^ k * k ! * (1 / (t + d) ^ (k + 1))) {z : ℂ | 0 < z.im} := by
  intro x hx
  rw [iteratedDerivWithin_fun_add hx (isOpen_lt continuous_const continuous_im).uniqueDiffOn
    ((aut_contDiffOn d k) x hx) (by simpa using (aut_contDiffOn (-d) k) x hx)]
  exact congrArg₂ (· + ·) (aut_iter_deriv' d k hx) (aut_iter_deriv d k hx)

variable {𝕜 : Type*} [NontriviallyNormedField 𝕜] {F : Type*}
  [NormedAddCommGroup F] [NormedSpace 𝕜 F] (n : ℕ) (f : 𝕜 → F) (s : Set 𝕜) (x : 𝕜)




theorem exp_iter_deriv_within (n m : ℕ) :
    EqOn (iteratedDerivWithin n (fun s : ℂ => Complex.exp (2 * ↑π * Complex.I * m * s))
           {z : ℂ | 0 < z.im})
      (fun t => (2 * ↑π * Complex.I * m) ^ n * Complex.exp (2 * ↑π * Complex.I * m * t))
      {z : ℂ | 0 < z.im} := by
  intro x hx
  rw [iteratedDerivWithin_of_isOpen (isOpen_lt continuous_const continuous_im) hx]
  exact congrFun (iteratedDeriv_cexp_const_mul ..) x
