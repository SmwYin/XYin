module

public import Mathlib.Algebra.Order.Ring.Star
public import Mathlib.Analysis.CStarAlgebra.Classes
public import Mathlib.Data.Int.Star
public import Mathlib.NumberTheory.ModularForms.EisensteinSeries.UniformConvergence

@[expose] public section

open ModularForm EisensteinSeries UpperHalfPlane TopologicalSpace Set
  Metric Filter Function Complex

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat


lemma norm_symm (x y : ℤ) : ‖![x, y]‖ = ‖![y,x]‖ := by
  simp_rw [EisensteinSeries.norm_eq_max_natAbs]
  rw [max_comm]
  simp


private lemma linear_bigO_of_norm_le (z : ℍ) (v : ℤ → Fin 2 → ℤ)
    (hv : ∀ n : ℤ, |(n : ℝ)| ≤ ‖v n‖) :
    (fun n ↦ ((v n 0 : ℂ) * z + v n 1)⁻¹) =O[cofinite]
      (fun n ↦ |(n : ℝ)|⁻¹) := by
  refine Asymptotics.IsBigO.of_bound (r z)⁻¹ ?_
  filter_upwards [Filter.eventually_cofinite_ne (0 : ℤ)] with n hn
  have hn' : 0 < |(n : ℝ)| := abs_pos.mpr (Int.cast_ne_zero.mpr hn)
  have hbound := EisensteinSeries.summand_bound z zero_le_one (v n)
  simp only [Real.rpow_neg_one] at hbound
  simpa only [norm_inv, Real.norm_eq_abs, abs_inv, abs_abs] using
    hbound.trans (mul_le_mul_of_nonneg_left (inv_anti₀ hn' (hv n)) (inv_nonneg.mpr (r_pos z).le))

lemma linear_bigO (m : ℤ) (z : ℍ) : (fun (n : ℤ) => ((m : ℂ) * z + n)⁻¹) =O[cofinite]
    fun n => (|(n : ℝ)|⁻¹) := by
  exact linear_bigO_of_norm_le z (fun n ↦ ![m, n]) fun n ↦ by
    simp [EisensteinSeries.norm_eq_max_natAbs]

lemma linear_bigO_pow (m : ℤ) (z : ℍ) (k : ℕ) : (fun (n : ℤ) => ((((m : ℂ) * z + n)) ^ k )⁻¹)
  =O[cofinite]
    fun n => ((|(n : ℝ)| ^ k)⁻¹) := by
  simp_rw [← inv_pow]
  apply Asymptotics.IsBigO.pow <| linear_bigO m z

lemma Asymptotics.IsBigO.zify {α β : Type*} [Norm α] [Norm β] {f : ℤ → α} {g : ℤ → β}
    (hf : f =O[cofinite] g) :
    (fun (n : ℕ) => f n) =O[cofinite] fun n => g n := by
  exact hf.comp_tendsto Nat.cast_injective.tendsto_cofinite

lemma Asymptotics.IsBigO.of_neg {α β : Type*} [Norm α] [Norm β] {f : ℤ → α} {g : ℤ → β}
    (hf : f =O[cofinite] g) : (fun n => f (-n)) =O[cofinite] fun n => g (-n) := by
  exact hf.comp_tendsto (Equiv.neg ℤ).injective.tendsto_cofinite

lemma linear_bigO_nat (m : ℤ) (z : ℍ) : (fun (n : ℕ) => ((m : ℂ) * z + n)⁻¹) =O[cofinite]
    fun n => (|(n : ℝ)|⁻¹) := by
  exact (linear_bigO m z).zify

lemma linear_bigO' (m : ℤ) (z : ℍ) : (fun (n : ℤ) => ((n : ℂ) * z + m)⁻¹) =O[cofinite]
    fun n => (|(n : ℝ)|⁻¹) := by
  exact linear_bigO_of_norm_le z (fun n ↦ ![n, m]) fun n ↦ by
    simp [EisensteinSeries.norm_eq_max_natAbs]
