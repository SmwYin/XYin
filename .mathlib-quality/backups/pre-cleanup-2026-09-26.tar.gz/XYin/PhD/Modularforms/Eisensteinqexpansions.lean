module

public import Mathlib.NumberTheory.LSeries.Dirichlet
public import Mathlib.NumberTheory.ModularForms.EisensteinSeries.QExpansion

public import XYin.PhD.Modularforms.Delta
public import XYin.PhD.Modularforms.Summability.QExpansion

@[expose] public section

open ModularForm EisensteinSeries UpperHalfPlane TopologicalSpace Set MeasureTheory intervalIntegral
  Metric Filter Function Complex

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat

open scoped ArithmeticFunction.sigma

noncomputable section Definitions

def standardcongruencecondition : Fin 2 → ZMod ((1 : ℕ+) : ℕ) := 0

def E (k : ℤ) (hk : 3 ≤ k) : ModularForm (CongruenceSubgroup.Gamma ↑1) k :=
  (1/2 : ℂ) • eisensteinSeriesMF hk standardcongruencecondition /-they need 1/2 for the
    normalization to match up (since the sum here is taken over coprime integers).-/

open Pointwise

def gammaSetN (N : ℕ) : Set (Fin 2 → ℤ) := ({N} : Set ℕ) • gammaSet 1 1 0

def gammaSetN_map (N : ℕ) (v : gammaSetN N) : gammaSet 1 1 0 := by
  have hv2 := v.2
  simp [gammaSetN] at hv2
  rw [@mem_smul_set] at hv2
  use hv2.choose
  exact hv2.choose_spec.1

lemma gammaSet_top_mem (v : Fin 2 → ℤ) : v ∈ gammaSet 1 1 0 ↔ IsCoprime (v 0) (v 1) := by
  simp [gammaSet, ← Int.isCoprime_iff_gcd_eq_one, Subsingleton.eq_zero (Int.cast ∘ v)]

lemma gammaSetN_map_eq (N : ℕ) (v : gammaSetN N) : v.1 = N • gammaSetN_map N v := by
  have hv2 := v.2
  simp [gammaSetN] at hv2
  rw [@mem_smul_set] at hv2
  have h1 := hv2.choose_spec.2
  exact h1.symm

def gammaSetN_Equiv (N : ℕ) (hN : N ≠ 0) : gammaSetN N ≃ gammaSet 1 1 0 where
  toFun v := gammaSetN_map N v
  invFun v := by
    use N • v
    simp only [gammaSetN, singleton_smul, nsmul_eq_mul, mem_smul_set]
    use v
    simp
  left_inv v := by
    simp_rw [← gammaSetN_map_eq N v]
  right_inv v := by
    apply Subtype.ext
    exact (nsmul_right_injective hN) (gammaSetN_map_eq N _).symm


lemma gammaSetN_eisSummand (k : ℤ) (z : ℍ) (n : ℕ) (v : gammaSetN n) : eisSummand k v z =
  ((n : ℂ)^k)⁻¹ * eisSummand k (gammaSetN_map n v) z := by
  simp only [eisSummand, gammaSetN_map_eq n v, Fin.isValue, Pi.smul_apply, nsmul_eq_mul,
    Int.cast_mul, Int.cast_natCast, zpow_neg, ← mul_inv]
  congr
  rw [← mul_zpow]
  ring_nf

def GammaSet_one_Equiv : (Fin 2 → ℤ) ≃ (Σn : ℕ, gammaSetN n) where
  toFun v := ⟨(v 0).gcd (v 1), ⟨(v 0).gcd (v 1) • ![(v 0)/(v 0).gcd (v 1), (v 1)/(v 0).gcd (v 1)],
    by
  by_cases hn : 0 < (v 0).gcd (v 1)
  · apply Set.smul_mem_smul
    · simp only [Fin.isValue, mem_singleton_iff]
    · rw [gammaSet_top_mem, Int.isCoprime_iff_gcd_eq_one]
      apply Int.gcd_div_gcd_div_gcd hn
  simp only [Fin.isValue, not_lt, nonpos_iff_eq_zero] at hn
  rw [hn]
  simp only [singleton_smul, Nat.succ_eq_add_one, Nat.reduceAdd, Fin.isValue,
    CharP.cast_eq_zero, EuclideanDomain.div_zero, zero_smul, gammaSetN]
  use ![1,1]
  simp only [gammaSet_top_mem, Fin.isValue, Matrix.cons_val_zero, Matrix.cons_val_one, zero_smul,
    and_true]
  exact Int.isCoprime_iff_gcd_eq_one.mpr rfl ⟩⟩
  invFun v := v.2
  left_inv v := by
            ext i
            fin_cases i
            · exact Int.mul_ediv_cancel' (Int.gcd_dvd_left (v 0) (v 1))
            · exact Int.mul_ediv_cancel' (Int.gcd_dvd_right (v 0) (v 1))
  right_inv v := by
           ext i
           · have hv2 := v.2.2
             simp only [gammaSetN, singleton_smul, mem_smul_set] at hv2
             obtain ⟨x, hx⟩ := hv2
             simp_rw [← hx.2]
             simp only [Fin.isValue, Pi.smul_apply, nsmul_eq_mul]
             have hg := hx.1.2
             rw [Int.gcd_mul_left, hg]
             omega
           · fin_cases i
             · refine Int.mul_ediv_cancel' ?_
               simp
               exact Int.gcd_dvd_left _ _
             · simp
               exact Int.mul_ediv_cancel' (Int.gcd_dvd_right _ _)


theorem q_exp_iden_2 (k : ℕ) (hk : 3 ≤ k) (hk2 : Even k) (z : ℍ) :
    ∑' x : ℤ × ℤ, 1 / ((x.1 : ℂ) * z + x.2) ^ k =
      2 * (riemannZeta (k)) + 2 * ∑' c : ℕ+, ∑' d : ℤ, 1 / (c * (z : ℂ) + d) ^ k := by
  have hs : Summable fun x : ℤ × ℤ ↦ 1 / ((x.1 : ℂ) * z + x.2) ^ k := by
    simpa [eisSummand] using summable_prod_eisSummand hk z
  rw [hs.tsum_prod, tsum_int_eq_zero_add_two_mul_tsum_pnat (fun n ↦ ?_) hs.prod]
  · simpa using congrArg (· + 2 * ∑' c : ℕ+, ∑' d : ℤ, 1 / (c * (z : ℂ) + d) ^ k)
      (two_mul_riemannZeta_eq_tsum_int_inv_pow_of_even (by lia) hk2).symm
  · nth_rw 1 [← tsum_comp_neg]
    exact tsum_congr fun d ↦ by
      simp [← neg_add _ (d : ℂ), -neg_add_rev, hk2.neg_pow]


lemma EQ0 (k : ℕ) (z : ℍ) : ∑' (x : Fin 2 → ℤ),
    1 / (x 0 * (z : ℂ) + x 1) ^ ↑k = ∑' x : ℤ × ℤ, 1 / ((x.1 : ℂ) * z + x.2) ^ k := by
  simpa using (piFinTwoEquiv fun _ ↦ ℤ).tsum_eq
    (fun x : ℤ × ℤ ↦ 1 / ((x.1 : ℂ) * z + x.2) ^ k)


lemma EQ1 (k : ℕ) (hk : 3 ≤ (k : ℤ)) (hk2 : Even k) (z : ℍ) : ∑' (x : Fin 2 → ℤ),
    1 / (x 0 * (z : ℂ) + x 1) ^ ↑k = 2 * riemannZeta ↑k +
    2 * ((-2 * ↑π * Complex.I) ^ k / ↑(k - 1)!) *
     ∑' (n : ℕ+), ↑((σ (k - 1)) ↑n) * cexp (2 * ↑π * Complex.I * ↑z * ↑↑n) := by
  simpa [eisSummand, ← Complex.exp_nat_mul, mul_comm, mul_left_comm] using
    tsum_eisSummand_eq_tsum_sigma_mul_cexp_pow (show 3 ≤ k by lia) hk2 z


lemma EQ22 (k : ℕ) (hk : 3 ≤ (k : ℤ)) (z : ℍ) :
    ∑' (x : Fin 2 → ℤ), eisSummand k x z =
    (riemannZeta (k)) * ∑' (c : gammaSet 1 1 0), eisSummand k c z := by
  simpa [eisensteinSeries] using
    tsum_eisSummand_eq_riemannZeta_mul_eisensteinSeries (show 3 ≤ k by lia) z

lemma EQ2 (k : ℕ) (hk : 3 ≤ (k : ℤ)) (z : ℍ) : ∑' (x : Fin 2 → ℤ),
    1 / (x 0 * (z : ℂ) + x 1) ^ ↑k = (riemannZeta (k)) * ∑' (c : gammaSet 1 1 0),
    1 / ((c.1 0) * (z : ℂ) + (c.1 1)) ^ k := by
  simpa [eisSummand] using EQ22 k hk z

/-This result is already proven in the modular forms repo and being PRed (slowly) into mathlib, so
we can use it freely here. -/
lemma E_k_q_expansion (k : ℕ) (hk : 3 ≤ (k : ℤ)) (hk2 : Even k) (z : ℍ) :
    (E k hk) z = 1 +
        (1 / (riemannZeta (k))) * ((-2 * ↑π * Complex.I) ^ k / (k - 1)!) *
        ∑' n : ℕ+, σ (k - 1) n * Complex.exp (2 * ↑π * Complex.I * z * n) := by
  simpa [_root_.E, ModularForm.E, standardcongruencecondition, ← Complex.exp_nat_mul,
    mul_comm, mul_left_comm, mul_assoc, div_eq_mul_inv] using
    EisensteinSeries.q_expansion_riemannZeta (show 3 ≤ k by lia) hk2 z
