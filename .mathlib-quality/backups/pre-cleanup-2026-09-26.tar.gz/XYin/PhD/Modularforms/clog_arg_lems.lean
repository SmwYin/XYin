module

public import Mathlib.Algebra.Order.Ring.Star
public import Mathlib.Analysis.CStarAlgebra.Classes
public import Mathlib.Analysis.Complex.UpperHalfPlane.FunctionsBoundedAtInfty
public import Mathlib.Analysis.SpecialFunctions.Log.Summable
public import Mathlib.LinearAlgebra.Complex.FiniteDimensional
public import Mathlib.Tactic.Cases

@[expose] public section

open UpperHalfPlane TopologicalSpace Set MeasureTheory intervalIntegral
  Metric Filter Function Complex

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat


lemma arg_pow_aux (n : ℕ) (x : ℂ) (hx : x ≠ 0) (hna : |arg x| < π / n) :
  Complex.arg (x ^ n) = n * Complex.arg x := by
  induction n with
  | zero => simp only [pow_zero, arg_one, CharP.cast_eq_zero, zero_mul]
  | succ n hn2 =>
    by_cases hn0 : n = 0
    · simp only [hn0, zero_add, pow_one, Nat.cast_one, one_mul]
    · rw [pow_succ, arg_mul, hn2, Nat.cast_add]
      · ring
      · apply lt_trans hna
        gcongr
        exact (lt_add_one n)
      · apply pow_ne_zero n hx
      · exact hx
      simp only [mem_Ioc]
      rw [hn2]
      · rw [abs_lt] at hna
        constructor
        · have hnal := hna.1
          rw [← neg_div] at hnal
          rw [div_lt_iff₀' ] at hnal
          · rw [Nat.cast_add, add_mul] at hnal
            simpa only [gt_iff_lt, Nat.cast_one, one_mul] using hnal
          · norm_cast
            omega
        · have hnal := hna.2
          rw [lt_div_iff₀', Nat.cast_add] at hnal
          · rw [add_mul] at hnal
            simpa only [ge_iff_le, Nat.cast_one, one_mul] using hnal.le
          · norm_cast
            omega
      apply lt_trans hna
      gcongr
      exact (lt_add_one n)

lemma one_add_abs_half_ne_zero {x : ℂ} (hb : ‖x‖ < 1 / 2) : 1 + x ≠ 0 := by
  intro h
  have hx : x = -1 := add_eq_zero_iff_eq_neg.mp (by simpa [add_comm] using h)
  norm_num [hx] at hb

private lemma eventually_arg_pow {α : Type*} {l : Filter α}
    (n : ℕ) (f : α → ℂ) (hf : Tendsto f l (𝓝 0)) :
    ∀ᶠ x in l, arg ((1 + f x) ^ n) = n * arg (1 + f x) := by
  by_cases hn : n = 0
  · simp [hn]
  have harg : Tendsto (fun x ↦ arg (1 + f x)) l (𝓝 0) := by
    simpa using (Complex.continuousAt_arg Complex.one_mem_slitPlane).tendsto.comp
      (by simpa using hf.const_add 1)
  have hbound := (tendsto_order.1 harg.abs).2 (π / n)
    (by simpa using div_pos Real.pi_pos (Nat.cast_pos.mpr (Nat.pos_of_ne_zero hn)))
  filter_upwards [hbound, (tendsto_order.1 hf.norm).2 (1 / 2) (by norm_num)] with x hx hx'
  exact arg_pow_aux n (1 + f x) (one_add_abs_half_ne_zero hx') hx

lemma arg_pow (n : ℕ) (f : ℕ → ℂ) (hf : Tendsto f atTop (𝓝 0)) : ∀ᶠ m : ℕ in atTop,
    Complex.arg ((1 + f m) ^ n) = n * Complex.arg (1 + f m) := by
  exact eventually_arg_pow n f hf

lemma arg_pow2 (n : ℕ) (f : ℍ → ℂ) (hf : Tendsto f atImInfty (𝓝 0)) : ∀ᶠ m : ℍ in atImInfty,
    Complex.arg ((1 + f m) ^ n) = n * Complex.arg (1 + f m) := by
  exact eventually_arg_pow n f hf

lemma clog_pow (n : ℕ) (f : ℕ → ℂ) (hf : Tendsto f atTop (𝓝 0)) : ∀ᶠ m : ℕ in atTop,
    Complex.log ((1 + f m) ^ n) = n * Complex.log (1 + f m) := by
  filter_upwards [arg_pow n f hf] with x hx
  simp only [Complex.log, hx, norm_pow, Real.log_pow, ofReal_mul, ofReal_natCast]
  ring

lemma clog_pow2 (n : ℕ) (f : ℍ → ℂ) (hf : Tendsto f atImInfty (𝓝 0)) : ∀ᶠ m : ℍ in atImInfty,
    Complex.log ((1 + f m) ^ n) = n * Complex.log (1 + f m) := by
  filter_upwards [arg_pow2 n f hf] with x hx
  simp only [Complex.log, hx, norm_pow, Real.log_pow, ofReal_mul, ofReal_natCast]
  ring

lemma log_summable_pow (f : ℕ → ℂ) (hf : Summable f) (m : ℕ) :
    Summable (fun n => Complex.log ((1 + f n)^m)) := by
  exact ((Complex.summable_log_one_add_of_summable hf).mul_left (m : ℂ)).congr_cofinite
    (Nat.cofinite_eq_atTop ▸ ((clog_pow m f hf.tendsto_atTop_zero).mono fun _ h ↦ h.symm))
