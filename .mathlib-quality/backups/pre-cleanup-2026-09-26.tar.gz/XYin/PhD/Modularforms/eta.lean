module

public import XYin.PhD.Modularforms.E2
public import XYin.PhD.Modularforms.csqrt
public import XYin.PhD.Modularforms.upperhalfplane
public import Mathlib.NumberTheory.ModularForms.DedekindEta

@[expose] public section


open ModularForm EisensteinSeries UpperHalfPlane TopologicalSpace Set MeasureTheory intervalIntegral
  Metric Filter Function Complex

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat

open scoped ArithmeticFunction.sigma


/- The eta function. Lean 4.29+ no longer allows η as an identifier name.
   We rely on mathlib's `scoped[ModularForm] notation "η" => eta`, brought into
   scope by `open ModularForm` above. -/

lemma eta_logDeriv_eql (z : ℍ) : (logDeriv (η ∘ (fun z : ℂ => -1/z))) z =
  (logDeriv ((csqrt) * η)) z := by
  have hinv : HasDerivAt (fun w : ℂ ↦ -1 / w) ((z : ℂ) ^ 2)⁻¹ z := by
    convert (hasDerivAt_inv z.ne_zero).neg using 1
    · ext w
      simp [neg_div]
    · simp
  have hlog : logDeriv csqrt z = (2 : ℂ)⁻¹ * (z : ℂ)⁻¹ := by
    change logDeriv (Complex.exp ∘ fun w ↦ (1 / 2 : ℂ) * Complex.log w) z = _
    rw [logDeriv_comp (by fun_prop)
      ((Complex.differentiableAt_log z.mem_slitPlane).const_mul _), Complex.logDeriv_exp]
    simpa using ((Complex.hasDerivAt_log z.mem_slitPlane).const_mul (1 / 2 : ℂ)).deriv
  have hE := E₂_S_transform z
  rw [logDeriv_comp (ModularForm.differentiableAt_eta_of_mem_upperHalfPlaneSet
      (by simpa using pnat_div_upper 1 z)) hinv.differentiableAt, hinv.deriv,
    show csqrt * η = (fun w ↦ csqrt w * η w) from rfl,
    logDeriv_mul _ (by simp [csqrt]) (ModularForm.eta_ne_zero z.2)
      (csqrt_differentiableAt z) (ModularForm.differentiableAt_eta_of_mem_upperHalfPlaneSet z.2),
    hlog]
  have hS : (-1 : ℂ) / z = (ModularGroup.S • z : ℍ) := by
    rw [modular_S_smul]
    simp [neg_div]
  rw [hS, ModularForm.logDeriv_eta_eq_E2, ModularForm.logDeriv_eta_eq_E2]
  change (π * Complex.I / 12) * E₂ (ModularGroup.S • z) * ((z : ℂ) ^ 2)⁻¹ =
    (2 : ℂ)⁻¹ * (z : ℂ)⁻¹ + (π * Complex.I / 12) * E₂ z
  rw [hE]
  field_simp [z.ne_zero]
  ring

lemma eta_logderivs : {z : ℂ | 0 < z.im}.EqOn (logDeriv (η ∘ (fun z : ℂ => -1/z)))
  (logDeriv ((csqrt) * η)) :=
  fun z hz ↦ eta_logDeriv_eql ⟨z, hz⟩

lemma eta_logderivs_const : ∃ z : ℂ, z ≠ 0 ∧ {z : ℂ | 0 < z.im}.EqOn ((η ∘ (fun z : ℂ => -1/z)))
  (z • ((csqrt) * η)) := by
  have hη : DifferentiableOn ℂ η {z : ℂ | 0 < z.im} :=
    fun z hz ↦ (ModularForm.differentiableAt_eta_of_mem_upperHalfPlaneSet hz).differentiableWithinAt
  have hinv : DifferentiableOn ℂ (fun z : ℂ ↦ -1 / z) {z : ℂ | 0 < z.im} :=
    DifferentiableOn.div (differentiableOn_const (-1)) differentiableOn_id
      fun z hz ↦ (⟨z, hz⟩ : ℍ).ne_zero
  have hsqrt : DifferentiableOn ℂ csqrt {z : ℂ | 0 < z.im} :=
    fun z hz ↦ (csqrt_differentiableAt ⟨z, hz⟩).differentiableWithinAt
  refine (logDeriv_eqOn_iff (hη.comp hinv ?_) (hsqrt.mul hη)
    (isOpen_lt continuous_const Complex.continuous_im)
    (convex_halfSpace_im_gt 0).isPreconnected ?_ ?_).mp eta_logderivs
  · exact fun z hz ↦ by simpa using pnat_div_upper 1 ⟨z, hz⟩
  · exact fun z hz ↦ mul_ne_zero (Complex.exp_ne_zero _) (ModularForm.eta_ne_zero hz)
  · exact fun z hz ↦ ModularForm.eta_ne_zero (by simpa using pnat_div_upper 1 ⟨z, hz⟩)

lemma eta_equality : {z : ℂ | 0 < z.im}.EqOn ((η ∘ (fun z : ℂ => -1/z)))
   ((csqrt (Complex.I))⁻¹ • ((csqrt) * η)) := by
  obtain ⟨c, hc, h⟩ := eta_logderivs_const
  have hI := h (show Complex.I ∈ {z : ℂ | 0 < z.im} by simp)
  have he : η Complex.I ≠ 0 := ModularForm.eta_ne_zero (by simp)
  have hc' : c * csqrt Complex.I = 1 := by
    apply (mul_right_cancel₀ he)
    simpa [mul_assoc] using hI.symm
  have hcval : c = (csqrt Complex.I)⁻¹ := (mul_eq_one_iff_eq_inv₀ (by simp [csqrt])).mp hc'
  simpa [hcval] using h
