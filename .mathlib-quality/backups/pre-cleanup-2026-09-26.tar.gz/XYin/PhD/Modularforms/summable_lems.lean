/-
Copyright (c) 2026 SmwYin. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: SmwYin
-/
module

public import XYin.PhD.Modularforms.Summability.QExpansion

/-!
# Summability lemmas for modular forms

Compatibility import for the summation API, now organized into
`Summability.Basic`, `Summability.Reciprocal`, and `Summability.QExpansion`.
Import the individual modules when only part of the API is needed.
-/
