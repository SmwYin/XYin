/-
Copyright (c) 2026 SmwYin. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: SmwYin
-/
module

public import Mathlib.Analysis.Calculus.UniformLimitsDeriv
public import Mathlib.Analysis.Normed.Group.FunctionSeries
public import Mathlib.Topology.Algebra.Module.ModuleTopology
public import Mathlib.Topology.ContinuousMap.Compact
public import XYin.PhD.Modularforms.exp_lems
public import XYin.PhD.Modularforms.iteratedderivs

/-!
# Differentiation of series on the upper half-plane

Termwise differentiation follows from summable derivative bounds on compact subsets.
The exponential terms admit a common geometric majorant on each such subset; this also
bounds all of their iterated derivatives.
-/

@[expose] public section

open UpperHalfPlane TopologicalSpace Set
  Metric Filter Function Complex

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat

abbrev ℍ' := {z : ℂ | 0 < z.im}

lemma upper_half_plane_isOpen :
    IsOpen ℍ' := by
  apply isOpen_lt (by fun_prop) (by fun_prop)

theorem hasDerivAt_tsum_fun {α : Type _} (f : α → ℂ → ℂ)
    {s : Set ℂ} (hs : IsOpen s) (x : ℂ) (hx : x ∈ s)
    (hf : ∀ y : ℂ, y ∈ s → Summable fun n : α => f n y)
    (hu :∀ K ⊆ s, IsCompact K →
          ∃ u : α → ℝ, Summable u ∧ ∀ (n : α) (k : K), ‖(derivWithin (f n) s k)‖ ≤ u n)
    (hf2 : ∀ (n : α) (r : s), DifferentiableAt ℂ (f n) r) :
    HasDerivAt (fun z => ∑' n : α, f n z) (∑' n : α, derivWithin (fun z => f n z) s x) x := by
  refine hasDerivAt_of_tendstoLocallyUniformlyOn hs
    (f := fun t : Finset α ↦ fun y ↦ ∑ n ∈ t, f n y)
    (f' := fun t : Finset α ↦ fun y ↦ ∑ n ∈ t, derivWithin (f n) s y) ?_ ?_
    (g' := fun y ↦ ∑' n, derivWithin (f n) s y)
    (fun y hy ↦ (hf y hy).hasSum) hx
  · rw [tendstoLocallyUniformlyOn_iff_forall_isCompact hs]
    intro K hKs hK
    obtain ⟨u, hu, hbound⟩ := hu K hKs hK
    exact tendstoUniformlyOn_tsum hu fun n y hy ↦ hbound n ⟨y, hy⟩
  · filter_upwards with t y hy
    exact HasDerivAt.fun_sum fun n _ ↦
      ((hf2 n ⟨y, hy⟩).differentiableWithinAt.hasDerivWithinAt).hasDerivAt
        (hs.mem_nhds hy)

theorem derivWithin_tsum_fun' {α : Type _} (f : α → ℂ → ℂ) {s : Set ℂ}
    (hs : IsOpen s) (x : ℂ) (hx : x ∈ s) (hf : ∀ y ∈ s, Summable fun n : α => f n y)
    (hu :∀ K ⊆ s, IsCompact K →
          ∃ u : α → ℝ, Summable u ∧ ∀ n (k : K), ‖derivWithin (f n) s k‖ ≤ u n)
    (hf2 : ∀ n (r : s), DifferentiableAt ℂ (f n) r) :
    derivWithin (fun z => ∑' n : α, f n z) s x = ∑' n : α, derivWithin (fun z => f n z) s x :=
  (hasDerivAt_tsum_fun f hs x hx hf hu hf2).hasDerivWithinAt.derivWithin
    (hs.uniqueDiffWithinAt hx)

theorem hasDerivWithinAt_tsum_fun {α : Type _} (f : α → ℂ → ℂ)
    {s : Set ℂ} (hs : IsOpen s) (x : ℂ) (hx : x ∈ s)
    (hf : ∀ y : ℂ, y ∈ s → Summable fun n : α => f n y)
    (hu :
      ∀ K ⊆ s, IsCompact K →
          ∃ u : α → ℝ, Summable u ∧ ∀ (n : α) (k : K), ‖(derivWithin (f n) s k)‖ ≤ u n)
    (hf2 : ∀ (n : α) (r : s), DifferentiableAt ℂ (f n) r) :
    HasDerivWithinAt (fun z => ∑' n : α, f n z) (∑' n : α, derivWithin (fun z => f n z) s x) s x :=
  (hasDerivAt_tsum_fun f hs x hx hf hu hf2).hasDerivWithinAt

theorem der_iter_eq_der_aux2 (k n : ℕ) (r : ℍ') :
  DifferentiableAt ℂ
    (fun z : ℂ =>
      iteratedDerivWithin k (fun s : ℂ => Complex.exp (2 * ↑π * Complex.I * n * s)) ℍ' z) ↑r := by
  have hh : DifferentiableOn ℂ (fun z ↦ (2 * ↑π * Complex.I * n) ^ k *
      Complex.exp (2 * ↑π * Complex.I * n * z)) ℍ' := by fun_prop
  exact (hh.congr fun z hz ↦ exp_iter_deriv_within k n hz).differentiableAt
    (upper_half_plane_isOpen.mem_nhds r.2)

theorem der_iter_eq_der2 (k n : ℕ) (r : ℍ') :
    deriv (iteratedDerivWithin k (fun s : ℂ => Complex.exp (2 * ↑π * Complex.I * n * s)) ℍ') ↑r =
      derivWithin (iteratedDerivWithin k (fun s : ℂ => Complex.exp (2 * ↑π * Complex.I * n * s)) ℍ')
        ℍ'
        ↑r :=
  ((der_iter_eq_der_aux2 k n r).derivWithin
    (upper_half_plane_isOpen.uniqueDiffWithinAt r.2)).symm

theorem der_iter_eq_der2' (k n : ℕ) (r : ℍ') :
    derivWithin (iteratedDerivWithin k (fun s : ℂ => Complex.exp (2 * ↑π * Complex.I * n * s)) ℍ')
      ℍ' ↑r =
      iteratedDerivWithin (k + 1) (fun s : ℂ => Complex.exp (2 * ↑π * Complex.I * n * s)) ℍ' ↑r :=
  by
  rw [iteratedDerivWithin_succ]

noncomputable def cts_exp_two_pi_n (K : Set ℂ) : ContinuousMap K ℂ where
  toFun := fun r : K => Complex.exp (2 * ↑π * Complex.I * r)

theorem iter_deriv_comp_bound3 (K : Set ℂ) (hK1 : K ⊆ ℍ') (hK2 : IsCompact K) (k : ℕ) :
    ∃ u : ℕ → ℝ,
      Summable u ∧
        ∀ (n : ℕ) (r : K),
          (2 * |π| * n) ^ k * ‖(Complex.exp (2 * ↑π * Complex.I * n * r))‖ ≤ u n := by
  letI : CompactSpace K := isCompact_iff_compactSpace.mp hK2
  let r := ‖cts_exp_two_pi_n K‖
  have hr : ‖r‖ < 1 := by
    rw [norm_norm]
    exact ((cts_exp_two_pi_n K).norm_lt_iff zero_lt_one).2 fun z ↦
      exp_upperHalfPlane_lt_one ⟨z, hK1 z.2⟩
  refine ⟨fun n ↦ (2 * |π| * n) ^ k * r ^ n, ?_, ?_⟩
  · simpa [r, mul_pow, mul_assoc] using
      (summable_norm_pow_mul_geometric_of_norm_lt_one k hr).mul_left ((2 * |π|) ^ k)
  · intro n z
    have heq : Complex.exp (2 * ↑π * Complex.I * n * z) =
        Complex.exp (2 * ↑π * Complex.I * z) ^ n := by
      rw [← Complex.exp_nat_mul]
      congr 1
      ring
    rw [heq, norm_pow]
    have hbound := (cts_exp_two_pi_n K).norm_coe_le_norm z
    change ‖Complex.exp (2 * ↑π * Complex.I * z)‖ ≤ r at hbound
    exact mul_le_mul_of_nonneg_left
      (pow_le_pow_left₀ (norm_nonneg _) hbound n) (by positivity)

theorem iter_deriv_comp_bound2 (K : Set ℂ) (hK1 : K ⊆ ℍ') (hK2 : IsCompact K) (k : ℕ) :
    ∃ u : ℕ → ℝ,
      Summable u ∧
        ∀ (n : ℕ) (r : K),
        ‖(derivWithin (iteratedDerivWithin k
          (fun s : ℂ => Complex.exp (2 * ↑π * Complex.I * n * s)) ℍ') ℍ' r)‖ ≤ u n := by
  obtain ⟨u, hu, hbound⟩ := iter_deriv_comp_bound3 K hK1 hK2 (k + 1)
  refine ⟨u, hu, fun n z ↦ ?_⟩
  rw [der_iter_eq_der2' k n ⟨z, hK1 z.2⟩, exp_iter_deriv_within (k + 1) n (hK1 z.2)]
  simpa [norm_mul, norm_pow] using hbound n z
