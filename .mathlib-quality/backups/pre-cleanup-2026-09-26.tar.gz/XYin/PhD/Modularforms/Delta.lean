module

public import XYin.PhD.Modularforms.SlashActionAuxil
public import XYin.PhD.Modularforms.clog_arg_lems
public import XYin.PhD.Modularforms.eta
public import XYin.PhD.Modularforms.multipliable_lems
public import XYin.PhD.Modularforms.ResToImagAxis
public import Mathlib.NumberTheory.ModularForms.Discriminant
public import Mathlib.NumberTheory.ModularForms.QExpansion
public import XYin.PhD.Modularforms.NormNumI

public import XYin.PhD.Modularforms.ForMathlib_Cusps

@[expose] public section

open ModularForm EisensteinSeries UpperHalfPlane TopologicalSpace Set MeasureTheory intervalIntegral
  Metric Filter Function Complex MatrixGroups

open scoped Interval Real NNReal ENNReal Topology BigOperators Nat

open ArithmeticFunction

noncomputable section Definitions

/- The discriminant form -/
def Δ (z : UpperHalfPlane) := cexp (2 * π * Complex.I * z) * ∏' (n : ℕ),
    (1 - cexp (2 * π * Complex.I * (n + 1) * z)) ^ 24

lemma DiscriminantProductFormula (z : ℍ) : Δ z = cexp (2 * π * Complex.I * z) * ∏' (n : ℕ+),
    (1 - cexp (2 * π * Complex.I * (n) * z)) ^ 24 := by
  simpa [Δ, Nat.cast_add, Nat.cast_one] using congrArg
    (cexp (2 * π * Complex.I * z) * ·)
    (tprod_pnat_eq_tprod_succ (f := fun n : ℕ ↦
      (1 - cexp (2 * π * Complex.I * n * z)) ^ 24)).symm

lemma Delta_eq_eta_pow (z : ℍ) : Δ z = (η z) ^ 24 := by
  simpa [Δ, ModularForm.discriminant, Periodic.qParam, ModularForm.eta_q_eq_cexp]
    using (ModularForm.discriminant_eq_q_prod z).symm

private lemma delta_eq_discriminant : Δ = ModularForm.discriminant :=
  funext Delta_eq_eta_pow

/-This should be easy from the definition and the Mulitpliable bit. -/
lemma Δ_ne_zero (z : UpperHalfPlane) : Δ z ≠ 0 := by
  rw [Delta_eq_eta_pow]
  simpa [ModularForm.eta] using (ModularForm.eta_ne_zero (z := (z : ℂ)) z.2)

/-This one is easy.-/
lemma Discriminant_T_invariant : (Δ ∣[(12 : ℤ)] ModularGroup.T) = Δ := by
  rw [delta_eq_discriminant]
  exact ModularForm.discriminant_T_invariant

/-This is the hard one. -/
lemma Discriminant_S_invariant : (Δ ∣[(12 : ℤ)] ModularGroup.S) = Δ := by
  rw [delta_eq_discriminant]
  exact ModularForm.discriminant_S_invariant

/-- Δ as a SlashInvariantForm of weight 12 -/
def Discriminant_SIF : SlashInvariantForm (CongruenceSubgroup.Gamma 1) 12 where
  toFun := Δ
  slash_action_eq' :=
    slashaction_generators_GL2R Δ 12 Discriminant_S_invariant Discriminant_T_invariant

/-- Δ is 1-periodic: Δ(z + 1) = Δ(z) -/
lemma Δ_periodic (z : ℍ) : Δ ((1 : ℝ) +ᵥ z) = Δ z := by
  simpa using SlashInvariantForm.vAdd_width_periodic 1 12 1 Discriminant_SIF z

/-- Δ transforms under S as: Δ(-1/z) = z¹² · Δ(z) -/
lemma Δ_S_transform (z : ℍ) : Δ (ModularGroup.S • z) = z ^ (12 : ℕ) * Δ z := by
  have h := congrFun Discriminant_S_invariant z
  rw [SL_slash_apply, ModularGroup.denom_S, zpow_neg] at h
  norm_cast at h
  simpa [mul_comm] using (mul_inv_eq_iff_eq_mul₀ (pow_ne_zero 12 z.ne_zero)).mp h

lemma I_in_atImInfty (A : ℝ) : { z : ℍ | A ≤ z.im} ∈ atImInfty := by
  rw [atImInfty_mem]
  use A
  simp only [mem_setOf_eq, imp_self, implies_true]


instance natPosSMul : SMul ℕ+ ℍ where
  smul x z := UpperHalfPlane.mk (x * z) <| by simp; apply z.2

theorem natPosSMul_apply (c : ℕ+) (z : ℍ) : ((c • z : ℍ) : ℂ) = (c : ℂ) * (z : ℂ) := by rfl

def pnat_smul_stable (S : Set ℍ) := ∀ n : ℕ+, ∀ (s : ℍ), s ∈ S → n • s ∈ S

lemma atImInfy_pnat_mono (S : Set ℍ) (hS : S ∈ atImInfty) (B : ℝ) : ∃ A : ℝ,
    pnat_smul_stable (S ∩ {z : ℍ | max A B ≤ z.im}) ∧ S ∩ {z : ℍ | max A B ≤ z.im} ∈ atImInfty := by
  have hS2 := hS
  rw [atImInfty_mem] at hS
  obtain ⟨A, hA⟩ := hS
  use A
  constructor
  · intro n s hs
    simp only [mem_inter_iff, mem_setOf_eq] at *
    have K : max A B ≤ (n • s).im := by
      rw [UpperHalfPlane.im, natPosSMul_apply]
      simp only [mul_im, natCast_re, coe_im, natCast_im, coe_re, zero_mul, add_zero]
      have hs2 := hs.2
      simp at *
      constructor
      · apply le_trans hs2.1
        have hn : (1 : ℝ) ≤ n := by
          norm_cast
          exact PNat.one_le n
        apply (le_mul_iff_one_le_left s.2).mpr hn
      apply le_trans hs2.2
      have hn : (1 : ℝ) ≤ n := by
        norm_cast
        exact PNat.one_le n
      apply (le_mul_iff_one_le_left s.2).mpr hn
    refine ⟨?_, K⟩
    simp at K
    apply hA _ K.1
  · simp only [ inter_mem_iff, hS2, true_and]
    apply I_in_atImInfty

lemma cexp_two_pi_I_im_antimono (a b : ℍ) (h : a.im ≤ b.im) (n : ℕ) :
    ‖(cexp (2 * ↑π * Complex.I * n * b))‖
    ≤ ‖(cexp (2 * ↑π * Complex.I *n * a))‖:= by
  simp_rw [Complex.norm_exp]
  simp
  gcongr

theorem tendsto_neg_cexp_atImInfty (k : ℕ) :
  Tendsto (fun x : ℍ ↦ -cexp (2 * ↑π * Complex.I * (↑k + 1) * ↑x)) atImInfty (𝓝 0) := by
  have := Tendsto.neg (f := (fun x : ℍ ↦ cexp (2 * ↑π * Complex.I * (↑k + 1) * ↑x)))
    (l := atImInfty) (y := 0)
  simp only [neg_zero] at this
  apply this
  refine tendsto_exp_nhds_zero_iff.mpr ?_
  simp
  apply Filter.Tendsto.const_mul_atTop (by positivity)
  exact tendsto_iff_comap.mpr fun ⦃U⦄ a ↦ a

theorem log_one_neg_cexp_tendto_zero (k : ℕ) :
  Tendsto (fun x : ℍ ↦ Complex.log ((1 - cexp (2 * ↑π * Complex.I * (↑k + 1) * ↑x)) ^ 24))
    atImInfty (𝓝 0) := by
  simpa [sub_eq_add_neg] using (continuousAt_clog Complex.one_mem_slitPlane).tendsto.comp
    (by simpa using ((tendsto_neg_cexp_atImInfty k).const_add 1).pow 24)

variable {α ι : Type*}

lemma Complex.cexp_tsum_eq_tprod_func (f : ι → α → ℂ) (hfn : ∀ x n, f n x ≠ 0)
    (hf : ∀ x : α, Summable fun n => log (f n x)) :
    (cexp ∘ (fun a : α => (∑' n : ι, log (f n a)))) = fun a : α => ∏' n : ι, f n a := by
  funext x
  exact Complex.cexp_tsum_eq_tprod (hfn x) (hf x)

theorem Delta_boundedfactor :
  Tendsto (fun x : ℍ ↦ ∏' (n : ℕ), (1 - cexp (2 * ↑π * Complex.I * (↑n + 1) * ↑x)) ^ 24) atImInfty
    (𝓝 1) := by
  simpa [ModularForm.eta_q_eq_cexp] using
    ModularForm.tendsto_atImInfty_tprod_one_sub_eta_q_pow

open Real

lemma Discriminant_zeroAtImInfty :
    ∀ γ ∈ 𝒮ℒ, IsZeroAtImInfty (Discriminant_SIF ∣[(12 : ℤ)] (γ : GL (Fin 2) ℝ)) := by
  intro γ ⟨γ', hγ⟩
  have hinv := Discriminant_SIF.slash_action_eq' γ
    ⟨γ', CongruenceSubgroup.mem_Gamma_one γ', hγ⟩
  change (⇑Discriminant_SIF ∣[12] γ) = Discriminant_SIF at hinv
  rw [hinv]
  change IsZeroAtImInfty Δ
  rw [delta_eq_discriminant]
  exact ModularForm.discriminant_isZeroAtImInfty

def Delta : CuspForm (CongruenceSubgroup.Gamma 1) 12 where
  toFun := Discriminant_SIF
  slash_action_eq' := Discriminant_SIF.slash_action_eq'
  holo' := by
    rw [mdifferentiable_iff]
    simp only [SlashInvariantForm.coe_mk]
    have he2 : DifferentiableOn ℂ (fun z => (η z) ^ 24) {z | 0 < z.im} := by
      apply DifferentiableOn.pow
      intro x hx
      apply DifferentiableAt.differentiableWithinAt
      simpa [ModularForm.eta] using (ModularForm.differentiableAt_eta_of_mem_upperHalfPlaneSet (z := x) hx)
    rw [Discriminant_SIF]
    simp only [SlashInvariantForm.coe_mk]
    apply he2.congr
    intro z hz
    have := Delta_eq_eta_pow (⟨z, hz⟩ : ℍ)
    simp only [comp_apply] at *
    rw [ofComplex_apply_of_im_pos hz]
    exact this
  zero_at_cusps' hc := zero_at_cusps_of_zero_at_infty hc Discriminant_zeroAtImInfty

lemma Delta_apply (z : ℍ) : Delta z = Δ z := by rfl

lemma Delta_isTheta_rexp : Delta =Θ[atImInfty] (fun τ => Real.exp (-2 * π * τ.im)) := by
  refine ⟨by simpa using CuspFormClass.exp_decay_atImInfty (h := 1) Delta, ?_⟩
  change (fun τ ↦ Real.exp (-2 * π * τ.im)) =O[atImInfty] Δ
  rw [delta_eq_discriminant]
  exact ModularForm.exp_isBigO_discriminant

lemma CuspForm_apply (k : ℤ) (f : CuspForm (CongruenceSubgroup.Gamma 1) k) (z : ℍ) :
  f.toFun z = f z := by rfl

theorem div_Delta_is_SIF (k : ℤ) (f : CuspForm (CongruenceSubgroup.Gamma 1) k)
    (γ : GL (Fin 2) ℝ)
    (hγ : γ ∈ Subgroup.map (Matrix.SpecialLinearGroup.mapGL ℝ) (CongruenceSubgroup.Gamma 1)) :
    (⇑f / ⇑Delta) ∣[k - 12] γ = ⇑f / ⇑Delta := by
  obtain ⟨A, hA, rfl⟩ := hγ
  change (⇑f / ⇑Delta) ∣[k - 12] A = ⇑f / ⇑Delta
  rw [div_slash_SL2]
  exact congrArg₂ (· / ·)
    (f.slash_action_eq' _ (Subgroup.mem_map_of_mem _ hA))
    (Delta.slash_action_eq' _ (Subgroup.mem_map_of_mem _ hA))

def CuspForm_div_Discriminant (k : ℤ) (f : CuspForm (CongruenceSubgroup.Gamma 1) k) :
  ModularForm (CongruenceSubgroup.Gamma 1) (k - 12) where
    toFun := f / Delta
    slash_action_eq' := by
      intro γ hγ
      exact div_Delta_is_SIF _ _ γ hγ
    holo' := by
      rw [mdifferentiable_iff]
      simp only [SlashInvariantForm.coe_mk]
      have : (⇑f / ⇑Delta) ∘ ↑ofComplex = (⇑f ∘ ↑ofComplex) / (Delta ∘ ↑ofComplex) := by rfl
      rw [this]
      apply DifferentiableOn.div
      · simpa only [CuspForm.toSlashInvariantForm_coe] using
        (UpperHalfPlane.mdifferentiable_iff.mp f.holo')
      · simpa only [CuspForm.toSlashInvariantForm_coe] using
        (UpperHalfPlane.mdifferentiable_iff.mp Delta.holo')
      · intro x hx
        have := Δ_ne_zero ⟨x, hx⟩
        simp only [comp_apply, ne_eq]
        rw [ofComplex_apply_of_im_pos hx]
        apply this
    bdd_at_cusps' {c} hc := by
      apply bounded_at_cusps_of_bounded_at_infty hc
      intro A ⟨A', hA'⟩
      have h1 := CuspFormClass.exp_decay_atImInfty (h := 1) f zero_lt_one (by simp)
      have h2 := Delta_isTheta_rexp.2
      rw [IsBoundedAtImInfty, BoundedAtFilter] at *
      rw [Asymptotics.isBigO_iff'] at h1 ⊢
      rw [Asymptotics.isBigO_iff''] at h2
      simp only [gt_iff_lt, neg_mul, div_one, Real.norm_eq_abs,
        Real.abs_exp, Pi.one_apply, norm_one, mul_one] at *
      obtain ⟨e1, he1, hf⟩ := h1
      obtain ⟨e2, he2, hD⟩ := h2
      use e1/e2
      refine ⟨ by positivity, ?_⟩
      rw [eventually_iff_exists_mem] at *
      obtain ⟨A1, hA, hA2⟩ := hf
      obtain ⟨B2, hB2, hB3⟩ := hD
      use min A1 B2
      refine ⟨by simp [hA, hB2], ?_⟩
      intro z hz
      have : ((⇑f / ⇑Delta) ∣[k - 12] (A: GL (Fin 2) ℝ)) z = ((⇑f z / ⇑Delta z)) := by
        have := congrFun (div_Delta_is_SIF k f A'
                            (Subgroup.mem_map.mp ⟨A', CongruenceSubgroup.mem_Gamma_one A', rfl⟩)) z
        rw [← hA']
        simpa [SL_slash, Pi.div_apply] using this
      rw [this]
      simp
      have he1e2 : e1 / e2 = (e1 * rexp (-(2 * π * z.im))) / (e2 * rexp (-(2 * π * z.im))) := by
        refine Eq.symm (mul_div_mul_right e1 e2 (Real.exp_ne_zero _))
      rw [he1e2]
      apply div_le_div₀
      · positivity
      · apply hA2
        apply hz.1
      · positivity
      · apply hB3
        apply hz.2

lemma CuspForm_div_Discriminant_apply (k : ℤ) (f : CuspForm (CongruenceSubgroup.Gamma 1) k)
    (z : ℍ) : (CuspForm_div_Discriminant k f) z = f z / Δ z := rfl

theorem CuspForm_div_Discriminant_Add (k : ℤ) (x y : CuspForm (CongruenceSubgroup.Gamma 1) k) :
  (fun f ↦ CuspForm_div_Discriminant k f) (x + y) =
    (fun f ↦ CuspForm_div_Discriminant k f) x + (fun f ↦ CuspForm_div_Discriminant k f) y := by
  ext z
  simp only [CuspForm_div_Discriminant_apply, CuspForm.add_apply, ModularForm.add_apply]
  ring

lemma cexp_aux1 (t : ℝ) : cexp (2 * ↑π * Complex.I * (Complex.I * t)) = rexp (-2 * π * t) := by
  calc
    _ = cexp (2 * ↑π * (Complex.I * Complex.I) * t) := by ring_nf
    _ = rexp (-2 * π * t) := by simp

lemma cexp_aux2 (t : ℝ) (n : ℕ)
    : cexp (2 * π * Complex.I * (n + 1) * (Complex.I * t)) = rexp (-(2 * π * (n + 1) * t)) := by
  calc
    _ = cexp (2 * ↑π * (n + 1) * (Complex.I * Complex.I) * t) := by ring_nf
    _ = rexp (-(2 * π * (n + 1) * t)) := by simp

lemma cexp_aux3 (t : ℝ) (n : ℕ) (ht : 0 < t) : 0 < 1 - rexp (-(2 * π * (n + 1) * t)) := by
  have _ : rexp (-(2 * π * (n + 1) * t)) < 1 := exp_lt_one_iff.mpr (by simp; positivity)
  linarith

lemma cexp_aux4 (t : ℝ) (n : ℕ) : (cexp (-2 * π * (n + 1) * t)).im = 0 := by
  simpa [Complex.ofReal_mul, Complex.ofReal_neg] using exp_ofReal_im (-2 * π * (n + 1) * t)

lemma cexp_aux5 (t : ℝ) : (cexp (-(2 * π * t))).im = 0 := by
  simpa [Complex.ofReal_mul, Complex.ofReal_neg] using exp_ofReal_im (-(2 * π * t))

/- Auxiliary lemmas for imaginary part of products and powers -/
lemma Complex.im_finset_prod_eq_zero_of_im_eq_zero {ι : Type*} (s : Finset ι)
    (f : ι → ℂ) (h : ∀ i ∈ s, (f i).im = 0) :
    (∏ i ∈ s, f i).im = 0 := by
  classical
  revert h; refine Finset.induction_on s (fun _ => by simp) ?_; intro a s ha ih h
  simp [Finset.prod_insert, ha, Complex.mul_im, h a (by simp),
    ih (fun i hi => h i (by simp [hi]))]

lemma Complex.im_pow_eq_zero_of_im_eq_zero {z : ℂ} (hz : z.im = 0) (m : ℕ) :
    (z ^ m).im = 0 := by
  rw [← Complex.re_add_im z, hz]
  simp [← Complex.ofReal_pow]

lemma Complex.im_tprod_eq_zero_of_im_eq_zero (f : ℕ → ℂ)
    (hf : Multipliable f) (him : ∀ n, (f n).im = 0) :
    (∏' n : ℕ, f n).im = 0 := by
  classical
  have hz : ∀ n, (∏ i ∈ Finset.range n, f i).im = 0 := fun n =>
    Complex.im_finset_prod_eq_zero_of_im_eq_zero (s := Finset.range n) (f := f)
      (by intro i _; simpa using him i)
  have h1 := ((Complex.continuous_im.tendsto _).comp hf.hasProd.tendsto_prod_nat)
  have h2 : Tendsto (fun n => (∏ i ∈ Finset.range n, f i).im) atTop (𝓝 (0 : ℝ)) := by simp [hz]
  exact tendsto_nhds_unique h1 h2

/- Δ(it) is real on the (positive) imaginary axis. -/
lemma Delta_imag_axis_real : ResToImagAxis.Real Δ := by
  intro t ht
  simp [ResToImagAxis, ht, Δ]
  set g : ℕ → ℂ := fun n => (1 - cexp (2 * π * Complex.I * (n + 1) * (Complex.I * t))) ^ 24
  have hArg (n : ℕ) :
      2 * (π : ℂ) * Complex.I * (n + 1) * (Complex.I * t) = -(2 * (π : ℂ) * (n + 1) * t) := by
    calc
      2 * (π : ℂ) * Complex.I * (n + 1) * (Complex.I * t)
        = 2 * (π : ℂ) * (Complex.I * Complex.I) * (n + 1) * t := by ring
      _ = -(2 * (π : ℂ) * (n + 1) * t) := by simp
  have him_g : ∀ n, (g n).im = 0 := fun n => by
    have : (cexp (-(2 * (π : ℂ) * ((n + 1) : ℂ) * t))).im = 0 := by
      simpa [mul_comm, mul_left_comm, mul_assoc] using (cexp_aux4 t n)
    have : ((1 - cexp (2 * (π : ℂ) * Complex.I * (n + 1) * (Complex.I * t))) : ℂ).im = 0 := by
      simpa [Complex.sub_im, hArg n] using this
    simpa [g] using Complex.im_pow_eq_zero_of_im_eq_zero this 24
  let z : ℍ := ⟨Complex.I * t, by simp [ht]⟩
  have hmul : Multipliable g := by
    have hz : (z : ℂ) = Complex.I * t := rfl
    simpa [g, hz] using
      (Multipliable_pow _ (by simpa using MultipliableEtaProductExpansion z) 24)
  have htprod_im : (∏' n : ℕ, g n).im = 0 :=
    Complex.im_tprod_eq_zero_of_im_eq_zero g hmul him_g
  have him_pref : (cexp (2 * π * Complex.I * (Complex.I * t))).im = 0 := by
    have : (cexp (-(2 * (π : ℂ) * t))).im = 0 := by simpa using cexp_aux5 t
    simpa [by simpa using hArg 0] using this
  simp [g, him_pref, htprod_im]

lemma re_ResToImagAxis_Delta_eq_real_prod (t : ℝ) (ht : 0 < t) :
  (Δ.resToImagAxis t).re =
    Real.exp (-2 * π * t) *
      ∏' (n : ℕ), (1 - Real.exp (-(2 * π * ((n + 1) : ℝ) * t))) ^ 24 := by
  set fR : ℕ → ℝ := fun n => (1 - Real.exp (-(2 * π * ((n + 1) : ℝ) * t))) ^ 24
  have hMap' :
      Complex.ofReal (∏' n : ℕ, fR n) = ∏' n : ℕ, ((fR n : ℝ) : ℂ) := by
    simpa using
      (Function.LeftInverse.map_tprod (f := fR)
        (g := Complex.ofRealHom.toMonoidHom)
        (hg := by simpa using Complex.continuous_ofReal)
        (hg' := Complex.continuous_re)
        (hgg' := by intro x; simp))
  simpa [ResToImagAxis, ht, Delta_apply, Δ, cexp_aux1, cexp_aux2, hMap', fR] using
    Complex.ofReal_re (Real.exp (-2 * π * t) * ∏' n : ℕ, fR n)

lemma tprod_pos_nat_im (z : ℍ) :
  0 < ∏' (n : ℕ), (1 - Real.exp (-(2 * π * ((n + 1) : ℝ) * z.im))) ^ 24 := by
  have hpos_pow : ∀ n : ℕ, 0 < (1 - Real.exp (-(2 * π * ((n + 1) : ℝ) * z.im))) ^ 24 :=
    fun n =>
      pow_pos (by simpa [mul_comm, mul_left_comm, mul_assoc] using cexp_aux3 (t := z.im) n z.2) _
  have hsum_log :
      Summable (fun n : ℕ =>
        Real.log ((1 - Real.exp (-(2 * π * ((n + 1) : ℝ) * z.im))) ^ 24)) := by
    simp only [Real.log_pow, Nat.cast_ofNat, ← smul_eq_mul]
    apply Summable.const_smul
    simp [sub_eq_add_neg]
    apply Real.summable_log_one_add_of_summable
    apply Summable.neg
    have h0 : Summable (fun n : ℕ => Real.exp (n * (-(2 * π * z.im)))) :=
      (Real.summable_exp_nat_mul_iff.mpr
        (by simpa using (neg_lt_zero.mpr (by positivity : 0 < 2 * π * z.im))))
    simpa [Nat.cast_add, Nat.cast_one, mul_comm, mul_left_comm, mul_assoc] using
      ((summable_nat_add_iff 1).2 h0)
  rw [← Real.rexp_tsum_eq_tprod
        (f := fun n : ℕ =>
          (1 - Real.exp (-(2 * π * ((n + 1) : ℝ) * z.im))) ^ 24)
        hpos_pow hsum_log]
  exact Real.exp_pos _

/- Δ(it) is positive on the (positive) imaginary axis. -/
lemma Delta_imag_axis_pos : ResToImagAxis.Pos Δ := by
  rw [ResToImagAxis.Pos]
  refine And.intro Delta_imag_axis_real ?_
  intro t ht
  have hprod :
      0 < ∏' (n : ℕ), (1 - Real.exp (-(2 * π * ((n + 1) : ℝ) * t))) ^ 24 := by
    let z : ℍ := ⟨Complex.I * t, by simp [ht]⟩
    have hz : z.im = t := by simp [UpperHalfPlane.im, z]
    simpa [hz] using tprod_pos_nat_im z
  rw [re_ResToImagAxis_Delta_eq_real_prod t ht]
  exact mul_pos (Real.exp_pos _) hprod
