/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import Mathlib.NumberTheory.Cyclotomic.Basic
import Mathlib.RingTheory.PowerSeries.Expand
import XYin.PhD.Cox.CoxMatrices.Basic

/-!
# Laurent expansions of the Cox roots

This file constructs the transformed Laurent series from equation (11.13), identifies it with
the analytic expansion of each Cox root, and defines the Galois reindexing of `C(m)`.
-/

open Complex Function MatrixGroups UpperHalfPlane

noncomputable section

namespace Cox

/-- The primitive `m`-th root used in equation (11.13). -/
def zeta (m : ℕ+) : ℂ := Complex.exp (2 * Real.pi * Complex.I / (m : ℂ))

theorem zeta_isPrimitiveRoot (m : ℕ+) : IsPrimitiveRoot (zeta m) (m : ℕ) := by
  simpa only [zeta] using
    Complex.isPrimitiveRoot_exp (m : ℕ) (PNat.ne_zero m)

/-- The integral Laurent coefficient of the analytic `j`-function. -/
noncomputable def jIntCoeff (n : ℤ) : ℤ :=
  (j_laurentQExpansion_isIntegral (n := n)).choose

theorem jIntCoeff_spec (n : ℤ) :
    (laurentqExpansion 1 j).coeff n = (jIntCoeff n : ℂ) :=
  (j_laurentQExpansion_isIntegral (n := n)).choose_spec

theorem jIntCoeff_neg_one : jIntCoeff (-1) = 1 := by
  have hcoeff : (jIntCoeff (-1) : ℂ) = 1 := by
    rw [← jIntCoeff_spec]
    calc
      (laurentqExpansion 1 j).coeff (-1) = (to_qExpansion 1 j).coeff 0 := by
        simpa [j_poleOrder] using
          (laurentqExpansion.coeff_neg_poleOrder (h := 1) (f := j))
      _ = (qExpansion 1 qj).coeff 0 := by rw [j_to_qExpansion]
      _ = 1 := qj_qExpansion_coeff_zero
  exact_mod_cast hcoeff

/-- Equation (11.13) as a formal Laurent series in `t=q^(1/m)`. -/
noncomputable def transformedJSeries {K : Type*} [Field K] {m : ℕ+}
    (ζ : K) (σ : CoxMatrix m) : LaurentSeries K :=
  ⟨fun k ↦ if (σ.a : ℤ) ^ 2 ∣ k ∧ -((σ.a : ℤ) ^ 2) ≤ k
      then (jIntCoeff (k / (σ.a : ℤ) ^ 2) : K) *
        ζ ^ (((σ.a : ℤ) * (σ.b : ℤ)) * (k / (σ.a : ℤ) ^ 2))
      else 0,
   by
    apply Set.IsWF.isPWO
    apply BddBelow.isWF
    refine ⟨-((σ.a : ℤ) ^ 2), fun k hk ↦ ?_⟩
    simp only [Function.mem_support, ne_eq] at hk
    by_contra h
    apply hk
    rw [if_neg]
    exact fun h' ↦ h h'.2⟩

theorem transformedJSeries_coeff {K : Type*} [Field K] {m : ℕ+}
    (ζ : K) (σ : CoxMatrix m) (k : ℤ) :
    (transformedJSeries ζ σ).coeff k =
      if (σ.a : ℤ) ^ 2 ∣ k ∧ -((σ.a : ℤ) ^ 2) ≤ k
      then (jIntCoeff (k / (σ.a : ℤ) ^ 2) : K) *
        ζ ^ (((σ.a : ℤ) * (σ.b : ℤ)) * (k / (σ.a : ℤ) ^ 2))
      else 0 := rfl

private def coxPhaseAux (m : ℕ+) (σ : CoxMatrix m) : ℂ :=
  zeta m ^ (σ.a * σ.b)

private theorem qParam_coxAction_aux (m : ℕ+) (σ : CoxMatrix m) (τ : ℍ) :
    Periodic.qParam 1 (σ.act τ) =
      coxPhaseAux m σ * Periodic.qParam ((m : ℕ) : ℝ) τ ^ (σ.a ^ 2) := by
  rw [Periodic.qParam, Periodic.qParam, CoxMatrix.coe_act, coxPhaseAux, zeta]
  simp only [Complex.ofReal_one, div_one]
  rw [← Complex.exp_nat_mul, ← Complex.exp_nat_mul, ← Complex.exp_add]
  congr 1
  have hm : (m : ℂ) = σ.a * σ.d := by
    exact_mod_cast σ.determinant.symm
  rw [hm]
  field_simp [show (σ.a : ℂ) ≠ 0 by exact_mod_cast σ.a_pos.ne',
    show (σ.d : ℂ) ≠ 0 by exact_mod_cast σ.d_pos.ne']
  push_cast
  rw [hm]
  ring

private theorem cuspFunction_coxCompose_aux (m : ℕ+) (σ : CoxMatrix m) (f : ℍ → ℂ)
    (hfper : Periodic (f ∘ UpperHalfPlane.ofComplex) 1) {q : ℂ}
    (hq0 : q ≠ 0) (hqnorm : ‖q‖ < 1) :
    cuspFunction ((m : ℕ) : ℝ) (fun τ : ℍ ↦ f (σ.act τ)) q =
      cuspFunction 1 f (coxPhaseAux m σ * q ^ (σ.a ^ 2)) := by
  have hmpos : (0 : ℝ) < (m : ℕ) := by exact_mod_cast PNat.pos m
  have him := Periodic.im_invQParam_pos_of_norm_lt_one hmpos hqnorm hq0
  let τ : ℍ := ⟨Periodic.invQParam ((m : ℕ) : ℝ) q, him⟩
  let w : ℍ := σ.act τ
  have hleft : cuspFunction ((m : ℕ) : ℝ) (fun z : ℍ ↦ f (σ.act z)) q = f w := by
    change Periodic.cuspFunction ((m : ℕ) : ℝ) _ q = f w
    rw [Periodic.cuspFunction_eq_of_nonzero _ _ hq0]
    simp only [Function.comp_apply]
    rw [UpperHalfPlane.ofComplex_apply_of_im_pos him]
  have hqparam : Periodic.qParam 1 w = coxPhaseAux m σ * q ^ (σ.a ^ 2) := by
    rw [show w = σ.act τ from rfl, qParam_coxAction_aux]
    rw [show Periodic.qParam ((m : ℕ) : ℝ) τ = q by
      simpa [τ] using Periodic.qParam_right_inv
        (show (((m : ℕ) : ℝ)) ≠ 0 by positivity) hq0]
  rw [hleft, ← hqparam]
  exact (UpperHalfPlane.eq_cuspFunction w one_ne_zero hfper).symm

private theorem cuspFunction_coxAction_aux (m : ℕ+) (σ : CoxMatrix m) {q : ℂ}
    (hq0 : q ≠ 0) (hqnorm : ‖q‖ < 1) :
    cuspFunction ((m : ℕ) : ℝ) (fun τ : ℍ ↦ j (σ.act τ)) q =
      cuspFunction 1 j (coxPhaseAux m σ * q ^ (σ.a ^ 2)) :=
  cuspFunction_coxCompose_aux m σ j ModularFunction.j_periodic hq0 hqnorm

private theorem coxPhase_ne_zero_aux (m : ℕ+) (σ : CoxMatrix m) :
    coxPhaseAux m σ ≠ 0 :=
  pow_ne_zero _ (Complex.exp_ne_zero _)

private theorem cuspFunction_coxAction_eventuallyEq_aux (m : ℕ+) (σ : CoxMatrix m) :
    cuspFunction ((m : ℕ) : ℝ) (fun τ : ℍ ↦ j (σ.act τ)) =ᶠ[nhdsWithin 0 ({0}ᶜ)]
      cuspFunction 1 j ∘ fun q ↦ coxPhaseAux m σ * q ^ (σ.a ^ 2) := by
  have hnorm : {q : ℂ | ‖q‖ < 1} ∈ nhdsWithin (0 : ℂ) ({0}ᶜ) :=
    nhdsWithin_le_nhds (by simpa [Metric.ball, dist_eq_norm]
      using Metric.ball_mem_nhds (0 : ℂ) zero_lt_one)
  filter_upwards [hnorm, self_mem_nhdsWithin] with q hqnorm hq
  exact cuspFunction_coxAction_aux m σ (Set.mem_compl_singleton_iff.mp hq) hqnorm

private theorem cuspFunction_coxAction_meromorphicAt_aux (m : ℕ+) (σ : CoxMatrix m) :
    MeromorphicAt (cuspFunction ((m : ℕ) : ℝ) (fun τ : ℍ ↦ j (σ.act τ))) 0 := by
  have hbase : MeromorphicAt (cuspFunction 1 j)
      (coxPhaseAux m σ * (0 : ℂ) ^ (σ.a ^ 2)) := by
    simpa [σ.a_pos.ne'] using j_cuspFunction_meromorphicAt
  exact (MeromorphicAt.comp_analyticAt
    (g := fun q : ℂ ↦ coxPhaseAux m σ * q ^ (σ.a ^ 2)) hbase (by fun_prop)).congr
    (cuspFunction_coxAction_eventuallyEq_aux m σ).symm

private theorem poleOrder_coxAction_aux (m : ℕ+) (σ : CoxMatrix m) :
    poleOrder ((m : ℕ) : ℝ) (fun τ : ℍ ↦ j (σ.act τ)) = σ.a ^ 2 := by
  let η := coxPhaseAux m σ
  let r := σ.a ^ 2
  let φ : ℂ → ℂ := fun q ↦ η * q ^ r
  have hη : η ≠ 0 := coxPhase_ne_zero_aux m σ
  have hφ0 : φ 0 = 0 := by simp [φ, r, σ.a_pos.ne']
  have hφan : AnalyticAt ℂ φ 0 := by fun_prop
  have hsuborder : analyticOrderAt (fun q ↦ φ q - φ 0) 0 = r := by
    simp only [hφ0, sub_zero]
    change analyticOrderAt ((fun _ : ℂ ↦ η) * id ^ r) 0 = r
    rw [analyticOrderAt_mul analyticAt_const (analyticAt_id.pow r),
      (analyticAt_const.analyticOrderAt_eq_zero).2 hη,
      analyticOrderAt_pow analyticAt_id, analyticOrderAt_id]
    simp
  have hφnc : ¬Filter.EventuallyConst φ (nhds 0) := by
    rw [eventuallyConst_iff_analyticOrderAt_sub_eq_top, hsuborder]
    simp
  have hbaseOrder :
      meromorphicOrderAt (cuspFunction 1 j) 0 = (-1 : WithTop ℤ) := by
    simpa [j_poleOrder] using
      (meromorphicOrderAt_cuspFunction_eq_neg_poleOrder
        (h := 1) (f := j) (by simp [j_poleOrder]))
  have hbaseMer : MeromorphicAt (cuspFunction 1 j) (φ 0) := by
    simpa [hφ0] using j_cuspFunction_meromorphicAt
  have hcompOrder :
      meromorphicOrderAt ((cuspFunction 1 j) ∘ φ) 0 = (-(r : ℤ) : ℤ) := by
    rw [hbaseMer.meromorphicOrderAt_comp hφan hφnc,
      hsuborder, hφ0, hbaseOrder, ENat.map_coe]
    change ((-1 : ℤ) : WithTop ℤ) * ((r : ℤ) : WithTop ℤ) =
      ((-(r : ℤ) : ℤ) : WithTop ℤ)
    norm_cast
    simp
  have horder :
      meromorphicOrderAt
          (cuspFunction ((m : ℕ) : ℝ) (fun τ : ℍ ↦ j (σ.act τ))) 0 =
        (-(r : ℤ) : ℤ) := by
    rw [meromorphicOrderAt_congr (by simpa [φ, η, r] using
      cuspFunction_coxAction_eventuallyEq_aux m σ)]
    exact hcompOrder
  rw [poleOrder_eq_toNat_neg_meromorphicOrderAt, horder, WithTop.untopD_coe]
  simp only [neg_neg, Int.toNat_natCast, r]

private theorem poleRemoved_coxAction_aux (m : ℕ+) (σ : CoxMatrix m) :
    poleRemoved ((m : ℕ) : ℝ) (fun τ : ℍ ↦ j (σ.act τ)) =
      fun τ ↦ (coxPhaseAux m σ)⁻¹ * qj (σ.act τ) := by
  funext τ
  rw [UpperHalfPlane.poleRemoved, poleOrder_coxAction_aux]
  rw [show qj (σ.act τ) = Periodic.qParam 1 (σ.act τ) * j (σ.act τ) by
    simp [qj, Pi.mul_apply, Periodic.qParam]]
  rw [qParam_coxAction_aux]
  field_simp [coxPhase_ne_zero_aux m σ]

private theorem to_qExpansion_coxAction_aux (m : ℕ+) (σ : CoxMatrix m) :
    to_qExpansion ((m : ℕ) : ℝ) (fun τ : ℍ ↦ j (σ.act τ)) =
      (coxPhaseAux m σ)⁻¹ •
        (PowerSeries.rescale (coxPhaseAux m σ) (qExpansion 1 qj)).expand
          (σ.a ^ 2) (pow_ne_zero _ σ.a_pos.ne') := by
  let η := coxPhaseAux m σ
  let r := σ.a ^ 2
  let g := poleRemoved ((m : ℕ) : ℝ) (fun τ : ℍ ↦ j (σ.act τ))
  let P : PowerSeries ℂ :=
    η⁻¹ • (PowerSeries.rescale η (qExpansion 1 qj)).expand r
      (pow_ne_zero _ σ.a_pos.ne')
  have hrpos : 0 < r := pow_pos σ.a_pos 2
  have hgan : AnalyticAt ℂ (cuspFunction ((m : ℕ) : ℝ) g) 0 :=
    analyticAt_cuspFunction_poleRemoved
      (cuspFunction_coxAction_meromorphicAt_aux m σ)
  have hsum : ∀ τ : ℍ,
      HasSum (fun n ↦ P.coeff n • Periodic.qParam ((m : ℕ) : ℝ) τ ^ n) (g τ) := by
    intro τ
    let x := Periodic.qParam ((m : ℕ) : ℝ) τ
    have hbase := (hasSum_qExpansion_qj (τ := σ.act τ)).mul_left η⁻¹
    have hreindexed : HasSum
        ((fun n ↦ P.coeff n • x ^ n) ∘ fun n ↦ r * n) (g τ) := by
      rw [show g τ = η⁻¹ * qj (σ.act τ) by
        simpa [g, η] using congrFun (poleRemoved_coxAction_aux m σ) τ]
      apply hbase.congr_fun
      intro n
      simp only [Function.comp_apply, smul_eq_mul]
      rw [show P.coeff (r * n) = η⁻¹ * (η ^ n * (qExpansion 1 qj).coeff n) by
        simp [P, PowerSeries.coeff_expand_mul,
          PowerSeries.coeff_rescale]]
      rw [qParam_coxAction_aux]
      simp only [η, r, x, mul_pow, pow_mul]
      ring
    have hinj : Function.Injective (fun n ↦ r * n) := by
      intro i j hij
      exact Nat.mul_left_cancel hrpos hij
    apply (hinj.hasSum_iff ?_).mp hreindexed
    intro n hn
    have hnotdvd : ¬r ∣ n := by
      rintro ⟨k, rfl⟩
      exact hn ⟨k, rfl⟩
    simp [P, PowerSeries.coeff_expand, hnotdvd]
  apply PowerSeries.ext
  intro n
  change (qExpansion ((m : ℕ) : ℝ) g).coeff n = P.coeff n
  exact (qExpansion_coeff_unique g (by positivity) hgan hsum n).symm

private theorem inv_mul_pow_toNat_add_one_aux {η : ℂ} (hη : η ≠ 0) {t : ℤ}
    (ht : -1 ≤ t) :
    η⁻¹ * η ^ Int.toNat (t + 1) = η ^ t := by
  have hnonneg : 0 ≤ t + 1 := by omega
  rw [← zpow_natCast, Int.toNat_of_nonneg hnonneg, ← zpow_neg_one]
  rw [← zpow_add₀ hη]
  congr 1
  omega

private theorem coxPhase_zpow_aux (m : ℕ+) (σ : CoxMatrix m) (t : ℤ) :
    coxPhaseAux m σ ^ t =
      zeta m ^ (((σ.a : ℤ) * (σ.b : ℤ)) * t) := by
  rw [coxPhaseAux, ← zpow_natCast, zpow_mul]
  norm_cast

private theorem laurentqExpansion_coxAction_coeff_aux
    (m : ℕ+) (σ : CoxMatrix m) (k : ℤ) :
    (laurentqExpansion ((m : ℕ) : ℝ) (fun τ ↦ j (σ.act τ))).coeff k =
      (transformedJSeries (zeta m) σ).coeff k := by
  let r := σ.a ^ 2
  let η := coxPhaseAux m σ
  have hrpos : (0 : ℤ) < r := by exact_mod_cast pow_pos σ.a_pos 2
  have hpole : poleOrder ((m : ℕ) : ℝ) (fun τ ↦ j (σ.act τ)) = r :=
    poleOrder_coxAction_aux m σ
  rw [transformedJSeries_coeff, laurentqExpansion.coeff_of_qExpansion, hpole]
  simp only [← Nat.cast_pow]
  change (if k < -(r : ℤ) then 0 else _) =
    if (r : ℤ) ∣ k ∧ -(r : ℤ) ≤ k then
      (jIntCoeff (k / (r : ℤ)) : ℂ) *
        zeta m ^ (((σ.a : ℤ) * (σ.b : ℤ)) * (k / (r : ℤ))) else 0
  by_cases hk : k < -(r : ℤ)
  · simp [hk, not_le_of_gt hk]
  rw [if_neg hk, to_qExpansion_coxAction_aux]
  have hkge : 0 ≤ k + (r : ℤ) := by lia
  by_cases hdiv : (r : ℤ) ∣ k
  · obtain ⟨t, rfl⟩ := hdiv
    have ht : -1 ≤ t := by nlinarith
    have hindex : Int.toNat ((r : ℤ) * t + r) = r * Int.toNat (t + 1) := by
      rw [show (r : ℤ) * t + r = r * (t + 1) by ring,
        Int.toNat_mul hrpos.le (by lia)]
      simp
    have hjcoeff : (qExpansion 1 qj).coeff (Int.toNat (t + 1)) = (jIntCoeff t : ℂ) := by
      rw [← jIntCoeff_spec, laurentqExpansion.coeff_of_geq (by simpa [j_poleOrder] using ht)]
      simp [j_poleOrder, j_to_qExpansion]
    simp only [Int.mul_ediv_cancel_left _ hrpos.ne', dvd_mul_right,
      le_of_not_gt hk, and_self, if_true]
    change (η⁻¹ • (PowerSeries.rescale η (qExpansion 1 qj)).expand r
      (pow_ne_zero _ σ.a_pos.ne')).coeff (Int.toNat ((r : ℤ) * t + r)) = _
    rw [hindex]
    simp only [PowerSeries.coeff_smul, PowerSeries.coeff_expand_mul,
      PowerSeries.coeff_rescale, smul_eq_mul, hjcoeff]
    rw [← mul_assoc, inv_mul_pow_toNat_add_one_aux (coxPhase_ne_zero_aux m σ) ht,
      mul_comm, coxPhase_zpow_aux]
  · have hnotdvd : ¬r ∣ Int.toNat (k + (r : ℤ)) := by
      simpa only [← Int.natCast_dvd_natCast, Int.toNat_of_nonneg hkge,
        dvd_add_self_right] using hdiv
    change ¬σ.a ^ 2 ∣ Int.toNat (k + (r : ℤ)) at hnotdvd
    simp [hdiv, PowerSeries.coeff_expand, hnotdvd]

/-- The exact analytic/formal bridge for (11.13).  The width is `m`, not `1`: its local
parameter is `q^(1/m)`. -/
theorem laurentqExpansion_coxAction (m : ℕ+) (σ : CoxMatrix m) :
    laurentqExpansion ((m : ℕ) : ℝ) (fun τ ↦ j (σ.act τ)) =
      transformedJSeries (zeta m) σ := by
  ext k
  exact laurentqExpansion_coxAction_coeff_aux m σ k

/-- Galois reindexing `b ↦ bk (mod d)` from the proof of Theorem 11.18(i). -/
def reindex {m : ℕ+} (k : ℕ) (hk : Nat.Coprime k (m : ℕ)) :
    CoxMatrix m → CoxMatrix m := fun σ ↦ by
  have hdvd : σ.d ∣ (m : ℕ) :=
    ⟨σ.a, by rw [Nat.mul_comm, σ.determinant]⟩
  have hkd : Nat.Coprime k σ.d := hk.coprime_dvd_right hdvd
  refine
    { a := σ.a
      b := (σ.b * k) % σ.d
      d := σ.d
      a_pos := σ.a_pos
      determinant := σ.determinant
      b_lt := Nat.mod_lt _ σ.d_pos
      primitive := ?_ }
  rw [Nat.gcd_assoc, ← Nat.gcd_rec, Nat.gcd_comm σ.d,
    hkd.gcd_mul_right_cancel, ← Nat.gcd_assoc]
  exact σ.primitive

theorem reindex_bijective {m : ℕ+} (k : ℕ) (hk : Nat.Coprime k (m : ℕ)) :
    Function.Bijective (reindex k hk) := by
  have hinj : Function.Injective (reindex k hk) := by
    intro σ τ h
    have ha : σ.a = τ.a := by
      simpa only [reindex] using congrArg (fun ρ ↦ ρ.a) h
    have hd : σ.d = τ.d := by
      simpa only [reindex] using congrArg (fun ρ ↦ ρ.d) h
    have hbmod : (σ.b * k) % σ.d = (τ.b * k) % σ.d := by
      have hb := congrArg (fun ρ ↦ ρ.b) h
      simpa only [reindex, hd] using hb
    have hdvd : σ.d ∣ (m : ℕ) :=
      ⟨σ.a, by rw [Nat.mul_comm, σ.determinant]⟩
    have hkd : Nat.gcd σ.d k = 1 :=
      (hk.coprime_dvd_right hdvd).symm.gcd_eq_one
    have hmul : σ.b * k ≡ τ.b * k [MOD σ.d] := hbmod
    have hbCongr : σ.b ≡ τ.b [MOD σ.d] :=
      hmul.cancel_right_of_coprime hkd
    have hb : σ.b = τ.b := by
      apply hbCongr.eq_of_lt_of_lt σ.b_lt
      simpa only [hd] using τ.b_lt
    cases σ
    cases τ
    simp_all
  exact ⟨hinj, Finite.injective_iff_surjective.mp hinj⟩

end Cox
