/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import Mathlib.LinearAlgebra.Lagrange
import XYin.PhD.Cox.ModularPolynomial.Construction
import XYin.PhD.Cox.UpperHalfPlaneFunctionField

/-!
# Interpolation for modular functions

This file proves Cox's interpolation and recovery formulas and deduces Theorem 11.9(ii).
-/

open Complex Function MatrixGroups ModularForm UpperHalfPlane
open scoped Manifold Polynomial.Bivariate

noncomputable section

namespace Cox

/-- Equation (11.16), Cox's interpolation polynomial at a point of the upper half-plane. -/
noncomputable def interpolationAt (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (τ : ℍ) : Polynomial ℂ :=
  ∑ σ : CoxMatrix m,
    Polynomial.C
        (rightCosetTranslate m hf (coxMatrixEquivRightCosets m σ) τ) *
      ∏ σ' ∈ (Finset.univ.erase σ),
        (Polynomial.X - Polynomial.C (j (σ'.act τ)))

private noncomputable def interpolationAtCosetsAux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (τ : ℍ) : Polynomial ℂ := by
  classical
  exact ∑ c : Gamma0RightCosets m,
    Polynomial.C (rightCosetTranslate m hf c τ) *
      ∏ d ∈ Finset.univ.erase c,
        (Polynomial.X - Polynomial.C (rightCosetEval m d τ))

private theorem interpolationAt_eq_cosets_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (τ : ℍ) :
    interpolationAt m hf τ = interpolationAtCosetsAux m hf τ := by
  classical
  rw [interpolationAt, interpolationAtCosetsAux]
  apply Finset.sum_equiv (coxMatrixEquivRightCosets m)
  · simp
  · intro σ _
    congr 1
    apply Finset.prod_equiv (coxMatrixEquivRightCosets m)
    · simp
    · intro σ' _
      rw [rightCosetEval_equiv]

private theorem interpolationAtCosets_smul_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (δ : SL(2, ℤ)) (τ : ℍ) :
    interpolationAtCosetsAux m hf (δ • τ) = interpolationAtCosetsAux m hf τ := by
  classical
  rw [interpolationAtCosetsAux, interpolationAtCosetsAux]
  apply Finset.sum_equiv (rightCosetMul m δ)
  · simp
  · intro c _
    apply congrArg₂ (· * ·)
    · exact congrArg Polynomial.C (rightCosetTranslate_smul m hf δ c τ)
    · apply Finset.prod_equiv (rightCosetMul m δ)
      · simp
      · intro d _
        rw [rightCosetEval_smul]

private theorem interpolationAt_smul_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (δ : SL(2, ℤ)) (τ : ℍ) :
    interpolationAt m hf (δ • τ) = interpolationAt m hf τ := by
  rw [interpolationAt_eq_cosets_aux, interpolationAt_eq_cosets_aux,
    interpolationAtCosets_smul_aux]

private theorem rightCosetTranslate_meromorphicOnH_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (c : Gamma0RightCosets m) :
    ∀ z : ℂ, 0 < z.im →
      MeromorphicAt ((rightCosetTranslate m hf c) ∘ UpperHalfPlane.ofComplex) z := by
  refine Quotient.inductionOn c ?_
  intro γ z hz
  let τ : ℍ := ⟨z, hz⟩
  have hact : MDiff (fun w : ℍ ↦ ((γ • w : ℍ) : ℂ)) :=
    UpperHalfPlane.mdifferentiable_coe.comp <|
      UpperHalfPlane.mdifferentiable_smul (g := (γ : GL (Fin 2) ℝ)) (by simp)
  have hinner : AnalyticAt ℂ
      ((fun w : ℍ ↦ ((γ • w : ℍ) : ℂ)) ∘ UpperHalfPlane.ofComplex) z := by
    have hdiff := UpperHalfPlane.mdifferentiable_iff.mp hact
    exact hdiff.analyticAt (UpperHalfPlane.isOpen_upperHalfPlaneSet.mem_nhds hz)
  have hmer : MeromorphicAt (f ∘ UpperHalfPlane.ofComplex)
      (((fun w : ℍ ↦ ((γ • w : ℍ) : ℂ)) ∘ UpperHalfPlane.ofComplex) z) := by
    simpa [Function.comp_def, τ, UpperHalfPlane.ofComplex_apply_of_im_pos hz] using
      hf.1 (((γ • τ : ℍ) : ℂ)) (γ • τ).im_pos
  simpa [Function.comp_def, τ, UpperHalfPlane.ofComplex_apply_of_im_pos hz] using
    hmer.comp_analyticAt hinner

private noncomputable def interpolationFunctionAux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) : Polynomial (ℍ → ℂ) := by
  classical
  exact ∑ σ : CoxMatrix m,
    Polynomial.C
        (rightCosetTranslate m hf (coxMatrixEquivRightCosets m σ)) *
      ∏ σ' ∈ Finset.univ.erase σ,
        (Polynomial.X - Polynomial.C (fun τ ↦ j (σ'.act τ)))

private theorem interpolationFunction_map_eval_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (τ : ℍ) :
    (interpolationFunctionAux m hf).map
        (Pi.evalRingHom (fun _ : ℍ ↦ ℂ) τ) =
      interpolationAt m hf τ := by
  classical
  simp [interpolationFunctionAux, interpolationAt, Polynomial.map_sum,
    Polynomial.map_prod]

private theorem interpolationFunction_coeff_apply_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (n : ℕ) (τ : ℍ) :
    (interpolationFunctionAux m hf).coeff n τ =
      (interpolationAt m hf τ).coeff n := by
  simpa using congrArg (fun p : Polynomial ℂ ↦ p.coeff n)
    (interpolationFunction_map_eval_aux m hf τ)

private noncomputable def interpolationRootProductAux (m : ℕ+)
    (σ : CoxMatrix m) : Polynomial (ℍ → ℂ) :=
  ∏ σ' ∈ Finset.univ.erase σ,
    (Polynomial.X - Polynomial.C (fun τ ↦ j (σ'.act τ)))

private theorem interpolationFunction_coeff_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (n : ℕ) :
    (interpolationFunctionAux m hf).coeff n =
      ∑ σ : CoxMatrix m,
        rightCosetTranslate m hf (coxMatrixEquivRightCosets m σ) *
          (interpolationRootProductAux m σ).coeff n := by
  classical
  simp [interpolationFunctionAux, interpolationRootProductAux]

private theorem coxRoot_mdifferentiable_aux (m : ℕ+)
    (σ : CoxMatrix m) : MDiff (fun τ : ℍ ↦ j (σ.act τ)) := by
  rw [← funext (rightCosetEval_equiv m σ)]
  exact (UpperHalfPlaneFunctionField.rightCosetFunction m
    (coxMatrixEquivRightCosets m σ)).property

private theorem coxLinearFactor_coeff_mdifferentiable_aux (m : ℕ+)
    (σ : CoxMatrix m) (n : ℕ) :
    MDiff ((Polynomial.X - Polynomial.C (fun τ : ℍ ↦ j (σ.act τ)) :
      Polynomial (ℍ → ℂ)).coeff n) := by
  cases n with
  | zero => simpa using (coxRoot_mdifferentiable_aux m σ).neg
  | succ n =>
      cases n with
      | zero => simpa using (mdifferentiable_const : MDiff (fun _ : ℍ ↦ (1 : ℂ)))
      | succ n =>
          simp only [Polynomial.coeff_sub, Polynomial.coeff_X, Nat.right_eq_add,
            Nat.add_eq_zero_iff, one_ne_zero, and_false, ↓reduceIte,
            Polynomial.coeff_C_succ, sub_zero]
          exact mdifferentiable_const

private theorem polynomial_prod_coeff_mdifferentiable_aux {ι : Type*}
    (P : ι → Polynomial (ℍ → ℂ)) :
    ∀ s : Finset ι,
      (∀ i ∈ s, ∀ n, MDiff ((P i).coeff n)) →
      ∀ n, MDiff ((s.prod P).coeff n) := by
  classical
  intro s
  induction s using Finset.induction_on with
  | empty =>
      intro _ n
      simp only [Finset.prod_empty, Polynomial.coeff_one]
      split_ifs <;> exact mdifferentiable_const
  | insert a s ha ih =>
      intro hP n
      rw [Finset.prod_insert ha, Polynomial.coeff_mul]
      exact MDifferentiable.sum fun x _ ↦
        (hP a (Finset.mem_insert_self a s) x.1).mul
          (ih (fun i hi k ↦ hP i (Finset.mem_insert_of_mem hi) k) x.2)

private theorem interpolationRootProduct_coeff_mdifferentiable_aux (m : ℕ+)
    (σ : CoxMatrix m) (n : ℕ) :
    MDiff ((interpolationRootProductAux m σ).coeff n) := by
  classical
  rw [interpolationRootProductAux]
  exact polynomial_prod_coeff_mdifferentiable_aux
    (fun σ' : CoxMatrix m ↦
      Polynomial.X - Polynomial.C (fun τ : ℍ ↦ j (σ'.act τ)))
    (Finset.univ.erase σ)
    (fun σ' _ k ↦ coxLinearFactor_coeff_mdifferentiable_aux m σ' k) n

private theorem interpolation_coeff_eq_function_coeff_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (n : ℕ) :
    (fun τ ↦ (interpolationAt m hf τ).coeff n) =
      (interpolationFunctionAux m hf).coeff n := by
  funext τ
  exact (interpolationFunction_coeff_apply_aux m hf n τ).symm

private theorem interpolation_coeff_meromorphicOnH_aux (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (n : ℕ) :
    ∀ z : ℂ, 0 < z.im →
      MeromorphicAt
        ((fun τ ↦ (interpolationAt m hf τ).coeff n) ∘
          UpperHalfPlane.ofComplex) z := by
  intro z hz
  rw [interpolation_coeff_eq_function_coeff_aux,
    interpolationFunction_coeff_aux]
  simp only [Function.comp_def, Finset.sum_apply, Pi.mul_apply]
  apply MeromorphicAt.fun_sum
  intro σ _
  exact (rightCosetTranslate_meromorphicOnH_aux m hf
    (coxMatrixEquivRightCosets m σ) z hz).mul
      ((UpperHalfPlane.mdifferentiable_iff.mp
        (interpolationRootProduct_coeff_mdifferentiable_aux m σ n)).analyticAt
          (UpperHalfPlane.isOpen_upperHalfPlaneSet.mem_nhds hz)).meromorphicAt

private theorem rightCosetTranslate_cuspMeromorphicAt_aux (m : ℕ+)
    {f : ℍ → ℂ} (hf : CuspData m f)
    (c : Gamma0RightCosets m) :
    MeromorphicAt
      (cuspFunction ((m : ℕ) : ℝ) (rightCosetTranslate m hf c)) 0 := by
  refine Quotient.inductionOn c ?_
  intro γ
  change MeromorphicAt
    (cuspFunction ((m : ℕ) : ℝ) (fun τ : ℍ ↦ f (γ • τ))) 0
  exact hf.2.2 γ

private theorem interpolationRootProduct_coeff_cuspMeromorphicAt_aux (m : ℕ+)
    (σ : CoxMatrix m) (n : ℕ) :
    MeromorphicAt
      (cuspFunction ((m : ℕ) : ℝ)
        ((interpolationRootProductAux m σ).coeff n)) 0 := by
  classical
  rw [interpolationRootProductAux]
  exact polynomial_prod_coeff_cuspMeromorphicAt ((m : ℕ) : ℝ)
    (fun σ' : CoxMatrix m ↦
      Polynomial.X - Polynomial.C (fun τ : ℍ ↦ j (σ'.act τ)))
    (Finset.univ.erase σ)
    (fun σ' _ k ↦ coxLinearFactor_coeff_cuspMeromorphicAt m σ' k) n

private theorem interpolation_coeff_widthM_cuspMeromorphicAt_aux (m : ℕ+)
    {f : ℍ → ℂ} (hf : CuspData m f) (n : ℕ) :
    MeromorphicAt
      (cuspFunction ((m : ℕ) : ℝ)
        (fun τ ↦ (interpolationAt m hf τ).coeff n)) 0 := by
  rw [interpolation_coeff_eq_function_coeff_aux,
    interpolationFunction_coeff_aux]
  simpa using meromorphicAt_cuspFunction_finset_sum
    (s := (Finset.univ : Finset (CoxMatrix m)))
    (f := fun σ ↦
      rightCosetTranslate m hf (coxMatrixEquivRightCosets m σ) *
        (interpolationRootProductAux m σ).coeff n)
    (fun σ _ ↦ meromorphicAt_cuspFunction_mul
      (rightCosetTranslate_cuspMeromorphicAt_aux m hf
        (coxMatrixEquivRightCosets m σ))
      (interpolationRootProduct_coeff_cuspMeromorphicAt_aux m σ n))

private theorem interpolation_coeff_slashInvariant_aux (m : ℕ+)
    {f : ℍ → ℂ} (hf : CuspData m f) (n : ℕ)
    (δ : SL(2, ℤ)) :
    (fun τ ↦ (interpolationAt m hf τ).coeff n) ∣[(0 : ℤ)] δ =
      fun τ ↦ (interpolationAt m hf τ).coeff n := by
  funext τ
  simp only [ModularForm.SL_slash_apply, neg_zero, zpow_zero, mul_one]
  exact congrArg (fun P : Polynomial ℂ ↦ P.coeff n)
    (interpolationAt_smul_aux m hf δ τ)

private theorem interpolation_coeff_widthOne_cuspMeromorphicAt_aux (m : ℕ+)
    {f : ℍ → ℂ} (hf : CuspData m f) (n : ℕ) :
    MeromorphicAt
      (cuspFunction 1 (fun τ ↦ (interpolationAt m hf τ).coeff n)) 0 := by
  apply meromorphicAt_cuspFunction_of_nat_mul (m := (m : ℕ)) (h := 1)
    (PNat.ne_zero m)
  · simpa using interpolation_coeff_widthM_cuspMeromorphicAt_aux m hf n
  · exact periodic_comp_of_slashInvariant_one
      (interpolation_coeff_slashInvariant_aux m hf n)

/-- Exercise 11.11: the raw interpolation coefficients have level-one analytic cusp data.
They need not be canonical representatives at removable singularities. -/
theorem interpolation_coeff_cuspData (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (n : ℕ) :
    LevelOneCuspData (fun τ ↦ (interpolationAt m hf τ).coeff n) := by
  let g := fun τ ↦ (interpolationAt m hf τ).coeff n
  have hslash := interpolation_coeff_slashInvariant_aux m hf n
  refine ⟨interpolation_coeff_meromorphicOnH_aux m hf n, ?_, ?_⟩
  · intro γ
    exact hslash γ
  · intro γ
    have hfun : (fun τ : ℍ ↦ g (γ • τ)) = g := by
      funext τ
      have h := congrFun (hslash γ) τ
      simpa only [ModularForm.SL_slash_apply, neg_zero, zpow_zero, mul_one, g] using h
    rw [show (fun τ : ℍ ↦
      (interpolationAt m hf (γ • τ)).coeff n) = g from hfun]
    simpa [g] using interpolation_coeff_widthOne_cuspMeromorphicAt_aux m hf n

private theorem eval_derivative_prod_X_sub_C_at
    {R ι : Type*} [CommRing R] [Fintype ι] [DecidableEq ι]
    (r : ι → R) (i : ι) :
    (Polynomial.derivative
        (∏ k : ι, (Polynomial.X - Polynomial.C (r k)))).eval (r i) =
      ∏ k ∈ Finset.univ.erase i, (r i - r k) := by
  simpa [Lagrange.nodal, Polynomial.eval_prod] using
    (Lagrange.eval_nodal_derivative_eval_node_eq (s := Finset.univ) (v := r)
      (Finset.mem_univ i))

private theorem eval_interpolation_sum_at
    {R ι : Type*} [CommRing R] [Fintype ι] [DecidableEq ι]
    (a r : ι → R) (i : ι) :
    (∑ k : ι,
        Polynomial.C (a k) *
          ∏ l ∈ Finset.univ.erase k,
            (Polynomial.X - Polynomial.C (r l))).eval (r i) =
      a i * ∏ l ∈ Finset.univ.erase i, (r i - r l) := by
  simp only [Polynomial.eval_finsetSum, Polynomial.eval_mul, Polynomial.eval_C,
    Polynomial.eval_prod, Polynomial.eval_sub, Polynomial.eval_X]
  refine Finset.sum_eq_single i ?_ (by simp)
  intro k _ hki
  rw [Finset.prod_eq_zero (Finset.mem_erase.mpr ⟨hki.symm, Finset.mem_univ i⟩)
    (sub_self _), mul_zero]

/-- Equation (11.17), stated at points where the separability denominator does not vanish.
This guard is essential: specialized roots can collide at CM points even though the polynomial
is separable over the function field.
-/
theorem recoveryFormula (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (τ : ℍ)
    (hderiv : ((modularPolynomialC m).specializeY (j τ)).derivative.eval
      (levelJ m τ) ≠ 0) :
    f τ = (interpolationAt m hf τ).eval (levelJ m τ) /
      ((modularPolynomialC m).specializeY (j τ)).derivative.eval (levelJ m τ) := by
  classical
  rw [← congrFun (j_act_sigmaZero m) τ, modularPolynomialC_specializeY,
    coxPhiAtJ, eval_derivative_prod_X_sub_C_at
      (fun σ : CoxMatrix m ↦ j (σ.act τ)) (sigmaZero m)] at hderiv ⊢
  rw [interpolationAt, eval_interpolation_sum_at
    (fun σ : CoxMatrix m ↦ rightCosetTranslate m hf (coxMatrixEquivRightCosets m σ) τ)
    (fun σ : CoxMatrix m ↦ j (σ.act τ)) (sigmaZero m), rightCosetTranslate_sigmaZero]
  exact (mul_div_cancel_right₀ _ hderiv).symm

section Theorem119

open UpperHalfPlaneFunctionField

private theorem interpolationAt_natDegree_lt (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f) (τ : ℍ) :
    (interpolationAt m hf τ).natDegree < Fintype.card (CoxMatrix m) := by
  classical
  rw [interpolationAt]
  have hcard : 0 < Fintype.card (CoxMatrix m) :=
    Fintype.card_pos_iff.mpr ⟨sigmaZero m⟩
  refine lt_of_le_of_lt (Polynomial.natDegree_sum_le_of_forall_le _ _ ?_)
    (Nat.sub_lt hcard zero_lt_one)
  intro σ _
  exact (Polynomial.natDegree_C_mul_le _ _).trans (by simp)

private theorem exists_commonDenominator_polynomialEval_of_natDegree_lt
    {A : ℍ → Polynomial ℂ} {g h : ℍ → ℂ} (d : ℕ)
    (hdegree : ∀ τ, (A τ).natDegree < d)
    (hcoeff : ∀ n, RationalIn (fun τ ↦ (A τ).coeff n) g) :
    ∃ numerator : ℂ[X][Y], ∃ commonDenom : Polynomial ℂ,
      commonDenom ≠ 0 ∧
        ∀ τ, commonDenom.eval (g τ) ≠ 0 →
          (A τ).eval (h τ) =
            numerator.evalEval (g τ) (h τ) / commonDenom.eval (g τ) := by
  classical
  choose p q hq hrepr using hcoeff
  let s := Finset.range d
  let commonDenom : Polynomial ℂ := ∏ n ∈ s, q n
  let numerator : ℂ[X][Y] :=
    ∑ n ∈ s,
      Polynomial.C (p n * ∏ k ∈ s.erase n, q k) * Polynomial.X ^ n
  refine ⟨numerator, commonDenom, ?_, ?_⟩
  · simp only [commonDenom]
    exact Finset.prod_ne_zero_iff.mpr fun n _ ↦ hq n
  · intro τ hdenom
    have hcommon_eval :
        commonDenom.eval (g τ) = ∏ n ∈ s, (q n).eval (g τ) := by
      simp only [commonDenom, Polynomial.eval_prod]
    have hqeval {n : ℕ} (hn : n ∈ s) : (q n).eval (g τ) ≠ 0 := by
      intro hnzero
      apply hdenom
      rw [hcommon_eval]
      exact Finset.prod_eq_zero hn hnzero
    rw [eq_div_iff hdenom]
    rw [Polynomial.eval_eq_sum_range' (hdegree τ)]
    change
      (∑ n ∈ s, (A τ).coeff n * h τ ^ n) * commonDenom.eval (g τ) =
        numerator.evalEval (g τ) (h τ)
    rw [Finset.sum_mul]
    simp only [numerator, Polynomial.evalEval_finsetSum]
    apply Finset.sum_congr rfl
    intro n hn
    rw [Polynomial.evalEval_mul, Polynomial.evalEval_C,
      Polynomial.evalEval_pow, Polynomial.evalEval_X,
      Polynomial.eval_mul, Polynomial.eval_prod]
    have hcoeffτ := hrepr n τ (hqeval hn)
    change (A τ).coeff n = (p n).eval (g τ) / (q n).eval (g τ) at hcoeffτ
    rw [hcoeffτ, Polynomial.eval_prod]
    rw [← Finset.mul_prod_erase s (fun k ↦ (q k).eval (g τ)) hn]
    field_simp [hqeval hn]

private theorem modularPolynomialC_derivative_evalEval (m : ℕ+) (τ : ℍ) :
    ((modularPolynomialC m).derivative).evalEval (j τ) (levelJ m τ) =
      ((modularPolynomialC m).specializeY (j τ)).derivative.eval
        (levelJ m τ) := by
  rw [BivariatePolynomial.specializeY, Polynomial.derivative_map,
    Polynomial.map_evalRingHom_eval]

private def modularDerivativeHolomorphic (m : ℕ+) : HolomorphicFunction := by
  classical
  exact ∏ c ∈ Finset.univ.erase (baseRightCoset m),
    (rightCosetFunction m (baseRightCoset m) - rightCosetFunction m c)

private theorem modularDerivativeHolomorphic_apply (m : ℕ+) (τ : ℍ) :
    (modularDerivativeHolomorphic m).1 τ =
      ((modularPolynomialC m).specializeY (j τ)).derivative.eval
        (levelJ m τ) := by
  classical
  have hbase : rightCosetEval m (baseRightCoset m) τ = levelJ m τ := by
    simp [baseRightCoset]
  rw [modularPolynomialC_rightCosetProduct, ← hbase,
    eval_derivative_prod_X_sub_C_at (fun c ↦ rightCosetEval m c τ) (baseRightCoset m)]
  simp [modularDerivativeHolomorphic, rightCosetFunction]

private theorem modularDerivativeHolomorphic_ne_zero (m : ℕ+) :
    modularDerivativeHolomorphic m ≠ 0 := by
  classical
  dsimp only [modularDerivativeHolomorphic]
  apply Finset.prod_ne_zero_iff.mpr
  intro c hc
  apply sub_ne_zero.mpr
  intro hbc
  have hcb : c ≠ baseRightCoset m := (Finset.mem_erase.mp hc).1
  exact hcb ((rightCosetFunction_injective m hbc).symm)

private def interpolationDenominator (m : ℕ+) (D : Polynomial ℂ) : ℂ[X][Y] :=
  Polynomial.C D * (modularPolynomialC m).derivative

private theorem interpolationDenominator_eval (m : ℕ+) (D : Polynomial ℂ)
    (τ : ℍ) :
    (interpolationDenominator m D).evalEval (j τ) (levelJ m τ) =
      D.eval (j τ) *
        ((modularPolynomialC m).specializeY (j τ)).derivative.eval
          (levelJ m τ) := by
  rw [interpolationDenominator, Polynomial.evalEval_mul,
    Polynomial.evalEval_C, modularPolynomialC_derivative_evalEval]

private theorem interpolationDenominator_onCurve_ne_zero (m : ℕ+)
    {D : Polynomial ℂ} (hD : D ≠ 0) :
    (fun τ : ℍ ↦
      (interpolationDenominator m D).evalEval (j τ) (levelJ m τ)) ≠ 0 := by
  have hEvalJ : evalJ D ≠ 0 := by
    intro hzero
    apply hD
    apply evalJ_injective
    simpa using hzero
  have hproduct :
      evalJ D * modularDerivativeHolomorphic m ≠ 0 :=
    mul_ne_zero hEvalJ (modularDerivativeHolomorphic_ne_zero m)
  intro hzero
  apply hproduct
  apply Subtype.ext
  funext τ
  change (evalJ D).1 τ * (modularDerivativeHolomorphic m).1 τ = 0
  rw [evalJ_apply, modularDerivativeHolomorphic_apply,
    ← interpolationDenominator_eval]
  exact congrFun hzero τ

private theorem rationalInTwo_of_interpolation_coeff_rational
    (m : ℕ+) {f : ℍ → ℂ}
    (hf : CuspData m f)
    (hcoeff : ∀ n,
      RationalIn (fun τ ↦ (interpolationAt m hf τ).coeff n) j) :
    RationalInTwo f j (levelJ m) := by
  obtain ⟨P, D, hD, hP⟩ :=
    exists_commonDenominator_polynomialEval_of_natDegree_lt
      (Fintype.card (CoxMatrix m))
      (interpolationAt_natDegree_lt m hf) hcoeff
  refine ⟨P, interpolationDenominator m D,
    interpolationDenominator_onCurve_ne_zero m hD, ?_⟩
  intro τ hdenom
  rw [interpolationDenominator_eval] at hdenom ⊢
  have hDeval : D.eval (j τ) ≠ 0 := left_ne_zero_of_mul hdenom
  have hderiv :
      ((modularPolynomialC m).specializeY (j τ)).derivative.eval
          (levelJ m τ) ≠ 0 :=
    right_ne_zero_of_mul hdenom
  rw [recoveryFormula m hf τ hderiv, hP τ hDeval, div_div]

/-- Theorem 11.9(ii): every level-`N` modular function is rational in `j(τ)` and
`j(Nτ)`. The chosen denominator is nonzero as a function along the modular curve, though it
may vanish at individual branch points as expected for a rational representation. -/
theorem theorem_11_9_ii_pointwise (N : ℕ+)
    (f : ModularFunction (CongruenceSubgroup.Gamma0 (N : ℕ))) :
    RationalInTwo f j (levelJ N) := by
  let hf := CuspData.of_modularFunction N f
  apply rationalInTwo_of_interpolation_coeff_rational N hf
  intro n
  exact (interpolation_coeff_cuspData N hf n).rationalInJ

end Theorem119

end Cox
