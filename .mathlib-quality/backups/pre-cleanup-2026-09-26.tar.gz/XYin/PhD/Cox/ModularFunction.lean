/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import Mathlib.Analysis.Meromorphic.TrailingCoefficient
import XYin.PhD.Cox.LatticeJ
import XYin.PhD.Cox.ModularFunction.LevelJ

/-!
# Level-one modular functions and Cox Theorem 11.9

The public statements use the bundled `ModularFunction` definition. A holomorphic level-one
modular function is a polynomial in `j`; clearing its poles on a fundamental domain proves
that every level-one modular function is rational in `j`.

The supporting raw-expression API and the bundled level transform `j(Nτ)` are developed in
`ModularFunction.CuspData` and `ModularFunction.LevelJ`.
-/

open Complex Filter Function MatrixGroups ModularForm UpperHalfPlane
open scoped Manifold Polynomial.Bivariate

noncomputable section

namespace Cox

/-- Cox Lemma 11.10(i): a level-one modular function holomorphic on `ℍ` and at `∞` is
constant. -/
private theorem levelOne_constant_of_holomorphic {f : ℍ → ℂ}
    (hf : LevelOneCuspData f) (hfH : MDiff f)
    (hf_cusp : AnalyticAt ℂ (cuspFunction 1 f) 0) :
    ∃ c : ℂ, f = fun _ ↦ c := by
  have hfper : Periodic (f ∘ UpperHalfPlane.ofComplex) 1 := by
    simpa [Function.comp_def] using periodic_comp_sl2 (1 : ℕ+) hf 1
  have hfbdd : IsBoundedAtImInfty f := by
    rw [IsBoundedAtImInfty, BoundedAtFilter]
    have hcomp :
        (cuspFunction 1 f ∘ fun τ : ℍ ↦ Periodic.qParam 1 (τ : ℂ)) = f := by
      funext τ
      exact eq_cuspFunction τ one_ne_zero hfper
    have htend : Tendsto f atImInfty (nhds (cuspFunction 1 f 0)) := by
      simpa only [hcomp] using
        hf_cusp.continuousAt.tendsto.comp (qParam_tendsto_atImInfty one_pos)
    exact htend.isBigO_one ℝ
  have hinv (γ : SL(2, ℤ)) : f ∣[(0 : ℤ)] γ = f := by
    let γ₀ : CongruenceSubgroup.Gamma0 1 :=
      ⟨γ, CongruenceSubgroup.Gamma0_mem.mpr (Subsingleton.elim _ _)⟩
    exact hf.2.1 γ₀
  let F : ModularForm (Matrix.SpecialLinearGroup.mapGL ℝ).range 0 :=
    { toFun := f
      slash_action_eq' := by
        rintro _ ⟨γ, rfl⟩
        exact hinv γ
      holo' := hfH
      bdd_at_cusps' := by
        intro c hc
        rw [OnePoint.isBoundedAt_iff_exists_SL2Z hc]
        obtain ⟨γ, hγ⟩ := isCusp_SL2Z_iff'.mp hc
        exact ⟨γ, hγ.symm, by simpa only [hinv γ] using hfbdd⟩ }
  simpa only [F, Function.const_def] using ModularFormClass.levelOne_weight_zero_const F

private lemma cuspFunction_sub_const_mul_pow_eventuallyEq
    (h : ℝ) (f g : ℍ → ℂ) (a : ℂ) (m : ℕ) :
    cuspFunction h (fun τ ↦ f τ - a * g τ ^ m) =ᶠ[nhdsWithin 0 ({0}ᶜ)]
      fun q ↦ cuspFunction h f q - a * cuspFunction h g q ^ m := by
  filter_upwards [self_mem_nhdsWithin] with q hq
  have hq0 : q ≠ 0 := Set.mem_compl_singleton_iff.mp hq
  simp only [UpperHalfPlane.cuspFunction]
  rw [Periodic.cuspFunction_eq_of_nonzero _ _ hq0,
    Periodic.cuspFunction_eq_of_nonzero _ _ hq0,
    Periodic.cuspFunction_eq_of_nonzero _ _ hq0]
  rfl

private lemma cuspData_sub_const_mul_pow
    (N : ℕ+) {f g : ℍ → ℂ} (hf : CuspData N f)
    (hg : CuspData N g) (a : ℂ) (m : ℕ) :
    CuspData N (fun τ ↦ f τ - a * g τ ^ m) := by
  refine ⟨?_, ?_, ?_⟩
  · intro z hz
    simpa only [Function.comp_def] using
      (hf.1 z hz).sub ((MeromorphicAt.const a z).mul ((hg.1 z hz).pow m))
  · intro γ
    funext τ
    have hfτ := congrFun (hf.2.1 γ) τ
    have hgτ := congrFun (hg.2.1 γ) τ
    simpa only [ModularForm.SL_slash_apply, neg_zero, zpow_zero, mul_one] using
      congrArg₂ (fun x y : ℂ ↦ x - a * y ^ m) hfτ hgτ
  · intro γ
    have hmer := (hf.2.2 γ).sub
      ((MeromorphicAt.const a 0).mul ((hg.2.2 γ).pow m))
    refine hmer.congr ?_
    simpa only using (cuspFunction_sub_const_mul_pow_eventuallyEq
      ((N : ℕ) : ℝ) (fun τ ↦ f (γ • τ)) (fun τ ↦ g (γ • τ)) a m).symm

private lemma meromorphicOrderAt_sub_gt_of_eq_and_trailingCoeff_eq
    {f g : ℂ → ℂ} {x : ℂ} {n : ℤ}
    (hf : MeromorphicAt f x) (hg : MeromorphicAt g x)
    (hfn : meromorphicOrderAt f x = n) (hgn : meromorphicOrderAt g x = n)
    (htc : meromorphicTrailingCoeffAt f x = meromorphicTrailingCoeffAt g x) :
    (n : WithTop ℤ) < meromorphicOrderAt (fun z ↦ f z - g z) x := by
  obtain ⟨F, hFan, hF0, hFeq⟩ := (meromorphicOrderAt_eq_int_iff hf).mp hfn
  obtain ⟨G, hGan, hG0, hGeq⟩ := (meromorphicOrderAt_eq_int_iff hg).mp hgn
  have hFtc : meromorphicTrailingCoeffAt f x = F x :=
    hFan.meromorphicTrailingCoeffAt_of_ne_zero_of_eq_nhdsNE hF0 hFeq
  have hGtc : meromorphicTrailingCoeffAt g x = G x :=
    hGan.meromorphicTrailingCoeffAt_of_ne_zero_of_eq_nhdsNE hG0 hGeq
  let H : ℂ → ℂ := fun z ↦ F z - G z
  have hHan : AnalyticAt ℂ H x := hFan.sub hGan
  have hH0 : H x = 0 := by
    rw [show H x = F x - G x from rfl, sub_eq_zero, ← hFtc, ← hGtc]
    exact htc
  have hHne : meromorphicOrderAt H x ≠ 0 := by
    intro h
    exact (hHan.meromorphicNFAt.meromorphicOrderAt_eq_zero_iff.mp h) hH0
  have hHpos : 0 < meromorphicOrderAt H x :=
    lt_of_le_of_ne hHan.meromorphicOrderAt_nonneg (Ne.symm hHne)
  have heq : (fun z ↦ f z - g z) =ᶠ[nhdsWithin x ({x}ᶜ)]
      fun z ↦ (z - x) ^ n * H z := by
    filter_upwards [hFeq, hGeq] with z hfz hgz
    simp [hfz, hgz, H, smul_eq_mul, mul_sub]
  rw [meromorphicOrderAt_congr heq]
  change (n : WithTop ℤ) < meromorphicOrderAt (((· - x) ^ n) * H) x
  rw [meromorphicOrderAt_mul (by fun_prop) hHan.meromorphicAt,
    meromorphicOrderAt_zpow_id_sub_const]
  cases ho : meromorphicOrderAt H x with
  | top => simp
  | coe k =>
      have hk : 0 < k := by exact_mod_cast (by simpa [ho] using hHpos)
      simpa [ho, ← WithTop.coe_add] using lt_add_of_pos_right n hk

private lemma poleOrder_lt_of_neg_lt_meromorphicOrderAt
    {F : ℍ → ℂ} {m : ℕ} (hm : 0 < m)
    (hord : ((-(m : ℤ) : ℤ) : WithTop ℤ) <
      meromorphicOrderAt (cuspFunction 1 F) 0) :
    poleOrder 1 F < m := by
  rw [poleOrder_eq_toNat_neg_meromorphicOrderAt]
  cases ho : meromorphicOrderAt (cuspFunction 1 F) 0 with
  | top => simp [hm]
  | coe k =>
      rw [ho] at hord
      have hk : -(m : ℤ) < k := WithTop.coe_lt_coe.mp hord
      simp only [WithTop.untopD_coe]
      omega

private lemma exists_const_poleOrder_sub_mul_pow_lt
    {f g : ℍ → ℂ}
    (hfmer : MeromorphicAt (cuspFunction 1 f) 0)
    (hgmer : MeromorphicAt (cuspFunction 1 g) 0)
    (hgorder : poleOrder 1 g = 1) (hm : 0 < poleOrder 1 f) :
    ∃ a : ℂ, poleOrder 1
      (fun τ ↦ f τ - a * g τ ^ poleOrder 1 f) < poleOrder 1 f := by
  let m := poleOrder 1 f
  let F := cuspFunction 1 f
  let G := cuspFunction 1 g
  let cF := meromorphicTrailingCoeffAt F 0
  let cG := meromorphicTrailingCoeffAt G 0
  let a := cF / cG ^ m
  have hm0 : m ≠ 0 := by simpa [m] using hm.ne'
  have hForder : meromorphicOrderAt F 0 = -(m : ℤ) := by
    simpa [F, m] using meromorphicOrderAt_cuspFunction_eq_neg_poleOrder hm0
  have hGpole : poleOrder 1 g ≠ 0 := by simp [hgorder]
  have hGorder : meromorphicOrderAt G 0 = -(1 : ℤ) := by
    simpa [G, hgorder] using meromorphicOrderAt_cuspFunction_eq_neg_poleOrder hGpole
  have hFtc0 : cF ≠ 0 := by
    apply hfmer.meromorphicTrailingCoeffAt_ne_zero
    rw [hForder]
    exact WithTop.coe_ne_top
  have hGtc0 : cG ≠ 0 := by
    apply hgmer.meromorphicTrailingCoeffAt_ne_zero
    rw [hGorder]
    exact WithTop.coe_ne_top
  have ha0 : a ≠ 0 := div_ne_zero hFtc0 (pow_ne_zero m hGtc0)
  let Gm : ℂ → ℂ := fun q ↦ a * G q ^ m
  have hGmmer : MeromorphicAt Gm 0 := by
    exact (MeromorphicAt.const a 0).mul (hgmer.pow m)
  have hGmorder : meromorphicOrderAt Gm 0 = -(m : ℤ) := by
    change meromorphicOrderAt ((fun _ : ℂ ↦ a) * G ^ m) 0 = _
    rw [meromorphicOrderAt_mul_of_ne_zero analyticAt_const ha0,
      meromorphicOrderAt_pow hgmer, hGorder]
    norm_cast
    exact mul_neg_one (m : ℤ)
  have hGmtc : meromorphicTrailingCoeffAt Gm 0 = cF := by
    change meromorphicTrailingCoeffAt ((fun _ : ℂ ↦ a) * G ^ m) 0 = _
    rw [(MeromorphicAt.const a 0).meromorphicTrailingCoeffAt_mul (hgmer.pow m),
      meromorphicTrailingCoeffAt_const, hgmer.meromorphicTrailingCoeffAt_pow]
    change a * cG ^ m = cF
    exact div_mul_cancel₀ cF (pow_ne_zero m hGtc0)
  refine ⟨a, ?_⟩
  apply poleOrder_lt_of_neg_lt_meromorphicOrderAt (by simpa [m] using hm)
  rw [meromorphicOrderAt_congr
    (cuspFunction_sub_const_mul_pow_eventuallyEq 1 f g a m)]
  exact meromorphicOrderAt_sub_gt_of_eq_and_trailingCoeff_eq hfmer hGmmer
    hForder hGmorder hGmtc.symm

/-- Cox Lemma 11.10(ii): a level-one modular function holomorphic on `ℍ` is a polynomial
in `j`. -/
theorem CuspData.polynomialInJ_of_holomorphic {f : ℍ → ℂ}
    (hf : LevelOneCuspData f) (hfH : MDiff f) :
    ∃ P : Polynomial ℂ, f = Cox.polynomialIn P j := by
  have main : ∀ m : ℕ, ∀ f : ℍ → ℂ, poleOrder 1 f = m →
      LevelOneCuspData f → MDiff f →
        ∃ P : Polynomial ℂ, f = Cox.polynomialIn P j := by
    intro m
    induction m using Nat.strong_induction_on with
    | h m ih =>
        intro f hfm hf hfH
        have hfmer : MeromorphicAt (cuspFunction 1 f) 0 := by
          simpa using hf.2.2 (1 : SL(2, ℤ))
        by_cases hm0 : m = 0
        · have hfcusp : AnalyticAt ℂ (cuspFunction 1 f) 0 :=
            (analyticAt_cuspFunction_iff_poleOrder_eq_zero hfmer).2 (hfm.trans hm0)
          obtain ⟨c, hc⟩ := levelOne_constant_of_holomorphic hf hfH hfcusp
          refine ⟨Polynomial.C c, ?_⟩
          rw [hc]
          funext τ
          simp [Cox.polynomialIn]
        · have hmpos : 0 < poleOrder 1 f := by
            rw [hfm]
            exact Nat.pos_of_ne_zero hm0
          obtain ⟨a, ha⟩ := exists_const_poleOrder_sub_mul_pow_lt hfmer
            j_cuspFunction_meromorphicAt j_poleOrder hmpos
          let f' : ℍ → ℂ := fun τ ↦ f τ - a * j τ ^ poleOrder 1 f
          have hf' : LevelOneCuspData f' :=
            cuspData_sub_const_mul_pow 1 hf
              j_levelOneCuspData a (poleOrder 1 f)
          have hf'H : MDiff f' := by
            simpa [f', smul_eq_mul] using
              hfH.sub (MDifferentiable.const_smul a
                (ModularFunction.j_mdifferentiable.pow (poleOrder 1 f)))
          have hlt : poleOrder 1 f' < m := by
            simpa [f', hfm] using ha
          obtain ⟨P, hP⟩ := ih (poleOrder 1 f') hlt f' rfl hf' hf'H
          refine ⟨P + Polynomial.monomial m a, ?_⟩
          funext τ
          have hPτ := congrFun hP τ
          simp only [f', Cox.polynomialIn] at hPτ ⊢
          rw [hfm] at hPτ
          rw [Polynomial.eval_add, Polynomial.eval_monomial]
          linear_combination hPτ
  exact main (poleOrder 1 f) f rfl hf hfH

private lemma eventually_mdifferentiableAt_atImInfty
    {f : ℍ → ℂ} (hf : LevelOneCuspData f) :
    ∀ᶠ τ in atImInfty, MDiffAt f τ := by
  have hper : Periodic (f ∘ UpperHalfPlane.ofComplex) 1 := by
    simpa [Function.comp_def] using periodic_comp_sl2 (1 : ℕ+) hf 1
  have hcusp : MeromorphicAt (cuspFunction 1 f) 0 := by
    simpa using hf.2.2 (1 : SL(2, ℤ))
  have hana : ∀ᶠ q in nhdsWithin (0 : ℂ) ({0}ᶜ),
      AnalyticAt ℂ (cuspFunction 1 f) q := hcusp.eventually_analyticAt
  have hq : Tendsto (fun τ : ℍ ↦ Periodic.qParam 1 (τ : ℂ)) atImInfty
      (nhdsWithin (0 : ℂ) ({0}ᶜ)) :=
    (Periodic.qParam_tendsto one_pos).comp tendsto_coe_atImInfty
  filter_upwards [hq.eventually hana] with τ hτ
  rw [UpperHalfPlane.mdifferentiableAt_iff]
  have hcomp : DifferentiableAt ℂ
      ((cuspFunction 1 f) ∘ Periodic.qParam 1) (τ : ℂ) :=
    hτ.differentiableAt.comp (τ : ℂ) Periodic.differentiable_qParam.differentiableAt
  refine hcomp.congr_of_eventuallyEq ?_
  filter_upwards [UpperHalfPlane.isOpen_upperHalfPlaneSet.mem_nhds τ.im_pos] with z hz
  change f (UpperHalfPlane.ofComplex z) = cuspFunction 1 f (Periodic.qParam 1 z)
  rw [UpperHalfPlane.ofComplex_apply_of_im_pos hz]
  exact (UpperHalfPlane.eq_cuspFunction ⟨z, hz⟩ one_ne_zero hper).symm

private lemma finite_not_mdifferentiableAt_truncatedFundamentalDomain
    {f : ℍ → ℂ} (hf : LevelOneCuspData f) (y : ℝ) :
    {τ | τ ∈ ModularGroup.truncatedFundamentalDomain y ∧ ¬MDiffAt f τ}.Finite := by
  let K := ModularGroup.truncatedFundamentalDomain y
  let A : Set ℂ := {z | AnalyticAt ℂ (f ∘ UpperHalfPlane.ofComplex) z}
  have hmer : MeromorphicOn (f ∘ UpperHalfPlane.ofComplex)
      UpperHalfPlane.upperHalfPlaneSet := by
    intro z hz
    exact hf.1 z hz
  have hA : A ∈ codiscreteWithin UpperHalfPlane.upperHalfPlaneSet := by
    exact hmer.eventually_codiscreteWithin_analyticAt (f ∘ UpperHalfPlane.ofComplex)
  have hKsub : UpperHalfPlane.coe '' K ⊆ UpperHalfPlane.upperHalfPlaneSet := by
    rintro _ ⟨τ, _, rfl⟩
    exact τ.im_pos
  have hAK : A ∈ codiscreteWithin (UpperHalfPlane.coe '' K) :=
    (Filter.codiscreteWithin_mono hKsub) hA
  have hKcompact : IsCompact (UpperHalfPlane.coe '' K) :=
    UpperHalfPlane.isEmbedding_coe.isCompact_iff.mp
      (ModularGroup.isCompact_truncatedFundamentalDomain y)
  have hsingular : ((UpperHalfPlane.coe '' K) \ A).Finite :=
    hKcompact.finite_diff_of_mem_codiscreteWithin hAK
  apply Set.Finite.of_finite_image
    (hsingular.subset ?_) UpperHalfPlane.isEmbedding_coe.injective.injOn
  rintro _ ⟨τ, ⟨hτK, hτ⟩, rfl⟩
  refine ⟨⟨τ, hτK, rfl⟩, ?_⟩
  intro hτan
  exact hτ (UpperHalfPlane.mdifferentiableAt_iff.mpr hτan.differentiableAt)

private lemma exists_analyticAt_pow_succ_mul_of_meromorphicAt_of_analyticAt_zero
    {F J : ℂ → ℂ} {x : ℂ} (hF : MeromorphicAt F x)
    (hJ : AnalyticAt ℂ J x) (hJ0 : J x = 0) :
    ∃ n : ℕ, AnalyticAt ℂ (fun z ↦ J z ^ (n + 1) * F z) x := by
  obtain ⟨n, hA⟩ := hF
  obtain ⟨p, hp⟩ := hJ
  have hJan : AnalyticAt ℂ J x := ⟨p, hp⟩
  have hD : AnalyticAt ℂ (dslope J x) x :=
    ⟨p.fslope, hp.has_fpower_series_dslope_fslope⟩
  have hA' : AnalyticAt ℂ (fun z ↦ (z - x) ^ n * F z) x := by
    simpa only [smul_eq_mul] using hA
  refine ⟨n, ?_⟩
  have hR : AnalyticAt ℂ
      (fun z ↦ J z * dslope J x z ^ n * ((z - x) ^ n * F z)) x :=
    (hJan.mul (hD.pow n)).mul hA'
  have heq : (fun z ↦ J z ^ (n + 1) * F z) =
      fun z ↦ J z * dslope J x z ^ n * ((z - x) ^ n * F z) := by
    funext z
    have hz := sub_smul_dslope_of_zero hJ0 z
    simp only [smul_eq_mul] at hz
    rw [pow_succ', ← hz, mul_pow]
    ring
  rw [heq]
  exact hR

private lemma exists_mdifferentiableAt_j_sub_pow_succ_mul
    {f : ℍ → ℂ} (hf : LevelOneCuspData f) (τ : ℍ) :
    ∃ n : ℕ, MDiffAt (fun z ↦ (j z - j τ) ^ (n + 1) * f z) τ := by
  let F : ℂ → ℂ := f ∘ UpperHalfPlane.ofComplex
  let J : ℂ → ℂ := fun z ↦ j (UpperHalfPlane.ofComplex z) - j τ
  have hF : MeromorphicAt F (τ : ℂ) := hf.1 τ τ.im_pos
  have hjdiff : DifferentiableOn ℂ (j ∘ UpperHalfPlane.ofComplex)
      UpperHalfPlane.upperHalfPlaneSet :=
    UpperHalfPlane.mdifferentiable_iff.mp ModularFunction.j_mdifferentiable
  have hJ : AnalyticAt ℂ J (τ : ℂ) := by
    exact (hjdiff.analyticAt
      (UpperHalfPlane.isOpen_upperHalfPlaneSet.mem_nhds τ.im_pos)).sub analyticAt_const
  have hJ0 : J (τ : ℂ) = 0 := by
    simp [J]
  obtain ⟨n, hn⟩ :=
    exists_analyticAt_pow_succ_mul_of_meromorphicAt_of_analyticAt_zero hF hJ hJ0
  refine ⟨n, UpperHalfPlane.mdifferentiableAt_iff.mpr ?_⟩
  simpa only [F, J, Function.comp_def] using hn.differentiableAt

private lemma mdifferentiable_polynomialIn_j (P : Polynomial ℂ) :
    MDiff (Cox.polynomialIn P j) := by
  exact UpperHalfPlane.mdifferentiable_iff.mpr <|
    P.differentiable.comp_differentiableOn
      (UpperHalfPlane.mdifferentiable_iff.mp ModularFunction.j_mdifferentiable)

private lemma levelOne_invariant_apply {f : ℍ → ℂ}
    (hf : LevelOneCuspData f) (γ : SL(2, ℤ)) (τ : ℍ) :
    f (γ • τ) = f τ := by
  let γ₀ : CongruenceSubgroup.Gamma0 1 :=
    ⟨γ, CongruenceSubgroup.Gamma0_mem.mpr (Subsingleton.elim _ _)⟩
  have h := congrFun (hf.2.1 γ₀) τ
  simpa only [ModularForm.SL_slash_apply, neg_zero, zpow_zero, mul_one] using h

private lemma exists_polynomial_clearing_poles_on_fd_aux {f : ℍ → ℂ}
    (hf : LevelOneCuspData f) :
    ∃ P : Polynomial ℂ, P ≠ 0 ∧ ∀ τ ∈ ModularGroup.fd,
      MDiffAt (fun z ↦ P.eval (j z) * f z) τ := by
  classical
  have hevent := eventually_mdifferentiableAt_atImInfty hf
  change {τ : ℍ | MDiffAt f τ} ∈ atImInfty at hevent
  obtain ⟨y, hy⟩ := UpperHalfPlane.atImInfty_mem _ |>.mp hevent
  let Bad : Set ℍ := {τ | τ ∈ ModularGroup.truncatedFundamentalDomain y ∧ ¬MDiffAt f τ}
  have hBad : Bad.Finite := by
    simpa only [Bad] using finite_not_mdifferentiableAt_truncatedFundamentalDomain hf y
  let S : Finset ℍ := hBad.toFinset
  let e : ℍ → ℕ := fun τ ↦ Classical.choose
    (exists_mdifferentiableAt_j_sub_pow_succ_mul hf τ)
  have he (τ : ℍ) : MDiffAt (fun z ↦ (j z - j τ) ^ (e τ + 1) * f z) τ := by
    exact Classical.choose_spec (exists_mdifferentiableAt_j_sub_pow_succ_mul hf τ)
  let factor : ℍ → Polynomial ℂ := fun τ ↦
    (Polynomial.X - Polynomial.C (j τ)) ^ (e τ + 1)
  let P : Polynomial ℂ := S.prod factor
  have hP0 : P ≠ 0 := by
    apply Finset.prod_ne_zero_iff.mpr
    intro τ hτ
    exact pow_ne_zero _ (Polynomial.X_sub_C_ne_zero (j τ))
  refine ⟨P, hP0, ?_⟩
  intro τ hτfd
  by_cases hτy : τ.im ≤ y
  · by_cases hτf : MDiffAt f τ
    · exact (mdifferentiable_polynomialIn_j P τ).mul hτf
    · have hτS : τ ∈ S := by
        simp only [S, Set.Finite.mem_toFinset, Bad]
        exact ⟨⟨hτfd, hτy⟩, hτf⟩
      let Q : Polynomial ℂ := (S.erase τ).prod factor
      have hP : P = factor τ * Q := (Finset.mul_prod_erase S factor hτS).symm
      have hmul := (mdifferentiable_polynomialIn_j Q τ).mul (he τ)
      have hfun : (fun z ↦ P.eval (j z) * f z) = fun z ↦
          Cox.polynomialIn Q j z * ((j z - j τ) ^ (e τ + 1) * f z) := by
        funext z
        simp only [hP, Cox.polynomialIn, Polynomial.eval_mul, factor, Polynomial.eval_pow,
          Polynomial.eval_sub, Polynomial.eval_X, Polynomial.eval_C]
        ring
      rw [hfun]
      exact hmul
  · have hτf : MDiffAt f τ := hy τ (le_of_not_ge hτy)
    exact (mdifferentiable_polynomialIn_j P τ).mul hτf

/-- A nonzero polynomial in `j` clears the poles of raw level-one analytic data. -/
theorem CuspData.exists_polynomial_clearing_poles {f : ℍ → ℂ}
    (hf : LevelOneCuspData f) :
    ∃ P : Polynomial ℂ, P ≠ 0 ∧ MDiff (fun τ ↦ P.eval (j τ) * f τ) := by
  obtain ⟨P, hP0, hPfd⟩ := exists_polynomial_clearing_poles_on_fd_aux hf
  let H : ℍ → ℂ := fun τ ↦ P.eval (j τ) * f τ
  have hHinv (γ : SL(2, ℤ)) (τ : ℍ) : H (γ • τ) = H τ := by
    simp only [H, j_modularGroup_smul γ τ, levelOne_invariant_apply hf γ τ]
  refine ⟨P, hP0, ?_⟩
  intro τ
  obtain ⟨γ, hγ⟩ := ModularGroup.exists_smul_mem_fd τ
  have hcomp : MDiffAt (H ∘ fun z ↦ γ • z) τ :=
    (hPfd (γ • τ) hγ).comp τ
      ((UpperHalfPlane.mdifferentiable_smul (g := (γ : GL (Fin 2) ℝ)) (by simp)) τ)
  have hfun : (H ∘ fun z ↦ γ • z) = H := by
    funext z
    exact hHinv γ z
  rw [hfun] at hcomp
  exact hcomp

/-- Pole-clearing and polynomiality give rationality for raw level-one analytic data. -/
theorem CuspData.rationalInJ {f : ℍ → ℂ} (hf : LevelOneCuspData f) :
    RationalIn f j := by
  obtain ⟨P, hP, hPdiff⟩ := hf.exists_polynomial_clearing_poles
  have hPmod : LevelOneCuspData (fun τ ↦ P.eval (j τ) * f τ) := by
    simpa only [Cox.polynomialIn] using
      (j_levelOneCuspData.polynomialIn P).mul hf
  obtain ⟨Q, hQ⟩ := CuspData.polynomialInJ_of_holomorphic hPmod hPdiff
  refine ⟨Q, P, hP, ?_⟩
  intro τ hPτ
  rw [eq_div_iff hPτ]
  simpa only [Cox.polynomialIn, mul_comm] using congrFun hQ τ

/-- Cox Theorem 11.9(i): every bundled level-one modular function is rational in `j`. -/
theorem theorem_11_9_i (f : ModularFunction 𝒮ℒ) : RationalIn f j :=
  (CuspData.of_levelOneModularFunction f).rationalInJ

/-- A bundled level-one modular function holomorphic on `ℍ` is a polynomial in `j`. -/
theorem levelOne_polynomialInJ_of_holomorphic (f : ModularFunction 𝒮ℒ) (hf : MDiff f) :
    ∃ P : Polynomial ℂ, (f : ℍ → ℂ) = Cox.polynomialIn P j :=
  (CuspData.of_levelOneModularFunction f).polynomialInJ_of_holomorphic hf

end Cox
