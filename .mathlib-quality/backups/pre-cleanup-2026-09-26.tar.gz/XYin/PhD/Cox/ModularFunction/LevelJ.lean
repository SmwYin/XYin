/-
Copyright (c) 2026 The XYin contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The XYin contributors
-/
import XYin.PhD.Cox.ModularFunction.CuspData
import XYin.PhD.jFunction.jLevelN

/-!
# The level transform of the modular invariant

This file constructs `levelJModularFunction N`, the bundled modular function `τ ↦ j(Nτ)` on
`Γ₀(N)`. Integral triangularization identifies each cusp transform with an affine transform of
`j`, whose q-coordinate expression proves meromorphy at the cusp.
-/

open Complex Filter Function MatrixGroups ModularForm UpperHalfPlane
open scoped Manifold Polynomial.Bivariate

noncomputable section

namespace Cox

/-- The project's `τ ↦ j(Nτ)`, with positivity packaged by a positive natural level. -/
noncomputable def levelJ (N : ℕ+) : ℍ → ℂ :=
  @jN (N : ℕ) ⟨PNat.ne_zero N⟩


private def natScaleUpperHalfPlane (N : ℕ+) (τ : ℍ) : ℍ :=
  ⟨(N : ℂ) * (τ : ℂ), by
    rw [Complex.mul_im]
    simp only [Complex.natCast_re, Complex.natCast_im, zero_mul, add_zero]
    exact mul_pos (Nat.cast_pos.mpr (PNat.pos N)) τ.im_pos⟩

@[simp]
private lemma coe_natScaleUpperHalfPlane (N : ℕ+) (τ : ℍ) :
    ((natScaleUpperHalfPlane N τ : ℍ) : ℂ) = (N : ℂ) * (τ : ℂ) :=
  rfl

private def affineUpperHalfPlane (g s : ℕ) (hg : 0 < g) (hs : 0 < s)
    (r : ℤ) (τ : ℍ) : ℍ :=
  ((r : ℝ) / s) +ᵥ
    ((⟨(g : ℝ) / s, div_pos (Nat.cast_pos.mpr hg) (Nat.cast_pos.mpr hs)⟩ :
      {x : ℝ // 0 < x}) • τ)

@[simp]
private lemma coe_affineUpperHalfPlane (g s : ℕ) (hg : 0 < g) (hs : 0 < s)
    (r : ℤ) (τ : ℍ) :
    ((affineUpperHalfPlane g s hg hs r τ : ℍ) : ℂ) =
      ((r : ℝ) / s : ℂ) + ((g : ℝ) / s : ℂ) * (τ : ℂ) := by
  simp [affineUpperHalfPlane]

private lemma qParam_affineUpperHalfPlane (g s : ℕ) (hg : 0 < g) (hs : 0 < s)
    (r : ℤ) (τ : ℍ) :
    Periodic.qParam 1 (affineUpperHalfPlane g s hg hs r τ) =
      Complex.exp (2 * Real.pi * Complex.I * ((r : ℝ) / s)) *
        Periodic.qParam ((g * s : ℕ) : ℝ) τ ^ (g * g) := by
  rw [Periodic.qParam, Periodic.qParam, coe_affineUpperHalfPlane]
  simp only [Complex.ofReal_one, div_one]
  rw [show 2 * (Real.pi : ℂ) * Complex.I *
      (((r : ℝ) / s : ℂ) + ((g : ℝ) / s : ℂ) * (τ : ℂ)) =
      2 * (Real.pi : ℂ) * Complex.I * ((r : ℝ) / s) +
        2 * (Real.pi : ℂ) * Complex.I * (((g : ℝ) / s : ℂ) * (τ : ℂ)) by ring,
    Complex.exp_add, ← Complex.exp_nat_mul]
  congr 1
  congr 1
  field_simp [show (g : ℂ) ≠ 0 by exact_mod_cast hg.ne',
    show (s : ℂ) ≠ 0 by exact_mod_cast hs.ne']
  push_cast
  ring

private lemma complex_mobius_scale_eq_affine
    {n p q u v a b c d g r s z : ℂ}
    (hD : c * z + d ≠ 0) (hs : s ≠ 0)
    (h00 : p * (n * a) + q * c = g) (h01 : p * (n * b) + q * d = r)
    (h10 : u * (n * a) + v * c = 0) (h11 : u * (n * b) + v * d = s) :
    (p * (n * ((a * z + b) / (c * z + d))) + q) /
        (u * (n * ((a * z + b) / (c * z + d))) + v) =
      r / s + g / s * z := by
  let D := c * z + d
  have hD' : D ≠ 0 := by simpa [D] using hD
  have hnum : p * (n * ((a * z + b) / D)) + q = (g * z + r) / D := by
    field_simp [hD']
    linear_combination z * h00 + h01
  have hden : u * (n * ((a * z + b) / D)) + v = s / D := by
    field_simp [hD']
    linear_combination z * h10 + h11
  rw [show c * z + d = D from rfl, hnum, hden]
  field_simp [hD', hs]
  ring

private lemma coe_inv_smul_natScale_smul (N : ℕ+) (γ δ : SL(2, ℤ)) (τ : ℍ) :
    (((δ⁻¹ : SL(2, ℤ)) • natScaleUpperHalfPlane N (γ • τ) : ℍ) : ℂ) =
      ((((δ⁻¹ : SL(2, ℤ)) 0 0 : ℤ) : ℂ) *
          ((N : ℂ) *
            ((((γ 0 0 : ℤ) : ℂ) * (τ : ℂ) + (γ 0 1 : ℤ)) /
              (((γ 1 0 : ℤ) : ℂ) * (τ : ℂ) + (γ 1 1 : ℤ)))) +
        (((δ⁻¹ : SL(2, ℤ)) 0 1 : ℤ) : ℂ)) /
      ((((δ⁻¹ : SL(2, ℤ)) 1 0 : ℤ) : ℂ) *
          ((N : ℂ) *
            ((((γ 0 0 : ℤ) : ℂ) * (τ : ℂ) + (γ 0 1 : ℤ)) /
              (((γ 1 0 : ℤ) : ℂ) * (τ : ℂ) + (γ 1 1 : ℤ)))) +
        (((δ⁻¹ : SL(2, ℤ)) 1 1 : ℤ) : ℂ)) := by
  rw [UpperHalfPlane.coe_specialLinearGroup_apply, coe_natScaleUpperHalfPlane,
    UpperHalfPlane.coe_specialLinearGroup_apply]
  rfl

private lemma inv_smul_natScale_smul_eq_affine
    (N : ℕ+) (γ δ : SL(2, ℤ)) (g s : ℕ) (hg : 0 < g) (hs : 0 < s)
    (r : ℤ)
    (hmat : (δ⁻¹ : SL(2, ℤ)).1 *
        !![(N : ℤ) * γ 0 0, (N : ℤ) * γ 0 1; γ 1 0, γ 1 1] =
      !![(g : ℤ), r; 0, (s : ℤ)]) (τ : ℍ) :
    (δ⁻¹ : SL(2, ℤ)) • natScaleUpperHalfPlane N (γ • τ) =
      affineUpperHalfPlane g s hg hs r τ := by
  have h00 := congrArg (fun x : ℤ ↦ (x : ℂ)) (congrFun (congrFun hmat 0) 0)
  have h01 := congrArg (fun x : ℤ ↦ (x : ℂ)) (congrFun (congrFun hmat 0) 1)
  have h10 := congrArg (fun x : ℤ ↦ (x : ℂ)) (congrFun (congrFun hmat 1) 0)
  have h11 := congrArg (fun x : ℤ ↦ (x : ℂ)) (congrFun (congrFun hmat 1) 1)
  simp only [Matrix.mul_apply, Fin.sum_univ_two, Matrix.of_apply, Matrix.cons_val_zero,
    Matrix.cons_val_one] at h00 h01 h10 h11
  push_cast at h00 h01 h10 h11
  have hD : (((γ 1 0 : ℤ) : ℂ) * (τ : ℂ) + (γ 1 1 : ℤ)) ≠ 0 := by
    simpa [ModularGroup.denom_apply, algebraMap_int_eq] using
      UpperHalfPlane.denom_ne_zero γ τ
  apply UpperHalfPlane.ext
  rw [coe_inv_smul_natScale_smul, coe_affineUpperHalfPlane]
  exact complex_mobius_scale_eq_affine hD (by exact_mod_cast hs.ne')
    h00 h01 h10 h11

private lemma cuspFunction_affine_j_eq (g s : ℕ) (hg : 0 < g) (hs : 0 < s)
    (r : ℤ) {q : ℂ} (hq0 : q ≠ 0) (hqnorm : ‖q‖ < 1) :
    cuspFunction (((g * s : ℕ) : ℝ))
        (fun τ : ℍ ↦ j (affineUpperHalfPlane g s hg hs r τ)) q =
      cuspFunction 1 j
        (Complex.exp (2 * Real.pi * Complex.I * ((r : ℝ) / s)) * q ^ (g * g)) := by
  have hgs : (0 : ℝ) < (g * s : ℕ) := by positivity
  have him := Periodic.im_invQParam_pos_of_norm_lt_one hgs hqnorm hq0
  let τ : ℍ := ⟨Periodic.invQParam ((g * s : ℕ) : ℝ) q, him⟩
  let w : ℍ := affineUpperHalfPlane g s hg hs r τ
  have hleft :
      cuspFunction (((g * s : ℕ) : ℝ))
          (fun z : ℍ ↦ j (affineUpperHalfPlane g s hg hs r z)) q = j w := by
    change Periodic.cuspFunction ((g * s : ℕ) : ℝ) _ q = j w
    rw [Periodic.cuspFunction_eq_of_nonzero _ _ hq0]
    simp only [Function.comp_apply]
    rw [UpperHalfPlane.ofComplex_apply_of_im_pos him]
  have hqparam :
      Periodic.qParam 1 w =
        Complex.exp (2 * Real.pi * Complex.I * ((r : ℝ) / s)) * q ^ (g * g) := by
    rw [show w = affineUpperHalfPlane g s hg hs r τ from rfl,
      qParam_affineUpperHalfPlane]
    rw [show Periodic.qParam ((g * s : ℕ) : ℝ) τ = q by
      simpa [τ] using Periodic.qParam_right_inv
        (show (((g * s : ℕ) : ℝ)) ≠ 0 by positivity) hq0]
  rw [hleft, ← hqparam]
  exact (UpperHalfPlane.eq_cuspFunction w one_ne_zero ModularFunction.j_periodic).symm

private lemma first_column_ne_zero_of_det_ne_zero_aux
    {M : Matrix (Fin 2) (Fin 2) ℤ} (hM : M.det ≠ 0) :
    M 0 0 ≠ 0 ∨ M 1 0 ≠ 0 := by
  by_contra h
  push Not at h
  apply hM
  rw [Matrix.det_fin_two, h.1, h.2]
  ring

private lemma exists_sl2_inv_mul_first_column_gcd_aux
    (M : Matrix (Fin 2) (Fin 2) ℤ)
    (hG : (Int.gcd (M 0 0) (M 1 0) : ℤ) ≠ 0) :
    ∃ δ : SL(2, ℤ),
      (((δ⁻¹ : SL(2, ℤ)).1 * M) 0 0 = (Int.gcd (M 0 0) (M 1 0) : ℤ) ∧
        ((δ⁻¹ : SL(2, ℤ)).1 * M) 1 0 = 0) := by
  let A : ℤ := M 0 0
  let C : ℤ := M 1 0
  let G : ℤ := Int.gcd A C
  let u : ℤ := A / G
  let v : ℤ := C / G
  have huG : u * G = A :=
    Int.ediv_mul_cancel (by simpa [G] using Int.gcd_dvd_left A C)
  have hvG : v * G = C :=
    Int.ediv_mul_cancel (by simpa [G] using Int.gcd_dvd_right A C)
  have huv : IsCoprime u v := by
    simpa [u, v, G] using isCoprime_div_gcd_div_gcd_of_gcd_ne_zero (p := A) (q := C)
      (by exact_mod_cast (show G ≠ 0 by simpa [A, C, G] using hG))
  obtain ⟨δ, hδu, hδv⟩ := huv.exists_SL2_col 0
  have hδdet : u * δ 1 1 - δ 0 1 * v = 1 := by
    simpa only [Matrix.det_fin_two, hδu, hδv] using δ.prop
  refine ⟨δ, ?_, ?_⟩
  · rw [Matrix.mul_apply, Matrix.SpecialLinearGroup.SL2_inv_expl, Fin.sum_univ_two]
    simp only [Matrix.cons_val_zero, Matrix.cons_val_one]
    change δ 1 1 * A + -δ 0 1 * C = G
    calc
      δ 1 1 * A + -δ 0 1 * C = (u * δ 1 1 - δ 0 1 * v) * G := by
        linear_combination -(δ 1 1) * huG + δ 0 1 * hvG
      _ = G := by rw [hδdet, one_mul]
  · rw [Matrix.mul_apply, Matrix.SpecialLinearGroup.SL2_inv_expl, Fin.sum_univ_two]
    simp only [Matrix.cons_val_zero, Matrix.cons_val_one]
    rw [hδu, hδv]
    change -v * A + u * C = 0
    linear_combination v * huG - u * hvG

private lemma matrix_eq_upper_triangular_aux (B : Matrix (Fin 2) (Fin 2) ℤ) (G : ℤ)
    (h00 : B 0 0 = G) (h10 : B 1 0 = 0) : B = !![G, B 0 1; 0, B 1 1] := by
  ext i j
  fin_cases i <;> fin_cases j
  · exact h00
  · rfl
  · exact h10
  · rfl

private lemma exists_positive_upper_triangularization_aux (N : ℕ+)
    (M : Matrix (Fin 2) (Fin 2) ℤ) (hdet : M.det = (N : ℤ)) :
    ∃ (δ : SL(2, ℤ)) (g s : ℕ), 0 < g ∧ 0 < s ∧ g * s = (N : ℕ) ∧
      ∃ r : ℤ, (δ⁻¹ : SL(2, ℤ)).1 * M = !![(g : ℤ), r; 0, (s : ℤ)] := by
  have hMdet : M.det ≠ 0 := by rw [hdet]; positivity
  have hcol := first_column_ne_zero_of_det_ne_zero_aux hMdet
  let G : ℤ := Int.gcd (M 0 0) (M 1 0)
  have hGpos : 0 < G := by
    dsimp [G]
    exact_mod_cast hcol.elim (fun h ↦ Int.gcd_pos_of_ne_zero_left (M 1 0) h)
      (fun h ↦ Int.gcd_pos_of_ne_zero_right (M 0 0) h)
  obtain ⟨δ, h00, h10⟩ := exists_sl2_inv_mul_first_column_gcd_aux M
    (by simpa [G] using hGpos.ne')
  let B : Matrix (Fin 2) (Fin 2) ℤ := (δ⁻¹ : SL(2, ℤ)).1 * M
  have hB00 : B 0 0 = G := by simpa [B, G] using h00
  have hB10 : B 1 0 = 0 := by simpa [B] using h10
  have hdetB : B.det = (N : ℤ) := by
    change ((δ⁻¹ : SL(2, ℤ)).1 * M).det = (N : ℤ)
    rw [Matrix.det_mul, Matrix.SpecialLinearGroup.det_coe, one_mul, hdet]
  let S : ℤ := B 1 1
  have hGS : G * S = (N : ℤ) := by
    simpa [Matrix.det_fin_two, hB00, hB10, S] using hdetB
  have hSpos : 0 < S := Int.pos_of_mul_pos_right (hGS.symm ▸ (by positivity)) hGpos
  have hprod : G.natAbs * S.natAbs = (N : ℕ) := by
    simpa only [Int.natAbs_mul, Int.natAbs_natCast] using congrArg Int.natAbs hGS
  refine ⟨δ, G.natAbs, S.natAbs, Int.natAbs_pos.mpr hGpos.ne',
    Int.natAbs_pos.mpr hSpos.ne', hprod, B 0 1, ?_⟩
  simpa [Int.ofNat_natAbs_of_nonneg hGpos.le,
    Int.ofNat_natAbs_of_nonneg hSpos.le] using
    matrix_eq_upper_triangular_aux B G hB00 hB10

private lemma exists_levelJ_cusp_normalization (N : ℕ+) (γ : SL(2, ℤ)) :
    ∃ (δ : SL(2, ℤ)) (g s : ℕ), 0 < g ∧ 0 < s ∧ g * s = (N : ℕ) ∧
      ∃ r : ℤ,
        (δ⁻¹ : SL(2, ℤ)).1 *
            !![(N : ℤ) * γ 0 0, (N : ℤ) * γ 0 1; γ 1 0, γ 1 1] =
          !![(g : ℤ), r; 0, (s : ℤ)] := by
  let M : Matrix (Fin 2) (Fin 2) ℤ :=
    !![(N : ℤ) * γ 0 0, (N : ℤ) * γ 0 1; γ 1 0, γ 1 1]
  have hγ := γ.prop
  rw [Matrix.det_fin_two] at hγ
  have hdet : M.det = (N : ℤ) := by
    change (!![(N : ℤ) * γ 0 0, (N : ℤ) * γ 0 1; γ 1 0, γ 1 1]).det = (N : ℤ)
    rw [Matrix.det_fin_two_of]
    linear_combination (N : ℤ) * hγ
  simpa [M] using exists_positive_upper_triangularization_aux N M hdet

private lemma levelJ_comp_eq_affine_of_normalization
    (N : ℕ+) (γ δ : SL(2, ℤ)) (g s : ℕ) (hg : 0 < g) (hs : 0 < s)
    (r : ℤ)
    (hmat :
      (δ⁻¹ : SL(2, ℤ)).1 *
          !![(N : ℤ) * γ 0 0, (N : ℤ) * γ 0 1; γ 1 0, γ 1 1] =
        !![(g : ℤ), r; 0, (s : ℤ)]) :
    (fun τ : ℍ ↦ levelJ N (γ • τ)) =
      fun τ : ℍ ↦ j (affineUpperHalfPlane g s hg hs r τ) := by
  funext τ
  change j (natScaleUpperHalfPlane N (γ • τ)) =
    j (affineUpperHalfPlane g s hg hs r τ)
  rw [← j_modularGroup_smul (δ⁻¹) (natScaleUpperHalfPlane N (γ • τ))]
  congr 1
  exact inv_smul_natScale_smul_eq_affine N γ δ g s hg hs r hmat τ

private lemma affine_j_cuspFunction_meromorphicAt
    (g s : ℕ) (hg : 0 < g) (hs : 0 < s) (r : ℤ) :
    MeromorphicAt
      (cuspFunction (((g * s : ℕ) : ℝ))
        (fun τ : ℍ ↦ j (affineUpperHalfPlane g s hg hs r τ))) 0 := by
  let ζ : ℂ := Complex.exp (2 * Real.pi * Complex.I * ((r : ℝ) / s))
  let φ : ℂ → ℂ := fun q ↦ ζ * q ^ (g * g)
  have hgg : g * g ≠ 0 := mul_ne_zero hg.ne' hg.ne'
  have hφ0 : φ 0 = 0 := by simp [φ, hgg]
  have hφan : AnalyticAt ℂ φ 0 := by
    exact analyticAt_const.mul (analyticAt_id.pow (g * g))
  have hbase : MeromorphicAt (cuspFunction 1 j) (φ 0) := by
    simpa [hφ0] using j_cuspFunction_meromorphicAt
  have hcomp : MeromorphicAt ((cuspFunction 1 j) ∘ φ) 0 :=
    hbase.comp_analyticAt hφan
  refine hcomp.congr ?_
  have hnorm : {q : ℂ | ‖q‖ < 1} ∈ nhdsWithin (0 : ℂ) ({0}ᶜ) :=
    nhdsWithin_le_nhds (by simpa [Metric.ball, dist_eq_norm]
      using Metric.ball_mem_nhds (0 : ℂ) zero_lt_one)
  filter_upwards [hnorm, self_mem_nhdsWithin] with q hqnorm hq
  have hq0 : q ≠ 0 := Set.mem_compl_singleton_iff.mp hq
  simpa [Function.comp_apply, φ, ζ] using
    (cuspFunction_affine_j_eq g s hg hs r hq0 hqnorm).symm

private lemma levelJ_meromorphicAt_cusp (N : ℕ+) (γ : SL(2, ℤ)) :
    MeromorphicAt
      (cuspFunction ((N : ℕ) : ℝ) (fun τ : ℍ ↦ levelJ N (γ • τ))) 0 := by
  obtain ⟨δ, g, s, hg, hs, hgs, r, hmat⟩ := exists_levelJ_cusp_normalization N γ
  have hfun := levelJ_comp_eq_affine_of_normalization N γ δ g s hg hs r hmat
  rw [hfun, ← hgs]
  exact affine_j_cuspFunction_meromorphicAt g s hg hs r

/-- The level transform `j(Nτ)` is holomorphic on the upper half-plane. -/
theorem levelJ_mdifferentiable (N : ℕ+) : MDiff (levelJ N) :=
  UpperHalfPlane.mdifferentiable_iff.mpr fun z hz ↦
    (jN_differentiableAt (N : ℕ) (z := ⟨z, hz⟩)).differentiableWithinAt

/-- The second generator of the modular function field, using the shared bundled definition. -/
def levelJModularFunction (N : ℕ+) :
    ModularFunction (CongruenceSubgroup.Gamma0 (N : ℕ)) :=
  ModularFunction.ofGamma0CuspData N (levelJ N)
    ((MeromorphicField.meromorphicNFOn_iff_exists _).mpr
      ⟨MeromorphicField.ofHolomorphic _ (levelJ_mdifferentiable N),
        MeromorphicField.toFun_ofHolomorphic _ (levelJ_mdifferentiable N)⟩)
    (fun γ ↦ jN_slash_invariant (N : ℕ) γ) (levelJ_meromorphicAt_cusp N)

@[simp]
theorem coe_levelJModularFunction (N : ℕ+) :
    (levelJModularFunction N : ℍ → ℂ) = levelJ N := rfl

/-- Analytic data for the bundled level transform. -/
theorem levelJ_cuspData (N : ℕ+) : CuspData N (levelJ N) :=
  CuspData.of_modularFunction N (levelJModularFunction N)

end Cox
